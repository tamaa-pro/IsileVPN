package com.tamaa.isilevpn

import android.content.Context
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

/**
 * تنقّل داخل صفحة الإعدادات (مثل HTTP Custom): القائمة الرئيسية صفوف (عنوان + وصف + سهم)،
 * والضغط على صف يفتح صفحة إعداداته وحدها مع شريط علوي فيه زر رجوع.
 */
class SettingsNav(private val ctx: Context, page: View) {
    private val menu = page.findViewById<LinearLayout>(R.id.settingsMenu)
    private val menuScroll = page.findViewById<View>(R.id.settingsMenuScroll)
    private val detail = page.findViewById<View>(R.id.settingsDetail)
    private val title = page.findViewById<TextView>(R.id.settingsTitle)
    private val general = page.findViewById<View>(R.id.settingsRoot)
    private val tunnelBox = page.findViewById<LinearLayout>(R.id.tunnelBox)

    /** الصفحة المفتوحة الآن: null = القائمة، GENERAL، أو عنوان قسم Tunnel. */
    var current: String? = null
        private set

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    init {
        page.findViewById<ImageButton>(R.id.settingsBack).setOnClickListener { close() }
        buildMenu()
        Tr.view(detail); Tr.align(detail)
    }

    private fun header(text: String) = TextView(ctx).apply {
        this.text = text.uppercase()
        textSize = 12f
        setTextColor(ContextCompat.getColor(ctx, R.color.accent))
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(22); bottomMargin = dp(4) }
    }

    private fun row(name: String, desc: String, onClick: () -> Unit): View {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(12), dp(4), dp(12))
            val tv = TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            setBackgroundResource(tv.resourceId)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginEnd = dp(12) }
        }
        col.addView(TextView(ctx).apply {
            text = name
            textSize = 17f
            setTextColor(ContextCompat.getColor(ctx, R.color.text))
        })
        if (desc.isNotEmpty()) col.addView(TextView(ctx).apply {
            text = desc
            textSize = 13f
            setTextColor(ContextCompat.getColor(ctx, R.color.text_dim))
        })
        r.addView(col)
        r.addView(ImageView(ctx).apply {
            setImageResource(R.drawable.ic_chevron)
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
        })
        return r
    }

    private fun buildMenu() {
        // الأول في القائمة عنوان "Settings" من ملف التخطيط؛ نُبقيه ونحذف ما بعده عند إعادة البناء
        while (menu.childCount > 1) menu.removeViewAt(1)
        menu.addView(row("General", "Language, theme and speed unit.") { open(GENERAL) })
        menu.addView(header("Connection"))
        for (sec in TunnelPrefs.connection) menu.addView(row(sec.title, sec.desc) { open(sec.title) })
        menu.addView(header("Tunnel"))
        for (sec in TunnelPrefs.sections) menu.addView(row(sec.title, sec.desc) { open(sec.title) })
        menu.addView(MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Reset tunnel settings"
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(28); bottomMargin = dp(24) }
            setOnClickListener { TunnelPrefs.reset(ctx) }
        })
        Tr.view(menu); Tr.align(menu)
    }

    fun open(key: String) {
        val sec = (TunnelPrefs.connection + TunnelPrefs.sections).firstOrNull { it.title == key }
        if (key != GENERAL && sec == null) return
        current = key
        title.text = Tr.t(key)
        general.visibility = if (key == GENERAL) View.VISIBLE else View.GONE
        tunnelBox.visibility = if (sec != null) View.VISIBLE else View.GONE
        if (sec != null) TunnelSettingsUi.buildSection(ctx, tunnelBox, sec)
        menuScroll.visibility = View.GONE
        detail.visibility = View.VISIBLE
    }

    /** يرجع للقائمة. يعيد true إذا كانت صفحة فرعية مفتوحة (أي استُهلك الضغط). */
    fun close(): Boolean {
        if (current == null) return false
        current = null
        detail.visibility = View.GONE
        menuScroll.visibility = View.VISIBLE
        return true
    }

    companion object { const val GENERAL = "General" }
}
