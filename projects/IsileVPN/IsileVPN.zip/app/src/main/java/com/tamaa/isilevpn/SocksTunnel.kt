package com.tamaa.isilevpn

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * VayDNS: خادم SOCKS5 محلي (بدون مصادقة، على 127.0.0.1 فقط) تتصل به أداة tun2socks.
 * كل اتصال يُمرَّر إلى SOCKS5 البعيد عبر منفذ عميل VayDNS المحلي، مع اسم المستخدم وكلمة المرور (RFC 1929).
 * الخادم البعيد يدعم TCP فقط، لذلك تُحوَّل استعلامات DNS (UDP ASSOCIATE على المنفذ 53) إلى DNS عبر TCP.
 */
class SocksTunnel(private val p: Profile, private val onLost: () -> Unit) {
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    private var upHost = "127.0.0.1"
    private var upPort = 0
    @Volatile private var stopped = false
    @Volatile private var running = false

    private class Up(val sock: Socket, val ins: InputStream, val outs: OutputStream)

    private class SocksReject(val code: Int) : IOException("SOCKS5 error $code")

    /** يتحقق من الاتصال والمصادقة عبر النفق مرة واحدة، ثم يفتح المنفذ المحلي لأداة tun2socks. */
    fun start(host: String, port: Int, timeoutMs: Int) {
        upHost = host
        upPort = port
        Bus.log("SOCKS5: Connecting through the tunnel, timeout ${timeoutMs / 1000} seconds")
        val deadline = System.currentTimeMillis() + timeoutMs
        var last: Exception? = null
        var ok = false
        // الاتصال الأول عبر نفق DNS قد يحتاج عدة محاولات حتى تكتمل المصافحة
        while (!stopped && System.currentTimeMillis() < deadline) {
            try {
                // مصافحة SOCKS5 فقط (طريقة المصادقة)، دون الاتصال بوجهة معيّنة: تثبت أن النفق يعمل وأن الخادم SOCKS5
                probe(minOf(20000, (deadline - System.currentTimeMillis()).toInt().coerceAtLeast(3000)))
                ok = true
                break
            } catch (e: SocksReject) {
                if (e.code == AUTH_FAILED) throw IOException("SOCKS5: wrong username or password")
                if (e.code == NO_METHOD) throw IOException(
                    if (p.auth) "SOCKS5: the server rejected the authentication method"
                    else "SOCKS5: the server requires a username and password (turn on Authentication)"
                )
                last = e
            } catch (e: Exception) {
                last = e
            }
            try { Thread.sleep(1500) } catch (_: InterruptedException) { break }
        }
        if (stopped) throw CancelledException()
        if (!ok) throw IOException("SOCKS5: no response through the tunnel" + (last?.message?.let { " ($it)" } ?: ""))
        Bus.log(if (p.auth) "SOCKS5: Authenticated as ${p.user}" else "SOCKS5: Connected (no authentication)")

        var ss: ServerSocket? = null
        var err: Exception? = null
        for (i in 0 until 10) {
            if (stopped) break
            try {
                val c = ServerSocket()
                c.reuseAddress = true
                c.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), XrayConfig.SOCKS_PORT), 128)
                ss = c
                break
            } catch (e: IOException) {
                err = e
                try { Thread.sleep(300) } catch (_: InterruptedException) { break }
            }
        }
        if (ss == null) {
            if (stopped) throw CancelledException()
            throw IOException("Local SOCKS port ${XrayConfig.SOCKS_PORT} is busy: ${err?.message}")
        }
        synchronized(this) {
            if (stopped) {
                try { ss.close() } catch (_: Exception) {}
                throw CancelledException()
            }
            server = ss
            running = true
        }
        val srv = ss
        try {
            pool.execute {
                while (running) {
                    val c = try { srv.accept() } catch (_: Exception) { break }
                    try {
                        pool.execute { handle(c) }
                    } catch (_: java.util.concurrent.RejectedExecutionException) {
                        try { c.close() } catch (_: Exception) {}
                        break
                    }
                }
            }
            // اتصال خادم SOCKS البعيد عبر النفق: إن فشل عدة فحوص متتالية نعتبر الرابط مقطوعًا
            pool.execute { watchdog() }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            throw CancelledException()
        }
    }

    private fun watchdog() {
        var fails = 0
        while (running) {
            try { Thread.sleep(20000) } catch (_: InterruptedException) { break }
            if (!running) break
            try {
                probe(20000)
                fails = 0
            } catch (e: SocksReject) {
                // رفض صريح (مثلاً الحساب انتهى أو عُطّل): لا فائدة من الانتظار
                if (running) { Bus.log("SOCKS5: ${if (e.code == AUTH_FAILED) "account rejected" else "server error ${e.code}"}"); onLost() }
                break
            } catch (_: Exception) {
                if (++fails >= 3 && running) {
                    Bus.log("SOCKS5: Connection lost")
                    onLost()
                    break
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        stopped = true
        running = false
        try { server?.close() } catch (_: Exception) {}
        server = null
        pool.shutdownNow()
    }

    /**
     * يفتح اتصالًا بالخادم البعيد عبر النفق ويطلب CONNECT. المصافحة كلها تُرسل دفعة واحدة (pipelining)
     * لأن كل رحلة ذهاب وإياب عبر DNS مكلفة.
     */
    /** مصافحة SOCKS5 (والمصادقة إن فُعّلت) دون طلب اتصال. تُستخدم للتحقق من النفق ثم كفحص دوري. */
    private fun probe(timeoutMs: Int) {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(upHost, upPort), 10000)
            s.soTimeout = timeoutMs
            val o = s.getOutputStream()
            val i = DataInputStream(BufferedInputStream(s.getInputStream()))
            o.write(handshake())
            o.flush()
            if (i.readUnsignedByte() != 5) throw IOException("not a SOCKS5 server")
            if (i.readUnsignedByte() != (if (p.auth) 2 else 0)) throw SocksReject(NO_METHOD)
            if (p.auth) {
                if (i.readUnsignedByte() != 1) throw IOException("bad auth reply")
                if (i.readUnsignedByte() != 0) throw SocksReject(AUTH_FAILED)
            }
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun handshake(): ByteArray {
        val req = ByteArrayOutputStream()
        if (p.auth) {
            val u = p.user.toByteArray(Charsets.UTF_8)
            val w = p.pass.toByteArray(Charsets.UTF_8)
            req.write(byteArrayOf(5, 1, 2))
            req.write(1); req.write(u.size); req.write(u)
            req.write(w.size); req.write(w)
        } else {
            req.write(byteArrayOf(5, 1, 0)) // بدون مصادقة
        }
        return req.toByteArray()
    }

    private fun openUp(host: String, port: Int, timeoutMs: Int): Up {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(upHost, upPort), 10000)
            s.soTimeout = timeoutMs
            val o = s.getOutputStream()
            val i = DataInputStream(BufferedInputStream(s.getInputStream()))
            val auth = p.auth
            val req = ByteArrayOutputStream()
            req.write(handshake())
            req.write(byteArrayOf(5, 1, 0))
            val ip = ipLiteral(host)
            when {
                ip != null && ip.size == 4 -> { req.write(1); req.write(ip) }
                ip != null -> { req.write(4); req.write(ip) }
                else -> { val h = host.toByteArray(Charsets.ISO_8859_1); req.write(3); req.write(h.size); req.write(h) }
            }
            req.write(port shr 8); req.write(port and 0xff)
            o.write(req.toByteArray())
            o.flush()
            if (i.readUnsignedByte() != 5) throw IOException("not a SOCKS5 server")
            if (i.readUnsignedByte() != (if (auth) 2 else 0)) throw SocksReject(NO_METHOD)
            if (auth) {
                if (i.readUnsignedByte() != 1) throw IOException("bad auth reply")
                if (i.readUnsignedByte() != 0) throw SocksReject(AUTH_FAILED)
            }
            if (i.readUnsignedByte() != 5) throw IOException("bad reply")
            val rep = i.readUnsignedByte()
            i.readUnsignedByte()
            when (i.readUnsignedByte()) {
                1 -> i.readFully(ByteArray(4))
                4 -> i.readFully(ByteArray(16))
                3 -> i.readFully(ByteArray(i.readUnsignedByte()))
                else -> throw IOException("bad address type")
            }
            i.readFully(ByteArray(2))
            if (rep != 0) throw SocksReject(rep)
            s.soTimeout = 0
            return Up(s, i, o)
        } catch (e: Exception) {
            try { s.close() } catch (_: Exception) {}
            throw e
        }
    }

    private fun ipLiteral(h: String): ByteArray? {
        if (!h.all { it.isDigit() || it == '.' || it == ':' || it in 'a'..'f' || it in 'A'..'F' } || !(h.contains('.') || h.contains(':'))) return null
        return try { InetAddress.getByName(h).address } catch (_: Exception) { null }
    }

    private fun readAddr(i: DataInputStream, atyp: Int): String = when (atyp) {
        1 -> { val b = ByteArray(4); i.readFully(b); InetAddress.getByAddress(b).hostAddress ?: "" }
        4 -> { val b = ByteArray(16); i.readFully(b); InetAddress.getByAddress(b).hostAddress ?: "" }
        3 -> { val l = i.readUnsignedByte(); val b = ByteArray(l); i.readFully(b); String(b, Charsets.ISO_8859_1) }
        else -> throw IOException("Bad address type")
    }

    private fun handle(c: Socket) {
        try {
            c.tcpNoDelay = true
            val inp = DataInputStream(BufferedInputStream(c.getInputStream()))
            val out = c.getOutputStream()
            if (inp.readUnsignedByte() != 5) return
            val n = inp.readUnsignedByte()
            inp.readFully(ByteArray(n))
            out.write(byteArrayOf(5, 0)); out.flush()
            inp.readUnsignedByte()
            val cmd = inp.readUnsignedByte()
            inp.readUnsignedByte()
            val host = readAddr(inp, inp.readUnsignedByte())
            val port = inp.readUnsignedShort()
            when (cmd) {
                1 -> connectCmd(c, inp, out, host, port)
                3 -> udpCmd(inp, out)
                else -> { out.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); out.flush() }
            }
        } catch (_: Exception) {
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
    }

    private fun connectCmd(c: Socket, inp: InputStream, out: OutputStream, host: String, port: Int) {
        val up = try {
            openUp(host, port, 30000)
        } catch (e: Exception) {
            val code = if (e is SocksReject && e.code in 1..8) e.code else 4
            out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0)); out.flush()
            return
        }
        out.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); out.flush()
        val t = Thread {
            try { copy(up.ins, out) } catch (_: Exception) {}
            try { up.sock.close() } catch (_: Exception) {}
            try { c.close() } catch (_: Exception) {}
        }
        t.isDaemon = true
        t.start()
        try { copy(inp, up.outs) } catch (_: Exception) {
        } finally {
            try { up.sock.close() } catch (_: Exception) {}
        }
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val b = ByteArray(32768)
        while (true) {
            val n = i.read(b)
            if (n < 0) break
            o.write(b, 0, n)
            o.flush()
        }
    }

    // ---- UDP ASSOCIATE: نمرّر استعلامات DNS (المنفذ 53) فقط، عبر DNS-over-TCP داخل النفق ----
    private fun udpCmd(inp: InputStream, out: OutputStream) {
        val ds = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        val prt = ds.localPort
        out.write(byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, (prt shr 8).toByte(), (prt and 0xff).toByte()))
        out.flush()
        pool.execute {
            val buf = ByteArray(65535)
            while (!ds.isClosed) {
                val pkt = DatagramPacket(buf, buf.size)
                try { ds.receive(pkt) } catch (_: Exception) { break }
                val data = pkt.data.copyOfRange(0, pkt.length)
                val client = pkt.socketAddress
                pool.execute { udpHandle(ds, data, client) }
            }
        }
        try { while (inp.read() >= 0) { /* keep control connection open */ } } catch (_: Exception) {}
        ds.close()
    }

    private fun udpHandle(ds: DatagramSocket, d: ByteArray, client: java.net.SocketAddress) {
        try {
            if (d.size < 10 || d[2].toInt() != 0) return
            var o = 4
            val host: String
            when (d[3].toInt()) {
                1 -> { host = InetAddress.getByAddress(d.copyOfRange(4, 8)).hostAddress ?: return; o = 8 }
                4 -> { host = InetAddress.getByAddress(d.copyOfRange(4, 20)).hostAddress ?: return; o = 20 }
                3 -> { val l = d[4].toInt() and 0xff; host = String(d, 5, l, Charsets.ISO_8859_1); o = 5 + l }
                else -> return
            }
            val port = ((d[o].toInt() and 0xff) shl 8) or (d[o + 1].toInt() and 0xff)
            o += 2
            if (port != 53) return
            val resp = dnsOverTcp(host, d.copyOfRange(o, d.size)) ?: return
            val r = d.copyOfRange(0, o) + resp
            ds.send(DatagramPacket(r, r.size, client))
        } catch (_: Exception) {}
    }

    private fun dnsOverTcp(host: String, q: ByteArray): ByteArray? {
        val up = try { openUp(host, 53, 15000) } catch (_: Exception) { return null }
        val f = pool.submit(Callable<ByteArray> {
            up.outs.write(byteArrayOf((q.size shr 8).toByte(), (q.size and 0xff).toByte()))
            up.outs.write(q)
            up.outs.flush()
            val di = DataInputStream(up.ins)
            val len = di.readUnsignedShort()
            val r = ByteArray(len)
            di.readFully(r)
            r
        })
        return try { f.get(8, TimeUnit.SECONDS) } catch (_: Exception) { f.cancel(true); null } finally {
            try { up.sock.close() } catch (_: Exception) {}
        }
    }

    private companion object {
        const val AUTH_FAILED = 1000
        const val NO_METHOD = 1001
    }
}
