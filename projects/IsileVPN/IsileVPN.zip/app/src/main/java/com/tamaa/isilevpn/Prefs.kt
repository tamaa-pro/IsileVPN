package com.tamaa.isilevpn

import android.content.Context
import java.util.Locale

/** إعدادات التطبيق العامة (اللغة، المظهر، وحدة السرعة). */
object Prefs {
    const val LANG_EN = "en"
    const val LANG_AR = "ar"

    @Volatile var lang = LANG_EN
        private set
    @Volatile var dark = true
        private set
    @Volatile var bits = false
        private set

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("isile_settings", Context.MODE_PRIVATE)

    /** يُستدعى مرة واحدة عند بدء العملية (App.onCreate) لتحميل القيم المحفوظة. */
    fun load(c: Context) {
        val s = sp(c)
        lang = s.getString("lang", LANG_EN) ?: LANG_EN
        // ترحيل لمرة واحدة: المظلم هو الافتراضي، ويُفرض عند التحديث حتى لمن كان على المشرق
        if (!s.getBoolean("dark_default_v2", false)) {
            s.edit().putBoolean("dark", true).putBoolean("dark_default_v2", true).apply()
        }
        dark = s.getBoolean("dark", true)
        bits = s.getBoolean("bits", false)
        Tr.ar = lang == LANG_AR
    }

    fun setLang(c: Context, v: String) {
        lang = v
        Tr.ar = v == LANG_AR
        sp(c).edit().putString("lang", v).apply()
    }

    fun setDark(c: Context, v: Boolean) {
        dark = v
        sp(c).edit().putBoolean("dark", v).apply()
    }

    fun setBits(c: Context, v: Boolean) {
        bits = v
        sp(c).edit().putBoolean("bits", v).apply()
    }

    /**
     * يعرض السرعة (بايت/ثانية) بالوحدة المختارة.
     * البايت: B/s، KB/s، MB/s (أساس 1024). البت: b/s، Kb/s، Mb/s (البايت × 8، أساس 1000 كما في سرعات الشبكات).
     */
    fun fmtSpeed(bytesPerSec: Long): String {
        if (!bits) {
            val b = bytesPerSec
            return when {
                b < 1024 -> "$b B/s"
                b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB/s", b / 1024.0)
                else -> String.format(Locale.US, "%.2f MB/s", b / 1048576.0)
            }
        }
        val b = bytesPerSec * 8
        return when {
            b < 1000 -> "$b b/s"
            b < 1_000_000 -> String.format(Locale.US, "%.1f Kb/s", b / 1000.0)
            else -> String.format(Locale.US, "%.2f Mb/s", b / 1_000_000.0)
        }
    }
}
