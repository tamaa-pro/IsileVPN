package com.tamaa.isilevpn

import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * إعادة ترتيب بطاقات القائمة: ضغطة مطولة على بطاقة ثم تحريكها لأعلى أو لأسفل.
 * أثناء السحب لا تُنقل العناصر فعليًا؛ تُزاح البطاقات بصريًا، وعند الإفلات يُستدعى onDone بالترتيب الجديد.
 */
class ListReorder(
    private val root: LinearLayout,
    private val scroll: ScrollView?,
    private val onDone: (List<Int>) -> Unit
) {
    private var cards: List<View> = emptyList()
    private var drag: View? = null
    private var from = 0
    private var cur = 0
    private var grab = 0f
    private var rawY = 0f
    private val d = root.resources.displayMetrics.density

    private val tick = object : Runnable {
        override fun run() {
            if (drag == null) return
            scroll?.let { s ->
                val l = IntArray(2)
                s.getLocationOnScreen(l)
                val edge = 72 * d
                val speed = (14 * d).toInt()
                if (rawY < l[1] + edge) s.scrollBy(0, -speed)
                else if (rawY > l[1] + s.height - edge) s.scrollBy(0, speed)
            }
            update()
            root.postDelayed(this, 16)
        }
    }

    fun attach(list: List<View>) {
        cards = list
        list.forEachIndexed { i, v ->
            v.setOnLongClickListener { start(i); true }
            v.setOnTouchListener { _, e ->
                rawY = e.rawY
                if (drag === v) {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_MOVE -> update()
                        MotionEvent.ACTION_UP -> finish(true)
                        MotionEvent.ACTION_CANCEL -> finish(false)
                    }
                    true
                } else false
            }
        }
    }

    private fun rootTop(): Int {
        val l = IntArray(2)
        root.getLocationOnScreen(l)
        return l[1]
    }

    private fun start(i: Int) {
        val v = cards[i]
        drag = v; from = i; cur = i
        grab = (rawY - rootTop()) - v.top
        v.parent.requestDisallowInterceptTouchEvent(true)
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        v.translationZ = 12 * d
        v.animate().scaleX(1.03f).scaleY(1.03f).alpha(0.92f).setDuration(120).start()
        root.post(tick)
    }

    private fun update() {
        val v = drag ?: return
        val top = (rawY - rootTop()) - grab
        v.translationY = top - v.top
        val center = top + v.height / 2f
        var n = 0
        for (j in cards.indices) if (j != from && cards[j].top + cards[j].height / 2f < center) n++
        if (n == cur) return
        cur = n
        val stride = v.height + ((v.layoutParams as? ViewGroup.MarginLayoutParams)?.bottomMargin ?: 0)
        cards.forEachIndexed { j, c ->
            if (j == from) return@forEachIndexed
            val t = when {
                j in (from + 1)..cur -> -stride
                j in cur until from -> stride
                else -> 0
            }
            c.animate().translationY(t.toFloat()).setDuration(120).start()
        }
    }

    private fun finish(commit: Boolean) {
        if (drag == null) return
        root.removeCallbacks(tick)
        drag = null
        cards.forEach { c ->
            c.animate().cancel()
            c.translationY = 0f; c.translationZ = 0f
            c.scaleX = 1f; c.scaleY = 1f; c.alpha = 1f
        }
        if (commit && cur != from) {
            val order = cards.indices.filter { it != from }.toMutableList()
            order.add(cur, from)
            onDone(order)
        }
    }
}
