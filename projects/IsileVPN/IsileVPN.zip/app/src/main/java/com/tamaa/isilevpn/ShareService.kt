package com.tamaa.isilevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** خدمة أمامية تُبقي خادم المشاركة يعمل في الخلفية. */
class ShareService : Service() {
    companion object {
        const val ACTION_START = "com.tamaa.isilevpn.SHARE_START"
        const val ACTION_STOP = "com.tamaa.isilevpn.SHARE_STOP"
        private const val CH = "share"
        private const val ID = 2

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, ShareService::class.java).setAction(ACTION_START))
        }

        fun stop(c: Context) {
            ShareProxy.stop()
            c.stopService(Intent(c, ShareService::class.java))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ShareCfg.setEnabled(this, false)
            ShareProxy.stop()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val port = ShareCfg.port(this)
        val ip = ShareNet.shareIp()
        val n = notif(if (ip != null) "$ip:$port" else "${Tr.t("Port")} $port")
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID, n)
        if (!ShareProxy.start(port)) {
            ShareCfg.setEnabled(this, false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ShareProxy.stop()
        super.onDestroy()
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Share net", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 10, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 11, Intent(this, ShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(Tr.t("Share net is on"))
            .setContentText("${Tr.t("HTTP proxy")} · $text")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .addAction(0, Tr.t("Stop sharing"), stop)
            .build()
    }
}
