package com.tamaa.isilevpn

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/**
 * إعدادات النفق العامة (قسم Tunnel في الإعدادات). كل عنصر له قيمة افتراضية تحافظ على سلوك التطبيق السابق تمامًا.
 * في إعدادات VayDNS: القيمة الفارغة = يستعمل المحرك قيمته الافتراضية، وأي قيمة في الكونفيج نفسه تتقدم عليها.
 */
object TunnelPrefs {
    enum class Kind { INT, TEXT, BOOL, CHOICE }

    class Item(
        val key: String,
        val label: String,
        val kind: Kind,
        val def: String,
        val hint: String = "",
        val min: Int = 0,
        val max: Int = 0,
        val options: List<String> = emptyList(),
        /** INT/TEXT: هل يُسمح بقيمة فارغة (= افتراضي المحرك)؟ */
        val blankOk: Boolean = false
    )

    class Section(val title: String, val items: List<Item>)

    val sections: List<Section> = listOf(
        Section("Connection", listOf(
            Item("connect_timeout", "Connection timeout (seconds)", Kind.INT, "0", "0 = automatic (25s SSH, 60s DNS tunnels)", 0, 600),
            Item("attempts", "Connection attempts", Kind.INT, "1", "How many times to try before giving up", 1, 20),
            Item("retry_delay", "Delay between attempts (seconds)", Kind.INT, "3", "Also the start of the auto-reconnect delay", 1, 120),
            Item("max_reconnects", "Auto-reconnect attempts", Kind.INT, "0", "After a drop. 0 = keep trying until you disconnect", 0, 1000)
        )),
        Section("SSH", listOf(
            Item("ssh_keepalive", "Keepalive interval (seconds)", Kind.INT, "25", "", 5, 600),
            Item("ssh_keepalive_max", "Missed keepalives before reconnect", Kind.INT, "3", "", 1, 20),
            Item("ssh_compress", "Compression (zlib)", Kind.BOOL, "false", "Only if the server supports it; helps text, costs CPU"),
            Item("ssh_window_mb", "Receive window per connection (MB)", Kind.INT, "2", "Bigger = faster on high-ping links, more memory", 1, 16)
        )),
        Section("SlowDNS", listOf(
            Item("slow_extra", "Extra client flags", Kind.TEXT, "", "e.g. -utls Chrome (put flags only, no domain)", blankOk = true)
        )),
        Section("VayDNS", listOf(
            Item("vay_idle", "Idle timeout (seconds)", Kind.INT, "", "Default for configs that leave it empty", 1, 86400, blankOk = true),
            Item("vay_keepalive", "Keepalive (seconds)", Kind.INT, "", "Must be smaller than the idle timeout", 1, 86400, blankOk = true),
            Item("vay_udp_timeout", "UDP timeout (ms)", Kind.INT, "", "", 1, 600000, blankOk = true),
            Item("vay_workers", "UDP workers", Kind.INT, "", "", 1, 10000, blankOk = true),
            Item("vay_rps", "Queries per second limit", Kind.INT, "", "0 = unlimited", 0, 1000000, blankOk = true),
            Item("vay_utls", "TLS fingerprint", Kind.TEXT, "", "e.g. random, Chrome_120", blankOk = true),
            Item("vay_log", "Log level", Kind.CHOICE, "", "", options = listOf("") + VayDnsSpec.LOG_LEVELS, blankOk = true),
            Item("vay_extra", "Extra client flags", Kind.TEXT, "", "e.g. -max-streams 8", blankOk = true)
        )),
        Section("V2Ray", listOf(
            Item("v2_log", "Log level", Kind.CHOICE, "warning", "", options = listOf("none", "error", "warning", "info", "debug")),
            Item("v2_mux_conc", "Mux concurrency", Kind.INT, "8", "Used by configs that have Mux enabled", 1, 1024),
            Item("v2_buffer_kb", "Buffer per connection (KB)", Kind.INT, "0", "0 = Xray default", 0, 65536)
        ))
    )

    private val all: Map<String, Item> = sections.flatMap { it.items }.associateBy { it.key }
    private val cache = ConcurrentHashMap<String, String>()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("isile_tunnel", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val s = sp(c)
        cache.clear()
        for (it in all.values) s.getString(it.key, null)?.let { v -> cache[it.key] = v }
    }

    fun get(key: String): String = cache[key] ?: all[key]?.def.orEmpty()
    fun int(key: String): Int = get(key).trim().toIntOrNull() ?: all[key]?.def?.toIntOrNull() ?: 0
    fun bool(key: String): Boolean = get(key) == "true"

    fun set(c: Context, key: String, value: String) {
        cache[key] = value
        sp(c).edit().putString(key, value).apply()
    }

    fun reset(c: Context) {
        cache.clear()
        sp(c).edit().clear().apply()
    }

    /** null = صالح؛ وإلا رسالة الخطأ. */
    fun validate(it: Item, raw: String): String? {
        val v = raw.trim()
        if (v.isEmpty()) return if (it.blankOk) null else "Required"
        return when (it.kind) {
            Kind.INT -> {
                val n = v.toIntOrNull()
                when {
                    n == null -> "Whole number required"
                    n < it.min || n > it.max -> "Between ${it.min} and ${it.max}"
                    else -> null
                }
            }
            else -> null
        }
    }

    /** مهلة بالميلي ثانية: قيمة المستخدم إن حدّدها، وإلا الافتراضي لنوع الاتصال. */
    fun timeoutMs(default: Int): Int = int("connect_timeout").let { if (it > 0) it * 1000 else default }
}
