package com.tamaa.isilevpn

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.util.Locale

/** صفحة Speed test: مقياس، ثم رفع ← تحميل ← ping، وفي الأخير مستطيل النتائج مع تقييم الاستخدامات. */
class SpeedTestPage(private val act: Activity, private val root: View) {
    private val gauge: SpeedGauge = root.findViewById(R.id.spGauge)
    private val phase: TextView = root.findViewById(R.id.spPhase)
    private val error: TextView = root.findViewById(R.id.spError)
    private val mode: TextView = root.findViewById(R.id.spMode)
    private val start: MaterialButton = root.findViewById(R.id.spStart)
    private val results: View = root.findViewById(R.id.spResults)
    private val resDown: TextView = root.findViewById(R.id.spResDown)
    private val resUp: TextView = root.findViewById(R.id.spResUp)
    private val resPing: TextView = root.findViewById(R.id.spResPing)
    private val resJitter: TextView = root.findViewById(R.id.spResJitter)
    private val ratings: LinearLayout = root.findViewById(R.id.spRatings)
    private val ratingsBlock: View = root.findViewById(R.id.spRatingsBlock)

    private var req = 0
    private var token: SpeedTest.Token? = null
    private var viaAtStart = false
    val running get() = token != null

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density + 0.5f).toInt()
    private fun col(id: Int) = ContextCompat.getColor(act, id)
    private fun ui(id: Int, block: () -> Unit) {
        act.runOnUiThread { if (id == req && !act.isDestroyed) block() }
    }

    init {
        gauge.setScale(SpeedGauge.MBPS, "Mbps", R.color.accent)
        start.setOnClickListener { if (running) stop() else begin() }
        Tr.view(root); Tr.align(root)
        updateMode()
    }

    private fun updateMode() {
        mode.text = Tr.t(
            if (Bus.state == State.CONNECTED) "Tested through the VPN tunnel"
            else "Tested on your direct connection (VPN off)"
        )
    }

    /** عند فتح الصفحة. */
    fun show() {
        updateMode()
    }

    /** عند مغادرة الصفحة أو تغيّر حالة الاتصال: يوقف أي اختبار جارٍ لأن نتائجه لم تعد صحيحة. */
    fun stop() {
        token?.cancelled = true
        token = null
        req++
        start.text = Tr.t("Start")
        phase.text = ""
        gauge.setScale(SpeedGauge.MBPS, "Mbps", R.color.accent)
    }

    fun onState(st: State) {
        if (st == State.CONNECTING) { if (running) stop(); return }
        updateMode()
        if (running && (st == State.CONNECTED) != viaAtStart) stop()
    }

    private fun begin() {
        val id = ++req
        val tk = SpeedTest.Token()
        token = tk
        val via = Bus.state == State.CONNECTED
        viaAtStart = via
        updateMode()
        error.visibility = View.GONE
        results.visibility = View.GONE
        start.text = Tr.t("Stop")
        Thread {
            try {
                val upErr = mutableListOf<String>()
                val downErr = mutableListOf<String>()
                val pingErr = mutableListOf<String>()
                // 1) الرفع
                ui(id) { phase.text = Tr.t("Testing upload..."); gauge.setScale(SpeedGauge.MBPS, "Mbps", R.color.purple) }
                val up = tryServers(upErr, id, { it.up != null }) { s ->
                    SpeedTest.upload(s, via, tk) { v -> ui(id) { gauge.setValue(v) } }
                }
                ui(id) { gauge.setValue(up ?: 0.0) }
                Thread.sleep(500)
                // 2) التحميل
                ui(id) { phase.text = Tr.t("Testing download..."); gauge.setScale(SpeedGauge.MBPS, "Mbps", R.color.green) }
                val down = tryServers(downErr, id) { s ->
                    SpeedTest.download(s, via, tk) { v -> ui(id) { gauge.setValue(v) } }
                }
                ui(id) { gauge.setValue(down ?: 0.0) }
                Thread.sleep(500)
                // 3) الاستجابة
                ui(id) { phase.text = Tr.t("Testing ping..."); gauge.setScale(SpeedGauge.MS, "ms", R.color.accent) }
                val pj = tryServers(pingErr, id) { s ->
                    SpeedTest.ping(s, via, tk) { v -> ui(id) { gauge.setValue(v) } }
                }
                ui(id) { gauge.setValue(pj?.first ?: 0.0) }
                Thread.sleep(400)
                val r = SpeedResult(down ?: Double.NaN, up ?: Double.NaN, pj?.first ?: Double.NaN, pj?.second ?: Double.NaN)
                val errs = buildList {
                    if (up == null) add("${Tr.t("Upload")}: ${upErr.joinToString(" | ")}")
                    if (down == null) add("${Tr.t("Download")}: ${downErr.joinToString(" | ")}")
                    if (pj == null) add("${Tr.t("Ping")}: ${pingErr.joinToString(" | ")}")
                }
                ui(id) { finish(r, errs) }
            } catch (_: SpeedCancelled) {
                // أوقفه المستخدم
            } catch (_: InterruptedException) {
            } catch (e: Exception) {
                ui(id) {
                    token = null
                    start.text = Tr.t("Test again")
                    phase.text = ""
                    error.visibility = View.VISIBLE
                    error.text = "${Tr.t("Speed test failed")}: ${e.message ?: Tr.t("network error")}"
                    gauge.setScale(SpeedGauge.MBPS, "Mbps", R.color.accent)
                }
            }
        }.apply { isDaemon = true }.start()
    }

    /** يجرّب الخوادم بالترتيب حتى ينجح أحدها؛ أسباب فشل الباقي تُسجَّل في notes. */
    private fun <T> tryServers(
        notes: MutableList<String>, id: Int,
        accept: (SpeedTest.Server) -> Boolean = { true },
        f: (SpeedTest.Server) -> T
    ): T? {
        for (s in SpeedTest.SERVERS) {
            if (!accept(s)) continue
            try {
                return f(s)
            } catch (e: SpeedCancelled) {
                throw e
            } catch (e: Exception) {
                val m = "${s.name} ${e.message ?: "error"}"
                notes.add(m)
                Bus.app("Speed test: $m")
                ui(id) { gauge.setValue(0.0) }
            }
        }
        return null
    }

    private fun fmt(v: Double) = when {
        v.isNaN() -> "—"
        v >= 100 -> String.format(Locale.US, "%.0f", v)
        v >= 10 -> String.format(Locale.US, "%.1f", v)
        else -> String.format(Locale.US, "%.2f", v)
    }

    private fun finish(r: SpeedResult, errs: List<String>) {
        token = null
        start.text = Tr.t("Test again")
        gauge.setScale(SpeedGauge.MBPS, "Mbps", R.color.green)
        gauge.setValue(if (r.down.isNaN()) 0.0 else r.down)
        resDown.text = fmt(r.down)
        resUp.text = fmt(r.up)
        resPing.text = if (r.ping.isNaN()) "—" else String.format(Locale.US, "%.0f", r.ping)
        resJitter.text = if (r.jitter.isNaN()) "—" else String.format(Locale.US, "%.0f", r.jitter)
        listOf(resDown, resUp, resPing, resJitter).forEach { it.textDirection = View.TEXT_DIRECTION_LTR }
        if (errs.isEmpty()) {
            phase.text = Tr.t("Test complete")
            error.visibility = View.GONE
        } else {
            phase.text = ""
            error.visibility = View.VISIBLE
            error.textDirection = View.TEXT_DIRECTION_LTR
            error.text = "${Tr.t("Speed test failed")}\n" + errs.joinToString("\n")
        }
        ratings.removeAllViews()
        val ok = !r.down.isNaN() && !r.ping.isNaN()
        if (ok) showRatings(SpeedTest.rate(if (r.up.isNaN()) r.copy(up = 0.0) else r))
        ratingsBlock.visibility = if (ok) View.VISIBLE else View.GONE
        results.visibility = View.VISIBLE
    }

    private fun showRatings(list: List<SpeedTest.Rating>) {
        ratings.removeAllViews()
        list.forEachIndexed { i, r ->
            if (i > 0) ratings.addView(View(act).apply { setBackgroundColor(col(R.color.outline)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            val c = col(when (r.grade) {
                SpeedTest.Grade.EXCELLENT -> R.color.green
                SpeedTest.Grade.GOOD -> R.color.accent
                SpeedTest.Grade.FAIR -> R.color.amber
                SpeedTest.Grade.POOR -> R.color.red
            })
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(12), dp(4), dp(12))
            }
            row.addView(View(act).apply {
                background = ContextCompat.getDrawable(act, R.drawable.dot)?.mutate()
                backgroundTintList = android.content.res.ColorStateList.valueOf(c)
            }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(12) })
            val left = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            left.addView(TextView(act).apply {
                text = Tr.t(r.title); textSize = 15f
                setTextColor(col(R.color.text))
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            })
            if (r.detail.isNotEmpty()) left.addView(TextView(act).apply {
                text = r.detail.replace("Up to", Tr.t("Up to")).replace("Going live:", Tr.t("Going live:"))
                textSize = 12f
                setTextColor(col(R.color.text_dim))
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            })
            row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(act).apply {
                text = Tr.t(r.grade.label); textSize = 14f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(c)
            })
            ratings.addView(row)
        }
    }
}
