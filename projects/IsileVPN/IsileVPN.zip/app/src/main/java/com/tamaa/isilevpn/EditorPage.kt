package com.tamaa.isilevpn

import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/** واجهة إعداد الكونفيج: نوع واحد من الخانات، وتظهر/تختفي حسب النوع والخيارات المفعّلة. */
class EditorPage(private val ctx: Context, private val root: LinearLayout) {
    var onApply: ((Profile) -> Unit)? = null

    private var cur = Profile()
    private var kind = Kind.SSH
    private val inf = LayoutInflater.from(ctx)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    class F(val til: TextInputLayout, val et: TextInputEditText)
    class D(val til: TextInputLayout, val actv: MaterialAutoCompleteTextView)

    private fun field(hint: String, password: Boolean = false, number: Boolean = false, multiline: Boolean = false): F {
        val til = inf.inflate(R.layout.field, root, false) as TextInputLayout
        val et = til.findViewById<TextInputEditText>(R.id.edit)
        til.hint = hint
        when {
            number -> et.inputType = InputType.TYPE_CLASS_NUMBER
            password -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                til.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
            }
            multiline -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                et.minLines = 3
                et.gravity = Gravity.TOP or Gravity.START
            }
            else -> et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        return F(til, et)
    }

    private fun dropdown(hint: String, items: List<String>): D {
        val til = inf.inflate(R.layout.dropdown, root, false) as TextInputLayout
        val a = til.findViewById<MaterialAutoCompleteTextView>(R.id.edit)
        til.hint = hint
        a.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, items))
        return D(til, a)
    }

    private fun sw(label: String) = MaterialSwitch(ctx).apply {
        text = label
        Tr.keepLtr(this)
        textSize = 15f
        setPadding(dp(4), dp(6), dp(4), dp(6))
    }

    private fun section(title: String) = TextView(ctx).apply {
        text = title.uppercase()
        textSize = 12f
        setTextColor(ContextCompat.getColor(ctx, R.color.accent))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }

    private fun row(a: View, b: View, bw: Int): LinearLayout {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(8) })
        r.addView(b, LinearLayout.LayoutParams(dp(bw), WRAP))
        return r
    }

    private fun row2(a: View, b: View): LinearLayout {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(8) })
        r.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    // ---- العناصر (بترتيب ظهورها) ----
    private val heading = TextView(ctx).apply {
        textSize = 20f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val kindGroup = MaterialButtonToggleGroup(ctx).apply {
        isSingleSelection = true
        isSelectionRequired = false
    }
    /** الصف الثاني: VayDNS (مجموعة منفصلة، ويُضمن أن واحدًا فقط من الصفّين محدد). */
    private val kindGroup2 = MaterialButtonToggleGroup(ctx).apply {
        visibility = View.GONE
        isSingleSelection = true
        isSelectionRequired = false
    }
    private var kindSync = false
    private val kindBtn = HashMap<Kind, Int>()
    private val hintSocks = TextView(ctx).apply {
        text = "VayDNS: a direct connection through the VayDNS tunnel (no SSH or V2Ray)."
        textSize = 13f
        setTextColor(ContextCompat.getColor(ctx, R.color.text_dim))
    }
    private val btnPaste = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
        text = "Paste from clipboard"
        setIconResource(R.drawable.ic_paste)
    }
    private val fName = field("Config name")
    private val fHost = field("Server address")
    private val fPort = field("Port", number = true)
    private val rowHostPort = row(fHost.til, fPort.til, 110)
    private val swAuth = sw("Authentication (username & password)")
    private val fUser = field("Username")
    private val fPass = field("Password", password = true)
    private val fSecret = field("UUID")
    private val secPayload = section("Transport")
    private val swWs = sw("WebSocket")
    private val swSlow = sw("SlowDNS")
    private val swVay = sw("VayDNS")
    // ---- VayDNS (النوع المباشر): النقل، المحلّل، النطاق، المفتاح، وما يمرّره الخادم ----
    private val dTransport = dropdown("DNS transport", listOf("UDP", "DoT", "DoH"))
    private val vResolver = field("UDP resolver").also { it.til.helperText = "e.g. 8.8.8.8:53" }
    private val vDomain = field("Tunnel domain")
    private val vKey = field("Server public key")
    private val dForward = dropdown("What the server forwards to", listOf("SOCKS5 proxy"))
    private val fDnsResolver = field("DNS resolver (IP:port)").also { it.til.helperText = "e.g. 8.8.8.8:53" }
    private val fDnsDomain = field("Tunnel domain (NS)")
    private val fDnsKey = field("Server public key (hex)")
    private val fDnsListen = field("Local listener (optional)").also {
        it.til.helperText = "e.g. 127.0.0.1:7000. Leave empty for an automatic port"
    }
    private val fDnsRecord = field("Record type (optional)").also {
        it.til.helperText = "txt, cname, null, a, aaaa, mx, ns, srv, caa. Leave empty for the default"
    }
    private val swDnsCompat = sw("dnstt compatibility mode")
    // ---- VayDNS: الإعدادات المتقدمة (فارغ = القيمة الافتراضية للمحرك) ----
    private val btnAdv = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
        text = "Show advanced settings"
    }
    private var advOpen = false
    private val vIdle = field("Idle timeout (s)", number = true)
    private val vKeepalive = field("Keepalive (s)", number = true)
    private val vMaxQname = field("Max QNAME length", number = true)
    private val vMaxLabels = field("Max labels (0 = any)", number = true)
    private val vRps = field("Queries per second (0 = unlimited)", number = true)
    private val vWorkers = field("UDP workers", number = true)
    private val vUdpTimeout = field("UDP timeout (ms)", number = true)
    private val vClientId = field("Client ID size", number = true)
    private val vOpenStream = field("Open stream timeout (s)", number = true)
    private val vUtls = field("TLS fingerprint (uTLS, optional)").also {
        it.til.helperText = "e.g. random, Chrome_120, Firefox_120. Used with DoH/DoT"
    }
    private val dLogLevel = dropdown("Engine log level", listOf("default", "debug", "info", "warning", "error"))
    private val vExtra = field("Extra client flags (optional)").also {
        it.til.helperText = "Passed to the engine as is, e.g. -max-streams 8"
    }
    private val rowTimers = row2(vIdle.til, vKeepalive.til)
    private val rowQ = row2(vMaxQname.til, vMaxLabels.til)
    private val rowW = row2(vWorkers.til, vUdpTimeout.til)
    private val rowC = row2(vClientId.til, vOpenStream.til)
    private var syncing = false
    private val swPayload = sw("Enable payload")
    private val fPayload = field("Payload", multiline = true).also {
        it.til.helperText = "Tags: [crlf] [host] [port] [host_port]"
    }
    private val fProxy = field("Remote proxy")
    private val fProxyPort = field("Port", number = true)
    private val rowProxy = row(fProxy.til, fProxyPort.til, 110)
    private val fPath = field("Path")
    private val fWsHost = field("Host header").also { it.til.helperText = "[host] = server address" }
    private val swTls = sw("TLS")
    private val fSni = field("SNI").also { it.til.helperText = "[host] = server address" }
    private val dTlsVer = dropdown("SNI version", listOf("Auto", "TLSv1.0", "TLSv1.1", "TLSv1.2", "TLSv1.3"))
    private val dFp = dropdown(
        "Fingerprint",
        listOf("none", "chrome", "firefox", "safari", "ios", "android", "edge", "360", "qq", "random", "randomized")
    )
    private val fAlpn = field("ALPN (e.g. h2,http/1.1)")
    private val swInsecure = sw("Allow insecure")
    private val swMux = sw("Mux")
    private val btnApply = MaterialButton(ctx).apply {
        text = "Apply"
        textSize = 16f
        cornerRadius = dp(16)
    }

    init {
        root.removeAllViews()
        Kind.values().forEach { k ->
            val b = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.id = View.generateViewId()
            b.text = k.label
            b.textSize = 13f
            b.maxLines = 1
            b.setPadding(dp(2), 0, dp(2), 0)
            b.tag = k
            kindBtn[k] = b.id
            (if (k.isSocks) kindGroup2 else kindGroup).addView(b, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        listOf(
            heading, kindGroup, kindGroup2, hintSocks, btnPaste, fName.til, rowHostPort, dTransport.til, vResolver.til, vDomain.til, vKey.til, dForward.til, swAuth, fUser.til, fPass.til, fSecret.til,
            secPayload, swWs, swSlow, swVay, fDnsResolver.til, fDnsDomain.til, fDnsKey.til, fDnsListen.til, fDnsRecord.til,
            btnAdv, swDnsCompat, rowTimers, rowQ, rowW, rowC, vRps.til, vUtls.til, dLogLevel.til, vExtra.til,
            swPayload, fPayload.til, rowProxy, fPath.til, fWsHost.til,
            swTls, fSni.til, dTlsVer.til, dFp.til, fAlpn.til, swInsecure, swMux
        ).forEach { add(it) }
        root.addView(btnApply, LinearLayout.LayoutParams(MATCH, dp(56)).apply { topMargin = dp(8); bottomMargin = dp(32) })

        val kindListener = MaterialButtonToggleGroup.OnButtonCheckedListener { g, id, checked ->
            if (kindSync) return@OnButtonCheckedListener
            if (checked) {
                kind = g.findViewById<View>(id).tag as Kind
                setKindUi(kind)
                onKindChanged()
            } else if (kindGroup.checkedButtonId == View.NO_ID && kindGroup2.checkedButtonId == View.NO_ID) {
                setKindUi(kind) // لا يُسمح بإلغاء التحديد بالضغط على الزر نفسه
            }
        }
        kindGroup.addOnButtonCheckedListener(kindListener)
        kindGroup2.addOnButtonCheckedListener(kindListener)
        val vis = { _: android.widget.CompoundButton, _: Boolean -> updateVisibility() }
        swWs.setOnCheckedChangeListener(vis)
        swPayload.setOnCheckedChangeListener(vis)
        swTls.setOnCheckedChangeListener(vis)
        swAuth.setOnCheckedChangeListener(vis)
        swSlow.setOnCheckedChangeListener { _, _ -> transportToggled(swSlow) }
        swVay.setOnCheckedChangeListener { _, _ -> transportToggled(swVay) }
        fProxy.et.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { if (!syncing) updateVisibility() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        btnPaste.setOnClickListener { pasteLink() }
        btnAdv.setOnClickListener { advOpen = !advOpen; updateVisibility() }
        dTransport.actv.setOnItemClickListener { _, _, _, _ -> updateResolverHints() }
        btnApply.setOnClickListener { apply() }
        Tr.view(root); Tr.align(root)
    }

    private fun setKindUi(k: Kind) {
        // خيار VayDNS المنفرد محذوف من القائمة؛ يظهر فقط عند تعديل كونفيج قديم من هذا النوع كي لا يتعطل
        show(kindGroup2, k.isSocks)
        kindSync = true
        if (k.isSocks) {
            kindGroup.clearChecked()
            kindGroup2.check(kindBtn[k]!!)
        } else {
            kindGroup2.clearChecked()
            kindGroup.check(kindBtn[k]!!)
        }
        kindSync = false
    }

    private fun add(v: View) {
        root.addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            bottomMargin = dp(if (v === secPayload || v === kindGroup) 4 else 12)
            if (v === secPayload) topMargin = dp(8)
        })
    }

    private fun onKindChanged() {
        fSecret.til.hint = if (kind == Kind.TROJAN) Tr.t("Password") else "UUID"
        val t = fPort.et.text.toString().trim()
        if (t.isEmpty() || t == "22" || t == "443") fPort.et.setText(if (kind.isSsh) "22" else "443")
        updateVisibility()
    }

    private fun show(v: View, on: Boolean) { v.visibility = if (on) View.VISIBLE else View.GONE }

    private fun enable(v: View, on: Boolean) { v.isEnabled = on; v.alpha = if (on) 1f else 0.4f }

    /** تشغيل أحد بروتوكولي DNS يطفئ الآخر وWebSocket/Payload/Proxy (يبقى TLS/SNI متاحًا فوق النفق). */
    private fun transportToggled(src: View) {
        if (syncing) return
        syncing = true
        if ((src === swSlow && swSlow.isChecked) || (src === swVay && swVay.isChecked)) {
            if (src === swSlow) swVay.isChecked = false else swSlow.isChecked = false
            swWs.isChecked = false
            swPayload.isChecked = false
            fProxy.et.setText("")
        }
        syncing = false
        updateVisibility()
    }

    private fun updateVisibility() {
        val ssh = kind.isSsh
        val sk = kind.isSocks
        val tls = swTls.isChecked && !sk
        show(btnPaste, true)
        show(hintSocks, sk)
        val dnsOn = sk || (ssh && (swSlow.isChecked || swVay.isChecked))
        val vayOn = sk || (ssh && swVay.isChecked)
        // أي خيار نقل عادي مفعّل يمنع تشغيل بروتوكولي DNS
        val plainOn = ssh && (swWs.isChecked || swPayload.isChecked || fProxy.et.text.toString().isNotBlank())
        show(rowHostPort, !dnsOn)
        show(swAuth, sk)
        show(fUser.til, ssh || (sk && swAuth.isChecked)); show(fPass.til, ssh || (sk && swAuth.isChecked))
        show(fSecret.til, !ssh && !sk)
        show(secPayload, ssh)
        show(swSlow, ssh); show(swVay, ssh)
        enable(swSlow, swSlow.isChecked || (!swVay.isChecked && !plainOn))
        enable(swVay, swVay.isChecked || (!swSlow.isChecked && !plainOn))
        enable(swWs, !dnsOn); enable(swPayload, !dnsOn)
        show(dTransport.til, vayOn); show(vResolver.til, sk); show(vDomain.til, sk); show(vKey.til, sk); show(dForward.til, sk)
        show(fDnsResolver.til, dnsOn && !sk); show(fDnsDomain.til, dnsOn && !sk); show(fDnsKey.til, dnsOn && !sk)
        show(fDnsListen.til, dnsOn)
        val adv = vayOn && advOpen
        show(btnAdv, vayOn)
        btnAdv.text = Tr.t(if (advOpen) "Hide advanced settings" else "Show advanced settings")
        show(fDnsRecord.til, adv); show(swDnsCompat, adv)
        show(rowTimers, adv); show(rowQ, adv); show(rowW, adv); show(rowC, adv)
        show(vRps.til, adv); show(vUtls.til, adv); show(dLogLevel.til, adv); show(vExtra.til, adv)
        updateResolverHints()
        show(swPayload, ssh)
        show(fPayload.til, ssh && !dnsOn && swPayload.isChecked)
        show(rowProxy, ssh && !dnsOn)
        show(fPath.til, !ssh && !sk && swWs.isChecked)
        show(fWsHost.til, !ssh && !sk && swWs.isChecked)
        show(swTls, !sk)
        show(fSni.til, tls)
        show(dTlsVer.til, ssh && tls)
        show(dFp.til, !ssh && !sk && tls)
        show(fAlpn.til, !ssh && !sk && tls)
        show(swInsecure, tls)
        show(swMux, !ssh && !sk)
    }

    private fun transportKey(): String = when (dTransport.actv.text.toString().trim().lowercase()) {
        "dot" -> "dot"
        "doh" -> "doh"
        else -> "udp"
    }

    /** يغيّر تسمية حقل المحلّل حسب نوع النقل (UDP / DoT / DoH) لحقلي VayDNS المباشر وSSH. */
    private fun updateResolverHints() {
        val (label, help) = when (transportKey()) {
            "dot" -> "DoT resolver" to "e.g. 1.1.1.1:853 or dns.google:853"
            "doh" -> "DoH URL" to "e.g. https://dns.google/dns-query"
            else -> "UDP resolver" to "e.g. 8.8.8.8:53"
        }
        val vayDirect = kind.isSocks || swVay.isChecked
        vResolver.til.hint = Tr.t(label); vResolver.til.helperText = Tr.t(help)
        if (vayDirect) { fDnsResolver.til.hint = Tr.t(label); fDnsResolver.til.helperText = Tr.t(help) }
        else { fDnsResolver.til.hint = Tr.t("DNS resolver (IP:port)"); fDnsResolver.til.helperText = Tr.t("e.g. 8.8.8.8:53") }
    }

    /** يملأ الواجهة من كونفيج موجود أو جديد. */
    fun bind(p: Profile, existing: Boolean) {
        heading.text = Tr.t(if (existing) "Edit config" else "New config")
        fill(p)
    }

    private fun fill(p: Profile) {
        cur = p.copy()
        kind = p.kind
        setKindUi(p.kind)
        fSecret.til.hint = if (p.kind == Kind.TROJAN) Tr.t("Password") else "UUID"
        fName.et.setText(p.name)
        fHost.et.setText(if (p.isDns) "" else p.host)
        fPort.et.setText(if (p.isDns) "22" else p.port.toString())
        swAuth.isChecked = p.kind.isSocks && p.auth
        fUser.et.setText(p.user)
        fPass.et.setText(p.pass)
        fSecret.et.setText(p.secret)
        swWs.isChecked = p.ws
        swPayload.isChecked = p.payloadOn
        fPayload.et.setText(p.payload)
        fProxy.et.setText(p.proxyHost)
        fProxyPort.et.setText(p.proxyPort.toString())
        fPath.et.setText(p.wsPath)
        fWsHost.et.setText(p.wsHost)
        swTls.isChecked = p.tls
        fSni.et.setText(p.sni)
        dTlsVer.actv.setText(p.tlsVersion.ifEmpty { "Auto" }, false)
        dFp.actv.setText(p.fingerprint.ifEmpty { "none" }, false)
        fAlpn.et.setText(p.alpn)
        swInsecure.isChecked = p.insecure
        swMux.isChecked = p.mux
        // نفق DNS: يُحمَّل بعد باقي الخيارات ويُصفَّر كل ما يتعارض معه (حتى لو جاء كونفيج قديم/مستورد متضارب)
        syncing = true
        swSlow.isChecked = p.kind.isSsh && p.isDns && p.dns == Dns.SLOW
        swVay.isChecked = p.kind.isSsh && p.isDns && p.dns == Dns.VAY
        if (p.isDns) {
            swWs.isChecked = false; swPayload.isChecked = false
            fProxy.et.setText("")
        }
        dTransport.actv.setText(when (p.dnsTransport.lowercase()) { "dot" -> "DoT"; "doh" -> "DoH"; else -> "UDP" }, false)
        dForward.actv.setText("SOCKS5 proxy", false)
        vResolver.et.setText(p.dnsResolver)
        vDomain.et.setText(if (p.isDns) p.host else "")
        vKey.et.setText(p.dnsPubkey)
        fDnsResolver.et.setText(p.dnsResolver)
        fDnsListen.et.setText(p.dnsListen)
        fDnsDomain.et.setText(if (p.isDns) p.host else "")
        fDnsKey.et.setText(p.dnsPubkey)
        fDnsRecord.et.setText(p.dnsRecord)
        swDnsCompat.isChecked = p.dnsCompat
        vIdle.et.setText(p.dnsIdle); vKeepalive.et.setText(p.dnsKeepalive)
        vMaxQname.et.setText(p.dnsMaxQname); vMaxLabels.et.setText(p.dnsMaxLabels)
        vRps.et.setText(p.dnsRps); vWorkers.et.setText(p.dnsWorkers)
        vUdpTimeout.et.setText(p.dnsUdpTimeout); vClientId.et.setText(p.dnsClientId)
        vOpenStream.et.setText(p.dnsOpenStream); vUtls.et.setText(p.dnsUtls)
        dLogLevel.actv.setText(p.dnsLogLevel.ifEmpty { "default" }, false)
        vExtra.et.setText(p.dnsExtra)
        // نفتح "المتقدمة" تلقائيًا إن كان في الكونفيج أي خيار متقدم مضبوط حتى لا يختبئ عن المستخدم
        advOpen = p.dnsCompat || p.dnsRecord.isNotEmpty() || listOf(
            p.dnsIdle, p.dnsKeepalive, p.dnsUdpTimeout, p.dnsOpenStream, p.dnsWorkers, p.dnsRps,
            p.dnsMaxQname, p.dnsMaxLabels, p.dnsClientId, p.dnsUtls, p.dnsLogLevel, p.dnsExtra
        ).any { it.isNotEmpty() }
        syncing = false
        listOf(fName, fHost, fPort, fUser, fPass, fSecret, fDnsResolver, fDnsDomain, fDnsKey, fDnsListen, vResolver, vDomain, vKey)
            .forEach { it.til.error = null }
        updateVisibility()
    }

    private fun pasteLink() {
        val t = ctx.getSystemService(ClipboardManager::class.java)
            .primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        try {
            if (t.isBlank()) throw IllegalArgumentException(Tr.t("Clipboard is empty"))
            val p = LinkParser.parse(t)
            if (p.name.isBlank()) p.name = fName.et.text.toString().trim()
            p.uid = cur.uid
            if (LinkParser.isDnsCommand(t)) {
                // أمر vaydns-client أثناء اختيار VayDNS: يُملأ الكونفيج كنوع VayDNS
                if (kind.isSocks && p.dns == Dns.VAY) p.kind = Kind.SOCKS
                p.user = txt(fUser)
                p.pass = fPass.et.text.toString()
                p.auth = p.kind.isSocks && swAuth.isChecked
            }
            fill(p)
            Toast.makeText(ctx, Tr.t("Config imported"), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, e.message ?: Tr.t("Invalid config"), Toast.LENGTH_LONG).show()
        }
    }

    private fun txt(f: F) = f.et.text.toString().trim()

    private fun apply() {
        listOf(fName, fHost, fPort, fUser, fPass, fSecret, fDnsResolver, fDnsDomain, fDnsKey, fDnsListen, vResolver, vDomain, vKey)
            .forEach { it.til.error = null }
        val sk = kind.isSocks
        val fR = if (sk) vResolver else fDnsResolver
        val fD = if (sk) vDomain else fDnsDomain
        val fK = if (sk) vKey else fDnsKey
        val dnsOn = sk || (kind.isSsh && (swSlow.isChecked || swVay.isChecked))
        val dnsMode = if (!dnsOn) "" else if (!sk && swSlow.isChecked) Dns.SLOW else Dns.VAY
        val domain = txt(fD)
        val listen = Dns.listen(txt(fDnsListen))
        val vayMode = dnsMode == Dns.VAY
        val transport = if (vayMode) transportKey() else "udp"
        val resolver = if (vayMode) VayDnsSpec.normalizeResolver(transport, txt(fR)) else Dns.resolver(txt(fR))
        val host = if (dnsOn) domain else txt(fHost)
        val port = txt(fPort).toIntOrNull()
        var bad: F? = null
        fun need(fail: Boolean, f: F, msg: String) {
            if (fail && bad == null) { f.til.error = Tr.t(msg); bad = f }
        }
        if (dnsOn) {
            need(resolver == null, fR, if (vayMode) VayDnsSpec.resolverError(transport) else "Enter an IPv4 address, e.g. 8.8.8.8:53")
            need(!Dns.validDomain(domain), fD, "Enter a valid domain")
            need(!Dns.validKey(txt(fK)), fK, "64 hex characters")
            need(listen == null, fDnsListen, "Use a port or 127.0.0.1:port")
        } else {
            need(host.isEmpty(), fHost, "Required")
            need(port == null || port !in 1..65535, fPort, "1-65535")
        }
        if (kind.isSsh || (sk && swAuth.isChecked)) {
            need(txt(fUser).isEmpty(), fUser, "Required")
            need(fPass.et.text.isNullOrEmpty(), fPass, "Required")
        } else {
            need(txt(fSecret).isEmpty(), fSecret, "Required")
        }
        bad?.let { it.et.requestFocus(); return }

        val fp = dFp.actv.text.toString().trim().let { if (it == "none") "" else it }
        val p = cur.copy(
            kind = kind,
            name = txt(fName).ifEmpty {
                "${if (sk) "VayDNS" else if (dnsOn) (if (dnsMode == Dns.SLOW) "SlowDNS" else "VayDNS") else kind.label} $host"
            },
            host = host,
            port = if (dnsOn) 22 else (port ?: 22),
            user = if (sk && !swAuth.isChecked) "" else txt(fUser),
            pass = if (sk && !swAuth.isChecked) "" else fPass.et.text.toString(),
            auth = sk && swAuth.isChecked,
            secret = txt(fSecret),
            ws = !dnsOn && swWs.isChecked,
            payloadOn = !dnsOn && swPayload.isChecked,
            payload = fPayload.et.text.toString().ifEmpty { DEFAULT_PAYLOAD },
            proxyHost = if (dnsOn) "" else txt(fProxy),
            proxyPort = txt(fProxyPort).toIntOrNull()?.takeIf { it in 1..65535 } ?: 8080,
            wsPath = txt(fPath).ifEmpty { "/" },
            wsHost = txt(fWsHost),
            tls = swTls.isChecked && !sk,
            sni = txt(fSni),
            tlsVersion = dTlsVer.actv.text.toString().ifEmpty { "Auto" },
            fingerprint = fp,
            alpn = txt(fAlpn),
            insecure = swInsecure.isChecked && !sk,
            mux = swMux.isChecked && !sk,
            dns = dnsMode,
            dnsResolver = resolver ?: txt(fR),
            dnsPubkey = txt(fK).lowercase(),
            dnsTransport = transport,
            forward = "socks5",
            dnsRecord = if (vayMode) txt(fDnsRecord).lowercase() else "",
            dnsCompat = vayMode && swDnsCompat.isChecked,
            dnsListen = if (dnsOn) (listen ?: "") else "",
            dnsIdle = if (vayMode) txt(vIdle) else "",
            dnsKeepalive = if (vayMode) txt(vKeepalive) else "",
            dnsUdpTimeout = if (vayMode) txt(vUdpTimeout) else "",
            dnsOpenStream = if (vayMode) txt(vOpenStream) else "",
            dnsWorkers = if (vayMode) txt(vWorkers) else "",
            dnsRps = if (vayMode) txt(vRps) else "",
            dnsMaxQname = if (vayMode) txt(vMaxQname) else "",
            dnsMaxLabels = if (vayMode) txt(vMaxLabels) else "",
            dnsClientId = if (vayMode) txt(vClientId) else "",
            dnsUtls = if (vayMode) txt(vUtls) else "",
            dnsLogLevel = if (vayMode) dLogLevel.actv.text.toString().trim().lowercase().let { if (it == "default") "" else it } else "",
            dnsExtra = if (vayMode) txt(vExtra) else ""
        )
        if (vayMode) {
            // تحقق شامل من كل خيارات VayDNS قبل الحفظ، برسالة مفهومة
            try { VayDnsSpec.fromProfile(p) } catch (e: java.io.IOException) {
                if (!advOpen) { advOpen = true; updateVisibility() }
                Toast.makeText(ctx, e.message ?: Tr.t("Invalid config"), Toast.LENGTH_LONG).show()
                return
            }
        }
        onApply?.invoke(p)
    }
}
