package com.tamaa.isilevpn

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.Process

/** تطبيقات الاتصال والرسائل: تُستثنى من النفق دائمًا كي لا تُقطع المكالمات (ولا يمكن تفعيلها من صفحة المراقبة). */
object CallApps {
    fun packages(ctx: Context): Set<String> {
        val pkgs = linkedSetOf(
            "com.android.phone", "com.android.server.telecom", "com.android.incallui",
            "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
            "com.samsung.android.incallui", "com.android.providers.telephony", "com.android.stk",
            "com.android.ims", "com.qualcomm.qti.ims", "com.qualcomm.qtil.ims", "com.mediatek.ims",
            "org.codeaurora.ims", "com.miui.voip", "com.android.mms", "com.android.cellbroadcastreceiver"
        )
        try {
            ctx.getSystemService(android.telecom.TelecomManager::class.java)?.defaultDialerPackage?.let { pkgs += it }
        } catch (_: Throwable) {}
        try {
            val i = Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:123"))
            ctx.packageManager.queryIntentActivities(i, 0).forEach { pkgs += it.activityInfo.packageName }
        } catch (_: Throwable) {}
        pkgs.remove(ctx.packageName)
        return pkgs
    }
}

/** التطبيقات التي عطّلها المستخدم: تخرج بإنترنت الجهاز مباشرة بدل النفق. تُطبَّق عند كل اتصال. */
object AppRules {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("isile_apps", Context.MODE_PRIVATE)

    @Volatile private var off: Set<String>? = null

    fun disabled(c: Context): Set<String> =
        off ?: (sp(c).getStringSet("off", emptySet()) ?: emptySet()).toSet().also { off = it }

    fun isEnabled(c: Context, pkg: String) = pkg !in disabled(c)

    /** يعيّن حالة مجموعة تطبيقات دفعة واحدة. */
    fun set(c: Context, pkgs: Collection<String>, enabled: Boolean) {
        val n = disabled(c).toMutableSet()
        if (enabled) n.removeAll(pkgs.toSet()) else n.addAll(pkgs)
        off = n
        sp(c).edit().putStringSet("off", n).apply()
    }

    /** يستثني التطبيقات المعطّلة من واجهة VPN المبنيّة. */
    fun applyTo(c: Context, b: VpnService.Builder): Int {
        var n = 0
        for (p in disabled(c)) {
            if (p == c.packageName) continue
            try { b.addDisallowedApplication(p); n++ } catch (_: Exception) { /* غير مثبّت */ }
        }
        return n
    }
}

/**
 * استهلاك كل تطبيق منذ بدء الاتصال، من إحصاءات النظام (NetworkStatsManager).
 * يحتاج إذن "الوصول إلى بيانات الاستخدام" الذي يمنحه المستخدم يدويًا. الأرقام من عدّاد النظام لكل تطبيق
 * (واي فاي + بيانات الجوال)، وهي تقريبية ولا تفصل ما مرّ بالنفق عمّا خرج مباشرة.
 */
object AppUsage {
    fun hasAccess(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) { false }

    /** uid -> [تنزيل، رفع] بالبايت بين [since] والآن. فارغة إن لم يُمنح الإذن. */
    fun query(c: Context, since: Long): Map<Int, LongArray> {
        val out = HashMap<Int, LongArray>()
        if (since <= 0 || !hasAccess(c)) return out
        val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as? NetworkStatsManager ?: return out
        val now = System.currentTimeMillis()
        for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
            try {
                val st = nsm.querySummary(type, null, since, now)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    val a = out.getOrPut(b.uid) { LongArray(2) }
                    a[0] += b.rxBytes; a[1] += b.txBytes
                }
                st.close()
            } catch (_: Throwable) { /* نوع الشبكة غير متاح أو لا يملك الإذن */ }
        }
        return out
    }
}
