package com.tamaa.isilevpn

import android.content.Context
import java.io.DataInputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI

/**
 * إعدادات محرك VayDNS (الملف التنفيذي libvaydns.so = vaydns-client).
 * كل الخيارات هنا تم التحقق من وجودها داخل الملف التنفيذي المرفق نفسه (نصوص المساعدة ورسائل الأخطاء)،
 * ولا يوجد أي خيار مخترَع. الخيار الفارغ = لا نمرّره، فيستعمل المحرك قيمته الافتراضية.
 */
class VayDnsSpec(
    val transport: String,          // udp | dot | doh
    var resolver: String,           // udp/dot: host:port ، doh: https://...
    val pubkey: String,             // 64 hex
    val domain: String,
    var listen: String,             // 127.0.0.1:port (يُحدَّد قبل التشغيل)
    val recordType: String,
    val compat: Boolean,
    val idleSec: Int?,
    val keepaliveSec: Int?,
    val udpTimeoutMs: Int?,
    val openStreamSec: Int?,
    val udpWorkers: Int?,
    val rps: Int?,
    val maxQname: Int?,
    val maxLabels: Int?,
    val clientId: Int?,
    val utls: String,
    val logLevel: String,
    val extra: List<String>
) {
    val port: Int get() = listen.substringAfterLast(':').toInt()

    /** سطر الأوامر الكامل (المفتاح العام يُمرَّر للمحرك فقط ولا يُكتب في السجلات). */
    fun args(bin: String): List<String> {
        val a = ArrayList<String>()
        a += bin
        a += when (transport) { "dot" -> "-dot"; "doh" -> "-doh"; else -> "-udp" }
        a += resolver
        a += listOf("-pubkey", pubkey, "-domain", domain, "-listen", listen)
        if (recordType.isNotEmpty()) a += listOf("-record-type", recordType)
        if (compat) a += "-dnstt-compat"
        idleSec?.let { a += listOf("-idle-timeout", "${it}s") }
        keepaliveSec?.let { a += listOf("-keepalive", "${it}s") }
        udpTimeoutMs?.let { a += listOf("-udp-timeout", "${it}ms") }
        openStreamSec?.let { a += listOf("-open-stream-timeout", "${it}s") }
        udpWorkers?.let { a += listOf("-udp-workers", it.toString()) }
        rps?.let { a += listOf("-rps", it.toString()) }
        maxQname?.let { a += listOf("-max-qname-len", it.toString()) }
        maxLabels?.let { a += listOf("-max-num-labels", it.toString()) }
        clientId?.let { a += listOf("-clientid-size", it.toString()) }
        if (utls.isNotEmpty()) a += listOf("-utls", utls)
        if (logLevel.isNotEmpty()) a += listOf("-log-level", logLevel)
        a += extra
        return a
    }

    /** وصف آمن للسجل (بدون المفتاح). */
    fun describe(): String = buildString {
        append(transport.uppercase()).append(' ').append(resolver)
        append(", domain ").append(domain)
        append(", listen ").append(listen)
        if (recordType.isNotEmpty()) append(", record ").append(recordType)
        if (compat) append(", dnstt-compat")
        idleSec?.let { append(", idle ${it}s") }
        keepaliveSec?.let { append(", keepalive ${it}s") }
        udpTimeoutMs?.let { append(", udp-timeout ${it}ms") }
        openStreamSec?.let { append(", open-stream ${it}s") }
        udpWorkers?.let { append(", workers $it") }
        rps?.let { append(", rps $it") }
        maxQname?.let { append(", max-qname $it") }
        maxLabels?.let { append(", max-labels $it") }
        clientId?.let { append(", clientid-size $it") }
        if (utls.isNotEmpty()) append(", utls ").append(utls)
        if (logLevel.isNotEmpty()) append(", log-level ").append(logLevel)
        if (extra.isNotEmpty()) append(", extra: ").append(extra.joinToString(" "))
    }

    companion object {
        val TRANSPORTS = listOf("udp", "dot", "doh")
        /** من رسالة الخطأ داخل المحرك: txt, cname, null, a, aaaa, mx, ns, srv, caa */
        val RECORDS = listOf("txt", "cname", "null", "a", "aaaa", "mx", "ns", "srv", "caa")
        val LOG_LEVELS = listOf("debug", "info", "warning", "error")

        /** خيارات يديرها التطبيق: لا يُسمح بتكرارها في "Extra client flags". */
        private val MANAGED = setOf(
            "udp", "dot", "doh", "pubkey", "pubkey-file", "domain", "listen", "record-type", "dnstt-compat",
            "idle-timeout", "keepalive", "udp-timeout", "open-stream-timeout", "udp-workers", "rps",
            "max-qname-len", "max-num-labels", "clientid-size", "utls", "log-level"
        )

        private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

        private fun isIpv4(s: String) = ipv4.matches(s)
        private fun ipv4Ok(s: String) = s.split(".").all { it.toInt() in 0..255 }

        /** "host", "host:port" أو "[v6]:port" -> "host:port" مطبَّع، أو null. */
        private fun hostPort(raw: String, defPort: Int): String? {
            val s = raw.trim()
            if (s.isEmpty()) return null
            val host: String
            val portTxt: String
            if (s.startsWith("[")) {
                val end = s.indexOf(']')
                if (end < 0) return null
                host = s.substring(0, end + 1)
                val rest = s.substring(end + 1)
                if (rest.isNotEmpty() && !rest.startsWith(":")) return null
                portTxt = rest.removePrefix(":")
                if (!Regex("^\\[[0-9A-Fa-f:.]+\\]$").matches(host)) return null
            } else {
                val colons = s.count { it == ':' }
                if (colons > 1) return null // IPv6 يجب أن يكون بين أقواس
                host = s.substringBefore(':')
                portTxt = if (colons == 1) s.substringAfter(':') else ""
                val ok = if (isIpv4(host)) ipv4Ok(host) else Dns.validDomain(host)
                if (!ok) return null
            }
            val port = if (portTxt.isEmpty()) defPort else (portTxt.toIntOrNull() ?: return null)
            if (port !in 1..65535) return null
            return "$host:$port"
        }

        /** يطبّع عنوان المحلّل حسب نوع النقل؛ null إن كان غير صالح. */
        fun normalizeResolver(transport: String, raw: String): String? = when (transport) {
            "udp" -> hostPort(raw, 53)
            "dot" -> hostPort(raw, 853)
            "doh" -> runCatching {
                val u = URI(raw.trim())
                val ok = u.scheme.equals("https", true) && !u.host.isNullOrEmpty() && (u.port == -1 || u.port in 1..65535)
                if (ok) raw.trim() else null
            }.getOrNull()
            else -> null
        }

        fun resolverError(transport: String): String = when (transport) {
            "udp" -> "UDP resolver must be an IP or host with optional port, e.g. 8.8.8.8:53"
            "dot" -> "DoT resolver must be host:port, e.g. 1.1.1.1:853 or dns.google:853"
            "doh" -> "DoH resolver must be an https URL, e.g. https://dns.google/dns-query"
            else -> "Unknown DNS transport: $transport"
        }

        /** عدد صحيح اختياري: فارغ = غير محدد؛ غير ذلك يجب أن يكون ضمن النطاق وإلا استثناء مفهوم. */
        private fun num(label: String, raw: String, min: Int, max: Int): Int? {
            val s = raw.trim()
            if (s.isEmpty()) return null
            val n = s.toIntOrNull() ?: throw IOException("$label must be a whole number")
            if (n < min || n > max) throw IOException("$label must be between $min and $max")
            return n
        }

        private fun tokens(raw: String): List<String> {
            val t = raw.trim()
            if (t.isEmpty()) return emptyList()
            val out = ArrayList<String>()
            val cur = StringBuilder()
            var q: Char? = null
            var has = false
            for (ch in t.replace("\r", " ").replace("\n", " ")) {
                when {
                    q != null -> if (ch == q) q = null else cur.append(ch)
                    ch == '"' || ch == '\'' -> { q = ch; has = true }
                    ch.isWhitespace() -> if (has || cur.isNotEmpty()) { out += cur.toString(); cur.clear(); has = false }
                    else -> cur.append(ch)
                }
            }
            if (has || cur.isNotEmpty()) out += cur.toString()
            return out
        }

        /** يبني الإعدادات من الكونفيج ويتحقق منها كلها. يرمي IOException برسالة مفهومة عند أي خطأ. */
        fun fromProfile(p: Profile): VayDnsSpec {
            val transport = p.dnsTransport.trim().lowercase().ifEmpty { "udp" }
            if (transport !in TRANSPORTS) throw IOException("Unknown DNS transport: ${p.dnsTransport}")
            val resolver = normalizeResolver(transport, p.dnsResolver) ?: throw IOException(resolverError(transport))
            val key = p.dnsPubkey.trim()
            if (!Dns.validKey(key)) throw IOException("Public key must be exactly 64 hex characters (got ${key.length})")
            val domain = p.host.trim()
            if (!Dns.validDomain(domain)) throw IOException("Invalid tunnel domain: $domain")
            val listen = Dns.listen(p.dnsListen) ?: throw IOException("Local listener must be a port or 127.0.0.1:port")
            val record = p.dnsRecord.trim().lowercase()
            if (record.isNotEmpty() && record !in RECORDS) throw IOException("Record type must be one of: ${RECORDS.joinToString(", ")}")

            val idle = num("Idle timeout", p.dnsIdle, 1, 86400)
            val keep = num("Keepalive", p.dnsKeepalive, 1, 86400)
            // المحرك نفسه يرفض keepalive >= idle-timeout، فنرفضه قبل التشغيل برسالة أوضح
            if (idle != null && keep != null && keep >= idle) throw IOException("Keepalive ($keep s) must be smaller than the idle timeout ($idle s)")
            val udpTimeout = num("UDP timeout", p.dnsUdpTimeout, 1, 600000)
            val openStream = num("Open stream timeout", p.dnsOpenStream, 1, 3600)
            val workers = num("UDP workers", p.dnsWorkers, 1, 10000)
            val rps = num("Queries per second limit", p.dnsRps, 0, 1000000)
            val maxQ = num("Max QNAME length", p.dnsMaxQname, 0, 253)
            val maxL = num("Max labels", p.dnsMaxLabels, 0, 127)
            val cid = num("Client ID size", p.dnsClientId, 1, 255)

            val utls = p.dnsUtls.trim()
            if (utls.isNotEmpty() && !Regex("^[A-Za-z0-9_*,.\\-]+$").matches(utls))
                throw IOException("TLS fingerprint contains invalid characters (use e.g. random, Chrome_120, Firefox_120)")
            val level = p.dnsLogLevel.trim().lowercase()
            if (level.isNotEmpty() && level !in LOG_LEVELS) throw IOException("Log level must be one of: ${LOG_LEVELS.joinToString(", ")}")

            val extra = tokens(p.dnsExtra)
            if (extra.isNotEmpty() && !extra[0].startsWith("-")) throw IOException("Extra client flags must start with a flag, e.g. -max-streams 8")
            for (t in extra) {
                if (t.startsWith("-") && t != "-") {
                    val n = t.trimStart('-').substringBefore('=')
                    if (n in MANAGED) throw IOException("Extra flag -$n is already set by the app, use its own field")
                }
            }
            return VayDnsSpec(
                transport, resolver, key.lowercase(), domain, if (listen.isEmpty()) "" else listen,
                record, p.dnsCompat, idle, keep, udpTimeout, openStream, workers, rps, maxQ, maxL, cid, utls, level, extra
            )
        }
    }
}

/**
 * مدير عملية VayDNS: تشغيل الملف التنفيذي كعملية، التقاط مخرجاته، انتظار المنفذ المحلي، وفحص النفق فعليًا.
 * لا يُعلن النجاح لمجرد أن العملية حيّة: يجب أن يُفتح المنفذ المحلي ثم يردّ الخادم عبر النفق.
 */
class VayDnsRunner(private val ctx: Context, val spec: VayDnsSpec) {
    enum class Ready { IDLE, STARTING, LISTENING, READY, FAILED, STOPPED }

    @Volatile var ready = Ready.IDLE
        private set
    @Volatile var onExit: ((Int) -> Unit)? = null
    @Volatile private var proc: Process? = null
    @Volatile private var exitCode: Int? = null
    @Volatile private var stopping = false
    private val tail = ArrayDeque<String>()

    companion object {
        private val GATE = Any()
        @Volatile private var running: VayDnsRunner? = null
        private const val KEEP_LINES = 200
    }

    val port: Int get() = spec.port

    /** آخر [n] سطر من مخرجات المحرك (stdout+stderr). */
    fun lastLines(n: Int = 8): String = synchronized(tail) { tail.toList().takeLast(n).joinToString("\n") }

    private fun lastLine(): String? = synchronized(tail) { tail.lastOrNull() }

    /** يحوّل اسم مضيف المحلّل (UDP) إلى IP قبل التشغيل؛ العناوين الرقمية تُترك كما هي. */
    fun pickIp(hostPort: String): String {
        val host = hostPort.substringBeforeLast(':')
        val port = hostPort.substringAfterLast(':')
        if (host.startsWith("[") || host.all { it.isDigit() || it == '.' }) return hostPort
        Bus.log("VayDNS: resolving resolver host $host")
        val all = try { InetAddress.getAllByName(host) } catch (e: Exception) {
            throw IOException("Cannot resolve DNS resolver host $host: ${e.message}")
        }
        val ip = all.firstOrNull { it.address.size == 4 } ?: all.first()
        val txt = ip.hostAddress ?: throw IOException("Cannot resolve DNS resolver host $host")
        Bus.log("VayDNS: resolver $host -> $txt")
        return if (ip.address.size == 16) "[$txt]:$port" else "$txt:$port"
    }

    private fun freePort(): Int =
        ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")).use { it.localPort }

    /**
     * 1) يتحقق من وجود الملف التنفيذي  2) يحلّ اسم المحلّل  3) يشغّل العملية  4) ينتظر المنفذ المحلي.
     * يعيد المنفذ المحلي. استخدم [probe] بعده للتأكد من أن النفق يردّ فعلًا.
     */
    fun start(cancelled: () -> Boolean): Int {
        synchronized(GATE) {
            val other = running
            if (other != null && other !== this) {
                Bus.log("VayDNS: stopping a previous engine instance")
                other.stop()
            }
            running = this
        }
        ready = Ready.STARTING
        try {
            Bus.log("VayDNS: config OK (${spec.describe()})")
            val bin = Native.lib(ctx, "vaydns")
            if (!bin.exists()) throw IOException("libvaydns.so is not bundled in the APK")
            if (!bin.canExecute()) bin.setExecutable(true)
            if (!bin.canExecute()) throw IOException("libvaydns.so is not executable (path ${bin.absolutePath})")

            if (spec.transport == "udp") spec.resolver = pickIp(spec.resolver)
            if (spec.listen.isEmpty()) spec.listen = "127.0.0.1:${freePort()}"

            val cmd = spec.args(bin.absolutePath)
            Bus.log("VayDNS: starting engine process")
            Bus.app("[VayDNS] exec: " + cmd.mapIndexed { i, s -> if (i > 0 && cmd[i - 1] == "-pubkey") "<key>" else s }.joinToString(" "))
            val pr = ProcessBuilder(cmd).directory(ctx.filesDir).redirectErrorStream(true).start()
            proc = pr
            if (cancelled()) { stop(); throw CancelledException() }

            Thread {
                try {
                    pr.inputStream.bufferedReader().forEachLine { line ->
                        val l = line.trim()
                        if (l.isNotEmpty()) {
                            synchronized(tail) { tail.addLast(l.take(300)); while (tail.size > KEEP_LINES) tail.removeFirst() }
                            Bus.app("[VayDNS] $l")
                        }
                    }
                } catch (_: Exception) {}
            }.apply { isDaemon = true }.start()

            Thread {
                val code = try { pr.waitFor() } catch (_: Exception) { -1 }
                exitCode = code
                if (stopping) { ready = Ready.STOPPED } else {
                    ready = Ready.FAILED
                    Bus.app("[VayDNS] process exited with code $code")
                    try { onExit?.invoke(code) } catch (_: Exception) {}
                }
            }.apply { isDaemon = true }.start()

            waitForPort(spec.port, 15000, cancelled)
            ready = Ready.LISTENING
            Bus.log("VayDNS: local listener ready on ${spec.listen}")
            return spec.port
        } catch (e: Exception) {
            if (e !is CancelledException) { ready = Ready.FAILED }
            stop()
            throw e
        }
    }

    private fun exitedMessage(): String {
        Thread.sleep(250) // نترك قارئ المخرجات يلتقط سبب الفشل
        val code = exitCode
        val ll = lastLines(4)
        return "VayDNS engine exited (code $code)" + if (ll.isNotEmpty()) ": ${ll.replace('\n', ' ').take(240)}" else ""
    }

    /** ينتظر حتى يقبل المنفذ المحلي اتصالًا TCP، مع كشف موت العملية المبكر والإلغاء. */
    fun waitForPort(port: Int, timeoutMs: Int, cancelled: () -> Boolean) {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (cancelled()) throw CancelledException()
            if (exitCode != null) throw IOException(exitedMessage())
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 300) }
                if (exitCode == null) return
            } catch (_: IOException) {}
            try { Thread.sleep(150) } catch (_: InterruptedException) { throw CancelledException() }
        }
        throw IOException("VayDNS local listener did not open on port $port within ${timeoutMs / 1000}s" + (lastLine()?.let { " (last: $it)" } ?: ""))
    }

    /**
     * فحص حقيقي للنفق: نفتح اتصالًا على المنفذ المحلي (أي نفتح stream حتى الخادم) وننتظر ردّ الخادم.
     * forward = "socks5": نرسل ترحيب SOCKS5 ونتوقع ردّه (05 xx). forward = "ssh": نتوقع لافتة "SSH-".
     * لا يحتاج اسم مستخدم ولا كلمة مرور. تُعاد المحاولة حتى انتهاء المهلة لأن أول اتصال عبر DNS بطيء.
     */
    fun probe(forward: String, timeoutMs: Int, cancelled: () -> Boolean) {
        Bus.log("VayDNS: probing the tunnel (${if (forward == "ssh") "SSH banner" else "SOCKS5 greeting"}), timeout ${timeoutMs / 1000}s")
        val end = System.currentTimeMillis() + timeoutMs
        var attempt = 0
        var err: String? = null
        while (System.currentTimeMillis() < end) {
            if (cancelled()) throw CancelledException()
            if (exitCode != null) throw IOException(exitedMessage())
            attempt++
            try {
                val left = (end - System.currentTimeMillis()).toInt().coerceIn(3000, 20000)
                tryOnce(forward, left)
                ready = Ready.READY
                Bus.log("VayDNS: tunnel probe OK (attempt $attempt)")
                return
            } catch (e: IOException) {
                err = e.message ?: e.javaClass.simpleName
                if (attempt == 1 || attempt % 5 == 0) Bus.log("VayDNS: no answer through the tunnel yet (attempt $attempt): $err")
            }
            try { Thread.sleep(1500) } catch (_: InterruptedException) { throw CancelledException() }
        }
        val ll = lastLine()
        throw IOException(
            "VayDNS tunnel did not answer within ${timeoutMs / 1000}s" +
                (err?.let { " ($it)" } ?: "") + (ll?.let { ". Engine: ${it.take(160)}" } ?: "")
        )
    }

    private fun tryOnce(forward: String, timeoutMs: Int) {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.connect(InetSocketAddress("127.0.0.1", spec.port), 5000)
            s.soTimeout = timeoutMs
            val ins = DataInputStream(s.getInputStream())
            if (forward == "ssh") {
                val b = ByteArray(4)
                ins.readFully(b)
                if (String(b, Charsets.ISO_8859_1) != "SSH-") throw IOException("server did not send an SSH banner")
            } else {
                val o = s.getOutputStream()
                o.write(byteArrayOf(5, 2, 0, 2)) // نعرض الطريقتين: بدون مصادقة / اسم مستخدم+كلمة مرور
                o.flush()
                if (ins.readUnsignedByte() != 5) throw IOException("the server behind the tunnel is not a SOCKS5 proxy")
                ins.readUnsignedByte()
            }
        } catch (e: java.net.SocketTimeoutException) {
            throw IOException("timed out waiting for the server")
        } catch (e: java.io.EOFException) {
            throw IOException("tunnel closed the stream")
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }

    /** إيقاف العملية وتنظيف الحالة (آمن للاستدعاء أكثر من مرة). */
    fun stop() {
        stopping = true
        val p = proc
        proc = null
        if (p != null) {
            try { p.destroy() } catch (_: Exception) {}
            var i = 0
            while (i < 20 && exitCode == null) {
                try { Thread.sleep(100) } catch (_: InterruptedException) { break }
                i++
            }
        }
        if (ready != Ready.FAILED) ready = Ready.STOPPED
        synchronized(GATE) { if (running === this) running = null }
    }
}
