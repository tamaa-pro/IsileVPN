package com.tamaa.isilevpn

import android.content.Context
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/** يبني قسم Tunnel داخل صفحة الإعدادات من خريطة [TunnelPrefs.sections]. كل تغيير صالح يُحفظ فورًا. */
object TunnelSettingsUi {
    fun build(ctx: Context, root: LinearLayout) {
        root.removeAllViews() // لا شيء آخر داخل الحاوية؛ يُستدعى مرة واحدة ويمكن إعادته بعد "Reset"
        val inf = LayoutInflater.from(ctx)
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        fun header(text: String, top: Int) = TextView(ctx).apply {
            this.text = text.uppercase()
            textSize = 12f
            setTextColor(ContextCompat.getColor(ctx, R.color.accent))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            layoutParams = LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(top) }
        }

        fun lp() = LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(10) }

        root.addView(header("Tunnel", 0))

        for (sec in TunnelPrefs.sections) {
            root.addView(header(sec.title, 20))
            for (it in sec.items) {
                when (it.kind) {
                    TunnelPrefs.Kind.BOOL -> root.addView(MaterialSwitch(ctx).apply {
                        text = it.label
                        Tr.keepLtr(this)
                        textSize = 15f
                        setPadding(dp(4), dp(6), dp(4), dp(6))
                        isChecked = TunnelPrefs.bool(it.key)
                        setOnCheckedChangeListener { _, on -> TunnelPrefs.set(ctx, it.key, on.toString()) }
                        layoutParams = lp()
                    })
                    TunnelPrefs.Kind.CHOICE -> {
                        val til = inf.inflate(R.layout.dropdown, root, false) as TextInputLayout
                        val a = til.findViewById<MaterialAutoCompleteTextView>(R.id.edit)
                        til.hint = it.label
                        // الخيار الفارغ = افتراضي المحرك ويظهر باسم Default
                        val shown = it.options.map { o -> if (o.isEmpty()) "Default" else o }
                        a.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, shown))
                        val cur = TunnelPrefs.get(it.key)
                        a.setText(if (cur.isEmpty()) "Default" else cur, false)
                        a.setOnItemClickListener { _, _, pos, _ -> TunnelPrefs.set(ctx, it.key, it.options[pos]) }
                        til.layoutParams = lp()
                        root.addView(til)
                    }
                    else -> {
                        val til = inf.inflate(R.layout.field, root, false) as TextInputLayout
                        val et = til.findViewById<TextInputEditText>(R.id.edit)
                        til.hint = it.label
                        if (it.hint.isNotEmpty() || it.blankOk) {
                            til.helperText = if (it.kind == TunnelPrefs.Kind.INT && it.blankOk && it.hint.isEmpty()) "Empty = engine default"
                            else it.hint.ifEmpty { "Empty = engine default" }
                        }
                        et.inputType = if (it.kind == TunnelPrefs.Kind.INT) InputType.TYPE_CLASS_NUMBER
                        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                        et.setText(TunnelPrefs.get(it.key))
                        et.addTextChangedListener(object : TextWatcher {
                            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                            override fun afterTextChanged(s: Editable?) {
                                val v = s?.toString().orEmpty()
                                val err = TunnelPrefs.validate(it, v)
                                til.error = err?.let { m -> Tr.t(m) }
                                if (err == null) TunnelPrefs.set(ctx, it.key, v.trim())
                            }
                        })
                        til.layoutParams = lp()
                        root.addView(til)
                    }
                }
            }
        }

        root.addView(MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Reset tunnel settings"
            layoutParams = LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(24); bottomMargin = dp(24) }
            setOnClickListener {
                TunnelPrefs.reset(ctx)
                build(ctx, root)
            }
        })
        Tr.view(root)
        Tr.align(root)
    }
}
