package com.tamaa.isilevpn

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.Locale
import java.util.concurrent.Executors

/**
 * صفحة مراقبة التطبيقات: بطاقة علوية (بحث، فلترة، تعطيل/تفعيل الكل) وتحتها بطاقة لكل تطبيق فيها مفتاح
 * (أخضر = يمرّ عبر النفق، أحمر = يخرج مباشرة بإنترنت الجهاز) واستهلاكه (تنزيل/رفع) منذ بدء الاتصال.
 */
class AppsPage(private val act: Activity, private val root: View) {
    private class Row(val pkg: String, val label: String, val uid: Int, val system: Boolean, val locked: Boolean)
    private enum class Filter { ALL, SYSTEM, USER }
    private enum class Sort { USAGE_DESC, USAGE_ASC, AZ, ZA }

    private val search: TextView = root.findViewById(R.id.appsSearch)
    private val btnFilter: MaterialButton = root.findViewById(R.id.appsFilter)
    private val btnSort: MaterialButton = root.findViewById(R.id.appsSort)
    private val btnAll: MaterialButton = root.findViewById(R.id.appsToggleAll)
    private val usageBar: View = root.findViewById(R.id.appsUsageBar)
    private val applyBar: View = root.findViewById(R.id.appsApplyBar)
    private val count: TextView = root.findViewById(R.id.appsCount)
    private val list: RecyclerView = root.findViewById(R.id.appsList)
    private val progress: ProgressBar = root.findViewById(R.id.appsProgress)

    private var all: List<Row> = emptyList()
    private var shown: List<Row> = emptyList()
    private var filter = Filter.ALL
    private var sort = Sort.AZ
    /** ترتيب أبجدي يراعي العربية والحروف اللاتينية (يتجاهل التشكيل واختلاف حالة الأحرف). */
    private val collator = java.text.Collator.getInstance(Locale("ar")).apply { strength = java.text.Collator.SECONDARY }
    private var query = ""
    @Volatile private var usage: Map<Int, LongArray> = emptyMap()
    private var loaded = false
    private var loading = false
    private var visible = false
    /** وقت الاتصال الذي كانت عنده آخر تعديلات لم تُطبَّق (0 = لا تعديلات معلّقة). */
    private var dirtyAt = 0L

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val iconIo = Executors.newFixedThreadPool(2)
    private val icons = android.util.LruCache<String, Drawable>(200)
    private val adapter = Adapter()

    private fun col(id: Int) = ContextCompat.getColor(act, id)

    private val tick = object : Runnable {
        override fun run() {
            if (!visible) return
            refreshUsage()
            ui.postDelayed(this, 3000)
        }
    }

    init {
        list.layoutManager = LinearLayoutManager(act)
        list.adapter = adapter
        list.itemAnimator = null
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s?.toString().orEmpty().trim(); applyFilter() }
        })
        btnFilter.setOnClickListener {
            val m = PopupMenu(act, btnFilter)
            m.menu.add(0, 0, 0, Tr.t("All apps"))
            m.menu.add(0, 1, 1, Tr.t("System apps"))
            m.menu.add(0, 2, 2, Tr.t("User apps"))
            m.setOnMenuItemClickListener {
                filter = Filter.values()[it.itemId]
                applyFilter()
                true
            }
            m.show()
        }
        btnSort.setOnClickListener {
            val m = PopupMenu(act, btnSort)
            m.menu.add(0, 0, 0, Tr.t("Highest usage first"))
            m.menu.add(0, 1, 1, Tr.t("Lowest usage first"))
            m.menu.add(0, 2, 2, Tr.t("A to Z"))
            m.menu.add(0, 3, 3, Tr.t("Z to A"))
            m.setOnMenuItemClickListener {
                sort = Sort.values()[it.itemId]
                applyFilter()
                list.scrollToPosition(0)
                true
            }
            m.show()
        }
        btnAll.setOnClickListener {
            val target = shown.filter { !it.locked }
            if (target.isEmpty()) return@setOnClickListener
            val allOn = target.all { AppRules.isEnabled(act, it.pkg) }
            AppRules.set(act, target.map { it.pkg }, !allOn)
            changed()
            adapter.notifyDataSetChanged()
            updateToggleAll()
        }
        root.findViewById<View>(R.id.appsUsageBtn).setOnClickListener {
            try { act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {}
        }
        root.findViewById<View>(R.id.appsApplyBtn).setOnClickListener {
            dirtyAt = 0L
            updateBars()
            ContextCompat.startForegroundService(
                act, Intent(act, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_RECONNECT)
            )
        }
        Tr.view(root); Tr.align(root)
    }

    fun show() {
        visible = true
        if (!loaded) load()
        updateBars()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    fun hide() {
        visible = false
        ui.removeCallbacks(tick)
    }

    /** تغيّرت حالة تطبيق: إن كان الاتصال قائمًا تُطبَّق التعديلات بعد إعادة الاتصال. */
    private fun changed() {
        if (Bus.state == State.CONNECTED) dirtyAt = Bus.connectedAt
        updateBars()
    }

    private fun updateBars() {
        if (dirtyAt != 0L && (Bus.state != State.CONNECTED || Bus.connectedAt != dirtyAt)) dirtyAt = 0L
        applyBar.visibility = if (dirtyAt != 0L) View.VISIBLE else View.GONE
        usageBar.visibility = if (AppUsage.hasAccess(act)) View.GONE else View.VISIBLE
    }

    private fun load() {
        if (loading) return
        loading = true
        progress.visibility = View.VISIBLE
        io.execute {
            val pm = act.packageManager
            val calls = CallApps.packages(act)
            val rows = ArrayList<Row>()
            try {
                for (ai in pm.getInstalledApplications(0)) {
                    val pkg = ai.packageName
                    if (pkg == act.packageName) continue
                    // التطبيق بلا إذن الإنترنت لا يستعمل النفق أصلًا
                    if (pm.checkPermission(Manifest.permission.INTERNET, pkg) != PackageManager.PERMISSION_GRANTED) continue
                    val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                    val label = try { ai.loadLabel(pm).toString() } catch (_: Exception) { pkg }
                    rows += Row(pkg, label.ifBlank { pkg }, ai.uid, sys, pkg in calls)
                }
            } catch (_: Exception) {}
            ui.post {
                loading = false
                loaded = true
                all = rows
                progress.visibility = View.GONE
                applyFilter()
            }
        }
    }

    private fun total(r: Row): Long = usage[r.uid]?.let { it[0] + it[1] } ?: 0L

    private fun applyFilter() {
        val q = query.lowercase(Locale.ROOT)
        val base = all.filter { r ->
            (filter == Filter.ALL || (filter == Filter.SYSTEM) == r.system) &&
                (q.isEmpty() || r.label.lowercase(Locale.ROOT).contains(q) || r.pkg.lowercase(Locale.ROOT).contains(q))
        }
        val byName = Comparator<Row> { x, y -> collator.compare(x.label, y.label).let { c -> if (c != 0) c else x.pkg.compareTo(y.pkg) } }
        shown = when (sort) {
            Sort.AZ -> base.sortedWith(byName)
            Sort.ZA -> base.sortedWith(byName.reversed())
            // الترتيب بالاستهلاك لا يعرض التطبيقات التي استهلاكها صفر
            Sort.USAGE_DESC -> base.filter { total(it) > 0 }.sortedWith(compareByDescending<Row> { total(it) }.then(byName))
            Sort.USAGE_ASC -> base.filter { total(it) > 0 }.sortedWith(compareBy<Row> { total(it) }.then(byName))
        }
        btnFilter.text = Tr.t(when (filter) { Filter.ALL -> "All apps"; Filter.SYSTEM -> "System apps"; Filter.USER -> "User apps" })
        btnSort.text = Tr.t(when (sort) { Sort.USAGE_DESC -> "Top usage"; Sort.USAGE_ASC -> "Low usage"; Sort.AZ -> "A → Z"; Sort.ZA -> "Z → A" })
        val usageSort = sort == Sort.USAGE_DESC || sort == Sort.USAGE_ASC
        count.text = if (usageSort && shown.isEmpty() && all.isNotEmpty())
            Tr.t("No usage yet. Connect and allow usage access.") else "${shown.size} ${Tr.t("apps")}"
        adapter.notifyDataSetChanged()
        updateToggleAll()
    }

    private fun updateToggleAll() {
        val target = shown.filter { !it.locked }
        val allOn = target.isNotEmpty() && target.all { AppRules.isEnabled(act, it.pkg) }
        btnAll.text = Tr.t(if (allOn) "Disable all" else "Enable all")
        btnAll.isEnabled = target.isNotEmpty()
    }

    private fun refreshUsage() {
        updateBars()
        val since = if (Bus.state == State.CONNECTED) Bus.connectedAt else 0L
        io.execute {
            val u = AppUsage.query(act, since)
            ui.post {
                if (!visible) return@post
                usage = u
                // الترتيب بالاستهلاك يُعاد حسابه مع كل تحديث؛ غيره يكتفي بتحديث الأرقام
                if (sort == Sort.USAGE_DESC || sort == Sort.USAGE_ASC) applyFilter()
                else adapter.notifyItemRangeChanged(0, adapter.itemCount)
            }
        }
    }

    private fun fmt(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    private fun usageText(r: Row): String {
        val u = usage[r.uid]
        val base = if (Bus.state == State.CONNECTED && u != null) "↓ ${fmt(u[0])}   ↑ ${fmt(u[1])}" else "↓ –   ↑ –"
        return if (r.locked) base + "   ·   " + Tr.t("Calls (always excluded)") else base
    }

    private fun loadIcon(pkg: String, iv: ImageView) {
        iv.tag = pkg
        icons.get(pkg)?.let { iv.setImageDrawable(it); return }
        iv.setImageDrawable(null)
        iconIo.execute {
            val d = try { act.packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null } ?: return@execute
            icons.put(pkg, d)
            ui.post { if (iv.tag == pkg) iv.setImageDrawable(d) }
        }
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.H>() {
        inner class H(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.appIcon)
            val name: TextView = v.findViewById(R.id.appName)
            val use: TextView = v.findViewById(R.id.appUsage)
            val dot: View = v.findViewById(R.id.appDot)
            val sw: MaterialSwitch = v.findViewById(R.id.appSwitch)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            H(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false).also { Tr.align(it) })

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: H, position: Int) {
            val r = shown.getOrNull(position) ?: return
            val on = !r.locked && AppRules.isEnabled(act, r.pkg)
            h.name.text = r.label
            h.use.text = usageText(r)
            loadIcon(r.pkg, h.icon)
            h.dot.backgroundTintList = ColorStateList.valueOf(col(if (on) R.color.green else R.color.red))
            h.sw.setOnCheckedChangeListener(null)
            h.sw.isChecked = on
            h.sw.isEnabled = !r.locked
            h.sw.setOnCheckedChangeListener { _, checked ->
                AppRules.set(act, listOf(r.pkg), checked)
                h.dot.backgroundTintList = ColorStateList.valueOf(col(if (checked) R.color.green else R.color.red))
                changed()
                updateToggleAll()
            }
        }
    }
}
