package com.tamaa.isilevpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class Kind(val label: String) {
    SSH("SSH"), VLESS("VLESS"), VMESS("VMess"), TROJAN("Trojan"),
    /** VayDNS: وكيل SOCKS5 مباشر عبر نفق VayDNS (مع مصادقة اختيارية)، بدون SSH أو V2Ray. */
    SOCKS("VayDNS");

    val isSsh get() = this == SSH
    val isSocks get() = this == SOCKS
}

/** يستبدل وسوم [host] و[port] و[host_port] (بأي حالة أحرف) بعنوان الخادم ومنفذه. */
object Tags {
    /** بدون أي قصّ للمسافات/الأسطر (مهم للـ payload الذي ينتهي بـ CRLF CRLF). */
    fun resolve(t: String, host: String, port: Int): String =
        t.replace("[host_port]", "$host:$port", ignoreCase = true)
            .replace("[host]", host, ignoreCase = true)
            .replace("[port]", port.toString(), ignoreCase = true)

    /** للحقول النصية القصيرة (SNI / Host): يستبدل الوسوم ثم يقصّ الفراغات. */
    fun field(t: String, host: String, port: Int): String = resolve(t, host, port).trim()
}

/** أنواع نفق DNS المدعومة مع SSH. */
object Dns {
    const val SLOW = "slowdns"
    const val VAY = "vaydns"

    private val ipv4 = Regex("^(\\d{1,3})(\\.\\d{1,3}){3}(:(\\d{1,5}))?$")

    /** يطبّع عنوان المحلل: IPv4 مع منفذ (53 افتراضيًا)، أو null إن كان غير صالح. */
    fun resolver(t: String): String? {
        val s = t.trim()
        val m = ipv4.matchEntire(s) ?: return null
        val ip = s.substringBefore(':')
        if (ip.split(".").any { it.toInt() !in 0..255 }) return null
        val port = m.groupValues[4].ifEmpty { "53" }.toInt()
        if (port !in 1..65535) return null
        return "$ip:$port"
    }

    /** يطبّع المستمع المحلي: "7000" أو "127.0.0.1:7000" -> "127.0.0.1:7000"؛ فارغ = منفذ تلقائي؛ null = غير صالح. */
    fun listen(t: String): String? {
        val s = t.trim()
        if (s.isEmpty()) return ""
        val port = (if (s.contains(':')) s.substringAfterLast(':') else s).toIntOrNull() ?: return null
        val ip = if (s.contains(':')) s.substringBeforeLast(':') else "127.0.0.1"
        if (port !in 1..65535) return null
        if (ip != "127.0.0.1" && ip != "localhost" && ip != "0.0.0.0") return null
        return "${if (ip == "localhost") "127.0.0.1" else ip}:$port"
    }

    fun validKey(t: String) = Regex("^[0-9a-fA-F]{64}$").matches(t.trim())
    fun validDomain(t: String) = Regex("^([A-Za-z0-9_]([A-Za-z0-9_-]*[A-Za-z0-9_])?\\.)+[A-Za-z0-9-]{2,}$").matches(t.trim())
}

const val DEFAULT_PAYLOAD = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]"

data class Profile(
    var uid: String = UUID.randomUUID().toString(),
    var name: String = "",
    var kind: Kind = Kind.SSH,
    var host: String = "",
    var port: Int = 22,
    // SSH
    var user: String = "",
    var pass: String = "",
    var payloadOn: Boolean = false,
    var payload: String = DEFAULT_PAYLOAD,
    var proxyHost: String = "",
    var proxyPort: Int = 8080,
    // V2Ray: UUID (vless/vmess) أو كلمة المرور (trojan)
    var secret: String = "",
    // مشترك
    var ws: Boolean = false,
    var wsPath: String = "/",
    var wsHost: String = "",
    var tls: Boolean = false,
    var sni: String = "",
    var tlsVersion: String = "Auto",
    var fingerprint: String = "chrome",
    var alpn: String = "",
    var insecure: Boolean = false,
    var mux: Boolean = false,
    // حقول مخفية تأتي من الروابط (تُحفظ كما هي)
    var network: String = "tcp",
    var security: String = "",
    var flow: String = "",
    var pbk: String = "",
    var sid: String = "",
    var spx: String = "",
    var alterId: Int = 0,
    var vmessScy: String = "auto",
    var encryption: String = "none",
    var serviceName: String = "",
    // نفق DNS لـ SSH: "" (بدون) أو "slowdns" (dnstt) أو "vaydns". وفي VayDNS دائمًا "vaydns". وفي هذه الحالة host = نطاق النفق (NS)
    var dns: String = "",
    var dnsResolver: String = "8.8.8.8:53",
    var dnsPubkey: String = "",
    var dnsRecord: String = "",
    var dnsCompat: Boolean = false,
    var dnsListen: String = "",
    // VayDNS: نقل DNS ("udp" أو "dot" أو "doh") وما يمرّره الخادم ("socks5")
    var dnsTransport: String = "udp",
    var forward: String = "socks5",
    // VayDNS: تفعيل المصادقة (اسم المستخدم وكلمة المرور). معطّلة افتراضيًا = اتصال مباشر بلا مصادقة
    var auth: Boolean = false,
    // VayDNS: خيارات المحرك المتقدمة (نص فارغ = لا يُمرَّر الخيار فيستعمل المحرك قيمته الافتراضية)
    var dnsIdle: String = "",        // idle-timeout بالثواني
    var dnsKeepalive: String = "",   // keepalive بالثواني
    var dnsUdpTimeout: String = "",  // udp-timeout بالميلي ثانية
    var dnsOpenStream: String = "",  // open-stream-timeout بالثواني
    var dnsWorkers: String = "",     // udp-workers
    var dnsRps: String = "",         // rps (0 = بلا حد)
    var dnsMaxQname: String = "",    // max-qname-len
    var dnsMaxLabels: String = "",   // max-num-labels
    var dnsClientId: String = "",    // clientid-size
    var dnsUtls: String = "",        // utls
    var dnsLogLevel: String = "",    // log-level
    var dnsExtra: String = "",       // خيارات إضافية تُمرَّر للمحرك كما هي
    // كونفيج مستورد مغلق: لا يُعرض محتواه ولا يُعدَّل ولا يُشارَك
    var locked: Boolean = false
) {
    /** مثال: "VLESS · WS · TLS" */
    val isDns get() = (kind.isSsh && dns.isNotEmpty()) || kind.isSocks

    /** العنوان المعروض في القوائم. */
    fun addrLine(): String = if (isDns) host else "$host:$port"

    fun typeLine(): String {
        val parts = mutableListOf(kind.label)
        if (kind.isSocks) return "VayDNS · SOCKS5"
        if (isDns) {
            parts += if (dns == Dns.VAY) "VayDNS" else "SlowDNS"
            if (tls) parts += "TLS"
            return parts.joinToString(" · ")
        }
        if (ws) parts += "WS"
        if (kind.isSsh && payloadOn) parts += "Payload"
        if (tls) parts += "TLS"
        return parts.joinToString(" · ")
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("uid", uid); put("name", name); put("kind", kind.name)
        put("host", host); put("port", port)
        put("user", user); put("pass", pass)
        put("payloadOn", payloadOn); put("payload", payload)
        put("proxyHost", proxyHost); put("proxyPort", proxyPort)
        put("secret", secret)
        put("ws", ws); put("wsPath", wsPath); put("wsHost", wsHost)
        put("tls", tls); put("sni", sni); put("tlsVersion", tlsVersion)
        put("fingerprint", fingerprint); put("alpn", alpn)
        put("insecure", insecure); put("mux", mux)
        put("network", network); put("security", security); put("flow", flow)
        put("pbk", pbk); put("sid", sid); put("spx", spx)
        put("alterId", alterId); put("vmessScy", vmessScy)
        put("encryption", encryption); put("serviceName", serviceName)
        put("dns", dns); put("dnsResolver", dnsResolver); put("dnsPubkey", dnsPubkey)
        put("dnsRecord", dnsRecord); put("dnsCompat", dnsCompat); put("dnsListen", dnsListen)
        put("dnsTransport", dnsTransport); put("forward", forward)
        put("auth", auth)
        put("dnsIdle", dnsIdle); put("dnsKeepalive", dnsKeepalive); put("dnsUdpTimeout", dnsUdpTimeout)
        put("dnsOpenStream", dnsOpenStream); put("dnsWorkers", dnsWorkers); put("dnsRps", dnsRps)
        put("dnsMaxQname", dnsMaxQname); put("dnsMaxLabels", dnsMaxLabels); put("dnsClientId", dnsClientId)
        put("dnsUtls", dnsUtls); put("dnsLogLevel", dnsLogLevel); put("dnsExtra", dnsExtra)
        put("locked", locked)
    }

    companion object {
        fun fromJson(j: JSONObject): Profile {
            val d = Profile()
            return Profile(
                uid = j.optString("uid").ifEmpty { d.uid },
                name = j.optString("name", d.name),
                kind = runCatching { Kind.valueOf(j.optString("kind")) }.getOrDefault(d.kind),
                host = j.optString("host", d.host),
                port = j.optInt("port", d.port),
                user = j.optString("user", d.user),
                pass = j.optString("pass", d.pass),
                payloadOn = j.optBoolean("payloadOn", d.payloadOn),
                payload = j.optString("payload", d.payload),
                proxyHost = j.optString("proxyHost", d.proxyHost),
                proxyPort = j.optInt("proxyPort", d.proxyPort),
                secret = j.optString("secret", d.secret),
                ws = j.optBoolean("ws", d.ws),
                wsPath = j.optString("wsPath", d.wsPath),
                wsHost = j.optString("wsHost", d.wsHost),
                tls = j.optBoolean("tls", d.tls),
                sni = j.optString("sni", d.sni),
                tlsVersion = j.optString("tlsVersion", d.tlsVersion),
                fingerprint = j.optString("fingerprint", d.fingerprint),
                alpn = j.optString("alpn", d.alpn),
                insecure = j.optBoolean("insecure", d.insecure),
                mux = j.optBoolean("mux", d.mux),
                network = j.optString("network", d.network),
                security = j.optString("security", d.security),
                flow = j.optString("flow", d.flow),
                pbk = j.optString("pbk", d.pbk),
                sid = j.optString("sid", d.sid),
                spx = j.optString("spx", d.spx),
                alterId = j.optInt("alterId", d.alterId),
                vmessScy = j.optString("vmessScy", d.vmessScy),
                encryption = j.optString("encryption", d.encryption),
                serviceName = j.optString("serviceName", d.serviceName),
                dns = j.optString("dns", d.dns),
                dnsResolver = j.optString("dnsResolver", d.dnsResolver),
                dnsPubkey = j.optString("dnsPubkey", d.dnsPubkey),
                dnsRecord = j.optString("dnsRecord", d.dnsRecord),
                dnsCompat = j.optBoolean("dnsCompat", d.dnsCompat),
                dnsListen = j.optString("dnsListen", d.dnsListen),
                dnsTransport = j.optString("dnsTransport", d.dnsTransport).ifEmpty { "udp" },
                forward = j.optString("forward", d.forward).ifEmpty { "socks5" },
                // كونفيجات VayDNS القديمة (قبل هذا الخيار) كانت كلها بمصادقة
                auth = j.optBoolean("auth", j.optString("kind") == Kind.SOCKS.name && j.optString("user").isNotEmpty()),
                dnsIdle = j.optString("dnsIdle", d.dnsIdle),
                dnsKeepalive = j.optString("dnsKeepalive", d.dnsKeepalive),
                dnsUdpTimeout = j.optString("dnsUdpTimeout", d.dnsUdpTimeout),
                dnsOpenStream = j.optString("dnsOpenStream", d.dnsOpenStream),
                dnsWorkers = j.optString("dnsWorkers", d.dnsWorkers),
                dnsRps = j.optString("dnsRps", d.dnsRps),
                dnsMaxQname = j.optString("dnsMaxQname", d.dnsMaxQname),
                dnsMaxLabels = j.optString("dnsMaxLabels", d.dnsMaxLabels),
                dnsClientId = j.optString("dnsClientId", d.dnsClientId),
                dnsUtls = j.optString("dnsUtls", d.dnsUtls),
                dnsLogLevel = j.optString("dnsLogLevel", d.dnsLogLevel),
                dnsExtra = j.optString("dnsExtra", d.dnsExtra),
                locked = j.optBoolean("locked", d.locked)
            )
        }
    }
}

/** تخزين الكونفيجات (قائمة) + الكونفيج النشط. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("isile_configs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Profile> {
        val s = sp(c).getString("list", null) ?: return mutableListOf()
        return runCatching {
            val a = JSONArray(s)
            MutableList(a.length()) { Profile.fromJson(a.getJSONObject(it)) }
        }.getOrDefault(mutableListOf())
    }

    private fun saveAll(c: Context, list: List<Profile>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    fun activeId(c: Context): String? = sp(c).getString("active", null)

    fun setActive(c: Context, uid: String?) {
        sp(c).edit().putString("active", uid).apply()
    }

    fun active(c: Context): Profile? {
        val id = activeId(c) ?: return null
        return all(c).firstOrNull { it.uid == id }
    }

    fun upsert(c: Context, p: Profile) {
        val l = all(c)
        val i = l.indexOfFirst { it.uid == p.uid }
        if (i >= 0) l[i] = p else l.add(p)
        saveAll(c, l)
    }

    /** يحفظ ترتيب الكونفيجات الجديد (قائمة uid بالترتيب المطلوب). */
    fun reorder(c: Context, uids: List<String>) {
        val l = all(c)
        val byId = l.associateBy { it.uid }
        saveAll(c, uids.mapNotNull { byId[it] } + l.filter { it.uid !in uids })
    }

    fun delete(c: Context, uid: String) {
        val l = all(c)
        l.removeAll { it.uid == uid }
        saveAll(c, l)
        if (activeId(c) == uid) setActive(c, l.firstOrNull()?.uid)
    }
}
