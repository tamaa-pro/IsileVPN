package com.tamaa.isilevpn

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * عميل بروتوكول BadVPN udpgw: قناة TCP واحدة (داخل نفق SSH إلى 127.0.0.1:المنفذ على الخادم) تحمل كل حزم UDP.
 *
 * الإطار: [len:2 LE] ثم [flags:1][conid:2 LE][addr: ipv4 4 بايت أو ipv6 16 بايت][port:2 BE][البيانات].
 * الردود لها الشكل نفسه (العنوان فيها = مصدر الرد). الاتصالات المنطقية تتميّز بـ conid.
 */
class UdpGw(private val connect: () -> Link) {
    class Link(val ins: InputStream, val outs: OutputStream, val close: () -> Unit)

    fun interface Rx { fun on(srcIp: ByteArray, srcPort: Int, data: ByteArray) }

    private val rx = ConcurrentHashMap<Int, Rx>()
    private val ids = AtomicInteger(0)
    private val lock = Any()
    private var link: Link? = null
    @Volatile private var closed = false

    fun newConId(): Int {
        var n = ids.incrementAndGet() and 0xffff
        if (n == 0) n = ids.incrementAndGet() and 0xffff
        return n
    }
    fun register(id: Int, r: Rx) { rx[id] = r }
    fun unregister(id: Int) { rx.remove(id) }

    /** يرسل حزمة UDP إلى [ip]:[port] عبر udpgw. false = تعذّر (القناة لا تعمل). */
    fun send(conId: Int, ip: ByteArray, port: Int, data: ByteArray): Boolean {
        if (closed || (ip.size != 4 && ip.size != 16) || data.size > 65000) return false
        val v6 = ip.size == 16
        val body = 3 + ip.size + 2 + data.size
        val f = ByteArray(2 + body)
        f[0] = (body and 0xff).toByte(); f[1] = (body shr 8).toByte()
        f[2] = if (v6) 0x08 else 0x00
        f[3] = (conId and 0xff).toByte(); f[4] = (conId shr 8).toByte()
        System.arraycopy(ip, 0, f, 5, ip.size)
        val o = 5 + ip.size
        f[o] = (port shr 8).toByte(); f[o + 1] = (port and 0xff).toByte()
        System.arraycopy(data, 0, f, o + 2, data.size)
        return try {
            synchronized(lock) {
                val l = link ?: open()
                try { l.outs.write(f); l.outs.flush() } catch (e: Exception) { drop(l); throw e }
            }
            true
        } catch (_: Exception) { false }
    }

    private fun open(): Link {
        val l = connect()
        link = l
        val t = Thread {
            try {
                val i = l.ins
                val h = ByteArray(2)
                while (!closed) {
                    readFully(i, h, 2)
                    val len = (h[0].toInt() and 0xff) or ((h[1].toInt() and 0xff) shl 8)
                    val b = ByteArray(len)
                    readFully(i, b, len)
                    if (len < 3) continue
                    val flags = b[0].toInt() and 0xff
                    if (flags and 0x01 != 0) continue // keepalive
                    val conId = (b[1].toInt() and 0xff) or ((b[2].toInt() and 0xff) shl 8)
                    val al = if (flags and 0x08 != 0) 16 else 4
                    if (len < 3 + al + 2) continue
                    val ip = b.copyOfRange(3, 3 + al)
                    val port = ((b[3 + al].toInt() and 0xff) shl 8) or (b[4 + al].toInt() and 0xff)
                    rx[conId]?.on(ip, port, b.copyOfRange(5 + al, len))
                }
            } catch (_: Exception) {
            } finally {
                synchronized(lock) { drop(l) }
            }
        }
        t.isDaemon = true
        t.start()
        return l
    }

    private fun drop(l: Link) {
        if (link === l) link = null
        try { l.close() } catch (_: Exception) {}
    }

    private fun readFully(i: InputStream, b: ByteArray, n: Int) {
        var o = 0
        while (o < n) {
            val r = i.read(b, o, n - o)
            if (r < 0) throw IOException("udpgw closed")
            o += r
        }
    }

    fun close() {
        closed = true
        synchronized(lock) { link?.let { drop(it) } }
        rx.clear()
    }
}
