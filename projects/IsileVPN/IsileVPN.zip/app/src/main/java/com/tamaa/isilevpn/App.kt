package com.tamaa.isilevpn

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.load(this)
        // اللغة تحدد اتجاه الواجهة أيضًا (عربي = من اليمين لليسار) حتى لو كان الهاتف بلغة أخرى
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(Prefs.lang))
        AppCompatDelegate.setDefaultNightMode(
            if (Prefs.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }
}
