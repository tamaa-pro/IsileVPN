package com.tamaa.isilevpn

import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.text.Selection
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.view.View
import android.view.ViewTreeObserver
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.util.TypedValue
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    /** MAIN = ViewPager فيه صفحتان: الرئيسية (0) والسجل (1). */
    private enum class Page { MAIN, EDITOR, LIST, IPINFO, SPEED, SHARE, SETTINGS, APPS }

    private lateinit var drawer: DrawerLayout
    private lateinit var pager: ViewPager
    private lateinit var homeView: View
    private lateinit var logsView: View
    private lateinit var pageEditor: ScrollView
    private lateinit var pageList: View
    private lateinit var listRoot: LinearLayout
    private lateinit var editor: EditorPage
    private lateinit var pageIpInfo: View
    private lateinit var ipPage: IpInfoPage
    private lateinit var pageSpeed: View
    private lateinit var speedPage: SpeedTestPage
    private lateinit var pageShare: View
    private lateinit var pageSettings: View
    private lateinit var pageApps: View
    private lateinit var appsPage: AppsPage
    private lateinit var settingsNav: SettingsNav
    private lateinit var sharePage: SharePage

    private lateinit var tvState: TextView
    private lateinit var dot: View
    private lateinit var dotRing: View
    private lateinit var tvIp: TextView
    private lateinit var tvIpVpn: TextView
    private lateinit var tvError: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var graph: SpeedGraph
    private lateinit var btn: MaterialButton
    private lateinit var tvActiveName: TextView
    private lateinit var tvActiveType: TextView
    private lateinit var tvActiveAddr: TextView

    private lateinit var logScroll: ScrollView
    private lateinit var tvLogs: TextView
    private var appTab = false
    private var shownVersion = -1
    private var shownAppTab = false
    /** true = السجل ملتصق بآخره فيتابع الأسطر الجديدة؛ يصبح false فقط عندما يصعد المستخدم بنفسه. */
    private var logStick = true

    private var page = Page.MAIN

    private val vpnPrompt = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) startVpn() else Bus.log("ERROR: VPN permission denied")
    }
    private var pendingSave: (() -> Unit)? = null
    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val act = pendingSave
        pendingSave = null
        if (ok) act?.invoke() else Toast.makeText(this, Tr.t("Storage permission denied"), Toast.LENGTH_LONG).show()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val pickIsl = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importIslUri(uri)
    }

    // في العربية الاتجاه معكوس: السجل على اليسار والرئيسية على اليمين، فيُعكس ترتيب صفحات ViewPager
    private val rtl get() = Prefs.lang == Prefs.LANG_AR
    private val homeIdx get() = if (rtl) 1 else 0
    private val logsIdx get() = if (rtl) 0 else 1

    private fun <T : View> f(id: Int): T = findViewById(id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun col(id: Int) = ContextCompat.getColor(this, id)

    /**
     * اتجاه الواجهة يتبع لغة التطبيق فقط وليس لغة الهاتف:
     * الإنجليزية = من اليسار لليمين دائمًا، والعربية = من اليمين لليسار دائمًا (حتى لو كان الهاتف بالعربية).
     */
    override fun attachBaseContext(base: Context) {
        val loc = Locale.forLanguageTag(Prefs.lang)
        val cfg = android.content.res.Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // واجهة التحميل (داكنة + الأيقونة في الوسط): تبقى ظاهرة قليلًا حتى تُرى بوضوح
        val splash = installSplashScreen()
        var keepSplash = true
        splash.setKeepOnScreenCondition { keepSplash }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ keepSplash = false }, 900)
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection =
            if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        setContentView(R.layout.activity_main)
        drawer = f(R.id.drawer)
        Tr.view(drawer); Tr.align(drawer)
        pageEditor = f(R.id.pageEditor)
        pageList = f(R.id.pageList)
        listRoot = f(R.id.listRoot)
        pageIpInfo = f(R.id.pageIpInfo)
        ipPage = IpInfoPage(this, pageIpInfo)
        pageSpeed = f(R.id.pageSpeed)
        speedPage = SpeedTestPage(this, pageSpeed)
        pageShare = f(R.id.pageShareNet)
        pageSettings = f(R.id.pageSettings)
        pageApps = f(R.id.pageApps)
        appsPage = AppsPage(this, pageApps)
        sharePage = SharePage(this, pageShare)

        // الرئيسية والسجل: قطعتان متجاورتان تتبدلان بالتمرير مع الإصبع
        homeView = layoutInflater.inflate(R.layout.page_home, null)
        logsView = layoutInflater.inflate(R.layout.page_logs, null)
        Tr.view(homeView); Tr.view(logsView); Tr.align(homeView); Tr.align(logsView)
        pager = f(R.id.pager)
        pager.offscreenPageLimit = 2
        pager.adapter = object : PagerAdapter() {
            private val views = if (rtl) listOf(logsView, homeView) else listOf(homeView, logsView)
            override fun getCount() = views.size
            override fun isViewFromObject(view: View, obj: Any) = view === obj
            override fun instantiateItem(container: ViewGroup, position: Int): Any {
                val v = views[position]
                if (v.parent == null) container.addView(v)
                return v
            }
            override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
                container.removeView(obj as View)
            }
        }
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                if (position == logsIdx) renderLogs(true)
            }
        })

        tvState = homeView.findViewById(R.id.tvState); dot = homeView.findViewById(R.id.dot); dotRing = homeView.findViewById(R.id.dotRing)
        tvIp = homeView.findViewById(R.id.tvIp); tvIpVpn = homeView.findViewById(R.id.tvIpVpn); tvError = homeView.findViewById(R.id.tvError)
        tvDown = homeView.findViewById(R.id.tvDown); tvUp = homeView.findViewById(R.id.tvUp)
        graph = homeView.findViewById(R.id.graph); btn = homeView.findViewById(R.id.btnConnect)
        tvActiveName = homeView.findViewById(R.id.tvActiveName)
        tvActiveType = homeView.findViewById(R.id.tvActiveType)
        tvActiveAddr = homeView.findViewById(R.id.tvActiveAddr)
        logScroll = logsView.findViewById(R.id.logScroll)
        tvLogs = logsView.findViewById(R.id.tvLogs)
        logScroll.setOnScrollChangeListener { v, _, y, _, _ ->
            val c = (v as ScrollView).getChildAt(0)
            if (c != null) logStick = c.height - (v.height + y) < dp(80)
        }

        editor = EditorPage(this, f(R.id.editorRoot))
        editor.onApply = { p -> applyProfile(p) }

        f<View>(R.id.btnMenu).setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        f<View>(R.id.btnCreate).setOnClickListener { openEditor(null) }
        f<View>(R.id.btnConfigs).setOnClickListener { showPage(Page.LIST) }
        homeView.findViewById<View>(R.id.cardActive).setOnClickListener { showPage(Page.LIST) }
        f<View>(R.id.menuHome).setOnClickListener {
            drawer.closeDrawers(); showPage(Page.MAIN); pager.setCurrentItem(homeIdx, false)
        }
        f<View>(R.id.menuCreate).setOnClickListener { drawer.closeDrawers(); openEditor(null) }
        f<View>(R.id.menuConfigs).setOnClickListener { drawer.closeDrawers(); showPage(Page.LIST) }
        f<View>(R.id.menuLogs).setOnClickListener { drawer.closeDrawers(); showLogs() }
        f<View>(R.id.menuSettings).setOnClickListener { drawer.closeDrawers(); showPage(Page.SETTINGS) }
        f<View>(R.id.menuShare).setOnClickListener { drawer.closeDrawers(); showPage(Page.SHARE) }
        f<View>(R.id.menuSpeed).setOnClickListener { drawer.closeDrawers(); showPage(Page.SPEED) }
        f<View>(R.id.menuMyIp).setOnClickListener { drawer.closeDrawers(); showPage(Page.IPINFO) }
        f<View>(R.id.menuApps).setOnClickListener { drawer.closeDrawers(); showPage(Page.APPS) }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        f<TextView>(R.id.menuVersion).text = "${Tr.t("Version")} $ver"
        btn.setOnClickListener { onConnectClick() }
        setupSettings()

        val tabs = logsView.findViewById<MaterialButtonToggleGroup>(R.id.logTabs)
        tabs.check(R.id.tabConn)
        tabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                appTab = id == R.id.tabApp
                renderLogs(true)
            }
        }
        logsView.findViewById<View>(R.id.btnLogClear).setOnClickListener { Bus.clear(appTab) }
        logsView.findViewById<View>(R.id.btnLogCopy).setOnClickListener {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("log", buildLogs(appTab).toString()))
            Toast.makeText(this, Tr.t("Logs copied"), Toast.LENGTH_SHORT).show()
        }

        // القائمة الجانبية حرة: تُفتح بالزر أو بالسحب من حافة اليسار، وتُغلق بتمريرها لليسار
        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        widenDrawerEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawer.isDrawerOpen(GravityCompat.START) -> drawer.closeDrawer(GravityCompat.START)
                    page == Page.SETTINGS && settingsNav.close() -> {}
                    page != Page.MAIN -> showPage(Page.MAIN)
                    pager.currentItem == logsIdx -> pager.setCurrentItem(homeIdx, true)
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
        showPage(Page.MAIN)
        pager.setCurrentItem(homeIdx, false)
        savedInstanceState?.let { s ->
            val p = Page.values().getOrNull(s.getInt("page", 0)) ?: Page.MAIN
            if (p != Page.EDITOR) showPage(p)
            if (p == Page.SETTINGS) s.getString("settingsSub")?.let { settingsNav.open(it) }
            if (p == Page.MAIN && s.getBoolean("logs", false)) pager.setCurrentItem(logsIdx, false)
        }
        handleIncoming(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page.ordinal)
        outState.putBoolean("logs", pager.currentItem == logsIdx)
        settingsNav.current?.let { outState.putString("settingsSub", it) }
    }

    /** صفحة الإعدادات: اللغة، المظهر، وحدة السرعة. تُحفظ فورًا وتُطبَّق مباشرة. */
    private fun setupSettings() {
        val lang = pageSettings.findViewById<MaterialButtonToggleGroup>(R.id.setLang)
        lang.check(if (Prefs.lang == Prefs.LANG_AR) R.id.setLangAr else R.id.setLangEn)
        lang.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val v = if (id == R.id.setLangAr) Prefs.LANG_AR else Prefs.LANG_EN
            if (v == Prefs.lang) return@addOnButtonCheckedListener
            Prefs.setLang(this, v)
            // تغيير لغة التطبيق (واتجاهه) يعيد إنشاء الشاشة تلقائيًا ويبقى في صفحة الإعدادات
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(v))
        }
        val theme = pageSettings.findViewById<MaterialButtonToggleGroup>(R.id.setTheme)
        theme.check(if (Prefs.dark) R.id.setThemeDark else R.id.setThemeLight)
        theme.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val dark = id == R.id.setThemeDark
            if (dark == Prefs.dark) return@addOnButtonCheckedListener
            Prefs.setDark(this, dark)
            // تغيير الوضع يعيد إنشاء الشاشة تلقائيًا
            AppCompatDelegate.setDefaultNightMode(
                if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
        // قائمة الإعدادات: كل خيار يفتح صفحته مع زر رجوع
        settingsNav = SettingsNav(this, pageSettings)
        val unit = pageSettings.findViewById<MaterialButtonToggleGroup>(R.id.setUnit)
        unit.check(if (Prefs.bits) R.id.setUnitBit else R.id.setUnitByte)
        unit.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            Prefs.setBits(this, id == R.id.setUnitBit)
            refresh()
        }
    }

    /** يوسّع منطقة السحب من حافة اليسار (الافتراضي ضيق جدًا) كي يسهل فتح القائمة. */
    private fun widenDrawerEdge() {
        try {
            for (name in listOf("mLeftDragger", "mRightDragger")) {
                val f = DrawerLayout::class.java.getDeclaredField(name)
                f.isAccessible = true
                val dragger = f.get(drawer)
                val e = dragger.javaClass.getDeclaredField("mEdgeSize")
                e.isAccessible = true
                e.setInt(dragger, dp(32))
            }
        } catch (_: Throwable) {
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val data = i.data ?: return
        i.data = null // لا نعيد الاستيراد عند تدوير الشاشة
        importIslUri(data)
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { refresh() } }
        if (page == Page.SHARE) sharePage.show()
        watchNetwork()
        refreshActive()
        refresh()
    }

    override fun onPause() {
        sharePage.hide()
        pulseAnim?.cancel(); pulseAnim = null; pulseState = null
        unwatchNetwork()
        Bus.listener = null
        super.onPause()
    }

    // ---------- نبض النقطة ----------
    private var pulseState: State? = null
    private var pulseAnim: ObjectAnimator? = null

    private fun updatePulse(st: State) {
        if (st == pulseState) return
        pulseState = st
        pulseAnim?.cancel()
        pulseAnim = null
        dotRing.alpha = 0f; dotRing.scaleX = 1f; dotRing.scaleY = 1f
        if (st == State.IDLE) return
        // النقطة ثابتة، والقرص يخرج منها ويكبر وهو يتلاشى ثم يتكرر
        pulseAnim = ObjectAnimator.ofPropertyValuesHolder(
            dotRing,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 3.1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 3.1f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.6f, 0f)
        ).apply {
            duration = if (st == State.CONNECTED) 1600L else 1000L
            interpolator = android.view.animation.DecelerateInterpolator(1.2f)
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.RESTART
            start()
        }
    }

    // ---------- مراقبة تغيّر الشبكة (لتحديث عنوان IP) ----------
    private var netCb: ConnectivityManager.NetworkCallback? = null

    private fun watchNetwork() {
        if (netCb != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            private fun upd() {
                runOnUiThread {
                    refresh()
                    tvIp.postDelayed({ refresh() }, 600)
                }
            }
            override fun onAvailable(network: Network) = upd()
            override fun onLost(network: Network) = upd()
            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) = upd()
        }
        try {
            getSystemService(ConnectivityManager::class.java)
                .registerNetworkCallback(NetworkRequest.Builder().build(), cb)
            netCb = cb
        } catch (_: Exception) {
        }
    }

    private fun unwatchNetwork() {
        val cb = netCb ?: return
        netCb = null
        try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb) } catch (_: Exception) {}
    }

    // ---------- الاتصال ----------
    private fun onConnectClick() {
        if (Bus.state != State.IDLE) {
            startService(Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_STOP))
            return
        }
        if (Store.active(this) == null) {
            Toast.makeText(this, Tr.t("Create a config first"), Toast.LENGTH_SHORT).show()
            openEditor(null)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i = VpnService.prepare(this)
        if (i != null) vpnPrompt.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_START)
        )
    }

    // ---------- الصفحات ----------
    private fun showPage(p: Page) {
        page = p
        pager.visibility = if (p == Page.MAIN) View.VISIBLE else View.GONE
        pageEditor.visibility = if (p == Page.EDITOR) View.VISIBLE else View.GONE
        pageList.visibility = if (p == Page.LIST) View.VISIBLE else View.GONE
        pageIpInfo.visibility = if (p == Page.IPINFO) View.VISIBLE else View.GONE
        pageSpeed.visibility = if (p == Page.SPEED) View.VISIBLE else View.GONE
        pageShare.visibility = if (p == Page.SHARE) View.VISIBLE else View.GONE
        pageSettings.visibility = if (p == Page.SETTINGS) View.VISIBLE else View.GONE
        pageApps.visibility = if (p == Page.APPS) View.VISIBLE else View.GONE
        if (p == Page.APPS) appsPage.show() else appsPage.hide()
        if (p != Page.SETTINGS && ::settingsNav.isInitialized) settingsNav.close()
        if (p == Page.SHARE) sharePage.show() else sharePage.hide()
        if (p == Page.LIST) buildList()
        if (p == Page.IPINFO) ipPage.load(Bus.state)
        if (p == Page.SPEED) speedPage.show() else speedPage.stop()
        if (p == Page.MAIN) refreshActive()
        refresh()
    }

    private fun showLogs() {
        showPage(Page.MAIN)
        pager.setCurrentItem(logsIdx, true)
        renderLogs(true)
    }

    private fun openEditor(p: Profile?) {
        if (p?.locked == true) { Toast.makeText(this, Tr.t("This config is locked"), Toast.LENGTH_SHORT).show(); return }
        editor.bind(p?.copy() ?: Profile(), p != null)
        pageEditor.scrollTo(0, 0)
        showPage(Page.EDITOR)
    }

    private fun applyProfile(p: Profile) {
        val prev = Store.activeId(this)
        Store.upsert(this, p)
        if (Bus.state == State.IDLE || prev == null || prev == p.uid) {
            Store.setActive(this, p.uid)
        } else {
            Toast.makeText(this, Tr.t("Saved. Disconnect to switch to it."), Toast.LENGTH_LONG).show()
        }
        val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        im.hideSoftInputFromWindow(pageEditor.windowToken, 0)
        showPage(Page.MAIN)
        pager.setCurrentItem(homeIdx, false)
    }

    // ---------- الشاشة الرئيسية ----------
    private fun refresh() {
        val st = Bus.state
        tvState.text = when (st) {
            State.IDLE -> Tr.t("Disconnected")
            State.CONNECTING -> if (Bus.reconnecting) Tr.t("Reconnecting...") + (if (Bus.reconnectTry > 0) " (${Bus.reconnectTry})" else "") else Tr.t("Connecting...")
            State.CONNECTED -> Tr.t("Connected")
        }
        val dotTint = ColorStateList.valueOf(
            col(when (st) { State.IDLE -> R.color.text_dim; State.CONNECTING -> R.color.amber; State.CONNECTED -> R.color.green })
        )
        dot.backgroundTintList = dotTint
        dotRing.backgroundTintList = dotTint
        // الأعلى: IP الهاتف الحقيقي دائمًا. تحته: IP الاتصال الجديد (عند الاتصال فقط). أرقام فقط دون تسمية.
        tvIp.text = LocalIp.get(this).ifEmpty { "—" }
        if (st == State.CONNECTED) {
            tvIpVpn.visibility = View.VISIBLE
            tvIpVpn.text = Bus.ip.ifEmpty { "..." }
        } else {
            tvIpVpn.visibility = View.GONE
        }
        val err = Bus.lastError
        tvError.visibility = if (st == State.IDLE && err.isNotEmpty()) View.VISIBLE else View.GONE
        tvError.text = err
        tvDown.text = fmtSpeed(Bus.curDown)
        tvUp.text = fmtSpeed(Bus.curUp)
        val (d, u) = Bus.history()
        graph.set(d, u)
        btn.text = if (st == State.IDLE) Tr.t("Connect") else Tr.t("Disconnect")
        // أخضر عند الاتصال، أصفر أثناء المحاولة، أحمر فقط عند فشل الاتصال، وإلا اللون الأساسي
        btn.backgroundTintList = ColorStateList.valueOf(
            col(when (st) {
                State.IDLE -> if (err.isNotEmpty()) R.color.red else R.color.accent
                State.CONNECTING -> R.color.amber
                State.CONNECTED -> R.color.green
            })
        )
        updatePulse(st)
        if (page == Page.MAIN && pager.currentItem == logsIdx) renderLogs(false)
        // إن تغيّرت حالة الاتصال والصفحة مفتوحة: أعد الفحص (عبر النفق أو مباشرة)
        if (page == Page.SPEED) speedPage.onState(st)
        if (page == Page.IPINFO && st != State.CONNECTING && st != ipPage.loadedState) ipPage.load(st)
    }

    private fun refreshActive() {
        val a = Store.active(this)
        if (a == null) {
            tvActiveName.text = Tr.t("No config selected")
            tvActiveType.visibility = View.GONE
            tvActiveAddr.text = Tr.t("Tap + to create one")
        } else {
            tvActiveName.text = a.name
            tvActiveType.visibility = View.VISIBLE
            tvActiveType.text = a.typeLine()
            tvActiveAddr.text = if (a.locked) Tr.t("Locked config") else a.addrLine()
        }
    }

    private fun fmtSpeed(b: Long): String = Prefs.fmtSpeed(b)

    // ---------- قائمة الكونفيجات ----------
    private fun buildList() {
        listRoot.removeAllViews()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(14))
        }
        head.addView(TextView(this).apply {
            text = Tr.t("Saved configs")
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(ImageButton(this).apply {
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            setImageResource(R.drawable.ic_import)
            contentDescription = Tr.t("Import")
            setOnClickListener { showImportDialog() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        listRoot.addView(head)
        Tr.align(head)
        val items = Store.all(this)
        val act = Store.activeId(this)
        if (items.isEmpty()) {
            listRoot.addView(TextView(this).apply {
                text = Tr.t("No saved configs yet. Tap + to create one, or Import.")
                setTextColor(col(R.color.text_dim))
            })
            return
        }
        if (items.size > 1) {
            listRoot.addView(TextView(this).apply {
                text = Tr.t("Long-press a config and drag to reorder")
                textSize = 12f
                setTextColor(col(R.color.text_dim))
                setPadding(0, 0, 0, dp(10))
            })
        }
        val cards = ArrayList<View>()
        for (p in items) {
            val v = layoutInflater.inflate(R.layout.item_config, listRoot, false) as MaterialCardView
            Tr.view(v); Tr.align(v)
            v.findViewById<TextView>(R.id.itName).text = p.name
            v.findViewById<TextView>(R.id.itSub).text =
                if (p.locked) "${p.kind.label}  ·  ${Tr.t("Locked")}" else "${p.typeLine()}  ·  ${p.addrLine()}"
            v.strokeColor = col(R.color.accent)
            v.strokeWidth = if (p.uid == act) dp(2) else 0
            v.setOnClickListener { select(p) }
            val edit = v.findViewById<View>(R.id.btnEdit)
            val share = v.findViewById<View>(R.id.btnShare)
            if (p.locked) {
                edit.visibility = View.GONE
                share.visibility = View.GONE
            } else {
                edit.setOnClickListener { openEditor(p) }
                share.setOnClickListener { showShareDialog(p) }
            }
            v.findViewById<View>(R.id.btnDelete).setOnClickListener { confirmDelete(p) }
            listRoot.addView(v)
            cards.add(v)
        }
        // الضغط المطول ثم التحريك يغيّر ترتيب الكونفيجات ويُحفظ فورًا
        ListReorder(listRoot, pageList as? ScrollView) { order ->
            Store.reorder(this, order.map { items[it].uid })
            buildList()
        }.attach(cards)
    }

    // ---------- المشاركة ----------
    private fun showShareDialog(p: Profile) {
        if (p.locked) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val rg = RadioGroup(this)
        val rFile = RadioButton(this).apply { id = View.generateViewId(); text = Tr.t("Share as file (.isl)") }
        val rSave = RadioButton(this).apply { id = View.generateViewId(); text = Tr.t("Save file to Downloads") }
        val rLink = RadioButton(this).apply { id = View.generateViewId(); text = Tr.t("Share as link") }
        val rCopy = RadioButton(this).apply { id = View.generateViewId(); text = Tr.t("Copy link") }
        listOf(rFile, rSave, rLink, rCopy).forEach { rg.addView(it) }
        rFile.isChecked = true
        val swLock = MaterialSwitch(this).apply {
            text = Tr.t("Lock config")
            Tr.keepLtr(this)
            isChecked = false
            setPadding(dp(4), dp(10), dp(4), dp(2))
        }
        val hint = TextView(this).apply {
            textSize = 12f
            setTextColor(col(R.color.text_dim))
        }
        fun upd() {
            val file = rFile.isChecked || rSave.isChecked
            swLock.visibility = if (file) View.VISIBLE else View.GONE
            hint.text = when {
                !file -> Tr.t("The link shows all details and can be opened by any compatible app.")
                swLock.isChecked -> Tr.t("Locked: the receiver can connect but cannot view, edit or share it.")
                else -> Tr.t("Open: the receiver can view, edit and share it.")
            }
        }
        rg.setOnCheckedChangeListener { _, _ -> upd() }
        swLock.setOnCheckedChangeListener { _, _ -> upd() }
        upd()
        box.addView(rg); box.addView(swLock); box.addView(hint)
        MaterialAlertDialogBuilder(this)
            .setTitle("${Tr.t("Share")} \"${p.name}\"")
            .setView(box)
            .setPositiveButton(Tr.t("Continue")) { _, _ ->
                try {
                    when {
                        rFile.isChecked -> shareFile(p, swLock.isChecked)
                        rSave.isChecked -> saveFile(p, swLock.isChecked)
                        rLink.isChecked -> {
                            startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, LinkGen.make(p)), Tr.t("Share link")))
                        }
                        else -> {
                            getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("config", LinkGen.make(p)))
                            Toast.makeText(this, Tr.t("Link copied"), Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "${Tr.t("Share failed")}: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton(Tr.t("Cancel"), null)
            .show()
    }

    /** يحفظ ملف .isl في التنزيلات داخل مجلد باسم التطبيق (Download/Isile VPN). */
    private fun saveFile(p: Profile, lock: Boolean) {
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = { saveFile(p, lock) }
            storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        try {
            val bytes = IslFile.encode(p, lock)
            val base = p.name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().ifEmpty { "config" }
            val fname = "$base.${IslFile.EXT}"
            val folder = "Isile VPN"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fname)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_DOWNLOADS + "/" + folder)
                }
                val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw java.io.IOException("Cannot create file")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw java.io.IOException("Cannot write file")
            } else {
                val dir = File(android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS), folder).apply { mkdirs() }
                var f = File(dir, fname)
                var i = 1
                while (f.exists()) { f = File(dir, "$base ($i).${IslFile.EXT}"); i++ }
                f.writeBytes(bytes)
            }
            Toast.makeText(this, "${Tr.t("Saved to")} Downloads/$folder/$fname", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "${Tr.t("Save failed")}: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareFile(p: Profile, lock: Boolean) {
        val dir = File(cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val base = p.name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().ifEmpty { "config" }
        val f = File(dir, "$base.${IslFile.EXT}")
        f.writeBytes(IslFile.encode(p, lock))
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        val send = Intent(Intent.ACTION_SEND)
            .setType(IslFile.MIME)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, Tr.t("Share config")))
    }

    // ---------- الاستيراد ----------
    private fun showImportDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(12))
        }
        val dlg = MaterialAlertDialogBuilder(this).setView(box).create()

        fun title(t: String) = TextView(this).apply {
            text = t
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(col(R.color.text))
            setPadding(dp(4), 0, 0, dp(12))
        }

        fun option(icon: Int, label: String, onClick: () -> Unit): View = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            setBackgroundResource(tv.resourceId)
            addView(ImageView(context).apply { setImageResource(icon) }, LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(TextView(context).apply {
                text = label
                textSize = 16f
                setTextColor(col(R.color.text))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(16) })
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
        }

        fun showLink() {
            box.removeAllViews()
            box.addView(title(Tr.t("Import link")))
            val til = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle).apply {
                hint = Tr.t("Config link")
            }
            val et = TextInputEditText(til.context).apply {
                minLines = 3
                maxLines = 6
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                // اللصق تلقائيًا من آخر شيء في الحافظة
                val clip = try {
                    getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                } catch (_: Exception) { "" }
                setText(clip.trim())
            }
            til.addView(et)
            box.addView(til, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val go = MaterialButton(this).apply {
                text = Tr.t("Import")
                setIconResource(R.drawable.ic_import)
                iconTint = ColorStateList.valueOf(col(R.color.on_accent))
                setOnClickListener {
                    val t = et.text?.toString().orEmpty().trim()
                    try {
                        if (t.isBlank()) throw IllegalArgumentException(Tr.t("Paste a config link first"))
                        val prof = LinkParser.parse(t)
                        dlg.dismiss()
                        addImported(prof)
                    } catch (e: Exception) {
                        til.error = e.message ?: Tr.t("Invalid config")
                    }
                }
            }
            box.addView(go, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(14) })
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { til.error = null }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }

        fun showChoices() {
            box.removeAllViews()
            box.addView(title(Tr.t("Import config")))
            box.addView(option(R.drawable.ic_file, Tr.t("From file (.isl)")) {
                dlg.dismiss()
                pickIsl.launch(arrayOf("*/*"))
            })
            box.addView(option(R.drawable.ic_link, Tr.t("Import link")) { showLink() })
        }

        showChoices()
        dlg.show()
    }

    private fun addImported(p: Profile) {
        p.uid = java.util.UUID.randomUUID().toString()
        if (p.name.isBlank()) p.name = "${p.kind.label} ${if (p.locked) "config" else p.host}"
        Store.upsert(this, p)
        if (Store.activeId(this) == null) Store.setActive(this, p.uid)
        Toast.makeText(this, "${Tr.t("Imported")}: ${p.name}" + if (p.locked) " (${Tr.t("Locked").lowercase()})" else "", Toast.LENGTH_LONG).show()
        showPage(Page.LIST)
    }

    private fun importClipboard() {
        val t = getSystemService(ClipboardManager::class.java)
            .primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        try {
            if (t.isBlank()) throw IllegalArgumentException(Tr.t("Clipboard is empty"))
            addImported(LinkParser.parse(t))
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: Tr.t("Invalid config"), Toast.LENGTH_LONG).show()
        }
    }

    private fun importIslUri(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException(Tr.t("Cannot read file"))
            if (bytes.size > 1_000_000) throw IllegalArgumentException(Tr.t("File too large"))
            addImported(IslFile.decode(bytes))
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: Tr.t("Import failed"), Toast.LENGTH_LONG).show()
        }
    }

    private fun select(p: Profile) {
        if (Bus.state != State.IDLE && p.uid != Store.activeId(this)) {
            Toast.makeText(this, Tr.t("Disconnect first to switch config"), Toast.LENGTH_SHORT).show()
            return
        }
        Store.setActive(this, p.uid)
        showPage(Page.MAIN)
        pager.setCurrentItem(homeIdx, false)
    }

    private fun confirmDelete(p: Profile) {
        if (Bus.state != State.IDLE && p.uid == Store.activeId(this)) {
            Toast.makeText(this, Tr.t("Disconnect first"), Toast.LENGTH_SHORT).show()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(Tr.t("Delete config"))
            .setMessage("${Tr.t("Delete this config?")}\n\"${p.name}\"")
            .setPositiveButton(Tr.t("Delete")) { _, _ ->
                Store.delete(this, p.uid)
                buildList()
                refreshActive()
            }
            .setNegativeButton(Tr.t("Cancel"), null)
            .show()
    }

    // ---------- السجلات ----------
    private fun renderLogs(force: Boolean) {
        if (!force && Bus.logVersion == shownVersion && shownAppTab == appTab) return
        // لا نستبدل النص أثناء تحديد المستخدم لجزء منه كي لا يضيع التحديد
        if (!force && tvLogs.hasSelection()) return
        shownVersion = Bus.logVersion
        shownAppTab = appTab
        if (force) logStick = true
        val stick = logStick
        tvLogs.text = buildLogs(appTab)
        // TextView القابل للتحديد يضع المؤشر في بداية النص عند كل setText، فيقفز ScrollView إلى أعلى السجل.
        // إزالة المؤشر تمنع القفز، ثم نثبّت الموضع بعد اكتمال القياس (وليس قبله كما كان يفعل post).
        (tvLogs.text as? Spannable)?.let { Selection.removeSelection(it) }
        if (stick) {
            val vto = logScroll.viewTreeObserver
            vto.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    val o = logScroll.viewTreeObserver
                    if (o.isAlive) o.removeOnPreDrawListener(this)
                    val c = logScroll.getChildAt(0)
                    if (c != null) logScroll.scrollTo(0, maxOf(0, c.height - logScroll.height))
                    return true
                }
            })
        }
    }

    private fun buildLogs(forApp: Boolean): SpannableStringBuilder {
        Ansi.light = !Prefs.dark
        val dim = col(R.color.text_dim)
        val sb = SpannableStringBuilder()
        fun put(t: String, c: Int) {
            val a = sb.length
            sb.append(t)
            sb.setSpan(ForegroundColorSpan(c), a, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val text = Bus.text(forApp)
        if (text.isEmpty()) {
            put(
                if (forApp) "No app logs yet." else "No logs yet. Connect to see each step here.",
                dim
            )
            return sb
        }
        for (line in text.lineSequence()) {
            if (line.isBlank()) continue
            if (line.length > 10 && line[2] == ':' && line[5] == ':') {
                put(line.substring(0, 8), dim)
                val m = line.substring(8).trimStart()
                put("  ", dim)
                if (m.startsWith("Server:")) {
                    // رسالة الخادم: سجل واحد متعدد الأسطر، ألوانها بوسوم HTML (أو ANSI)
                    put("Server:", dim)
                    val body = m.removePrefix("Server:").trimStart().replace(Bus.NL, '\n')
                    sb.append('\n')
                    val from = sb.length
                    if (Ansi.hasHtml(body)) Ansi.appendHtml(sb, body)
                    else Ansi.append(sb, body, col(R.color.text))
                    styleServerMessage(sb, from)
                } else {
                    Ansi.append(sb, m, col(logColor(Ansi.strip(m))))
                }
            } else {
                put(line, dim)
            }
            sb.append('\n')
        }
        return sb
    }

    /**
     * رسالة الخادم تُعرض بخط عادي (sans-serif) بدل monospace: خط monospace في أندرويد لا يحتوي رموز الرسم
     * (─ ═ ...) فيستبدلها بخط آخر بعرض مختلف فتظهر الخطوط قصيرة، ويبدو النص سميكًا. كما نزيل التسميك الذي
     * تفرضه وسوم الخادم ونكبّر الخط قليلًا ليماثل ما يظهر في HTTP Custom.
     */
    private fun styleServerMessage(sb: SpannableStringBuilder, from: Int) {
        val to = sb.length
        if (to <= from) return
        for (st in sb.getSpans(from, to, StyleSpan::class.java)) {
            if (st.style == android.graphics.Typeface.BOLD || st.style == android.graphics.Typeface.BOLD_ITALIC) sb.removeSpan(st)
        }
        for (t in sb.getSpans(from, to, TypefaceSpan::class.java)) sb.removeSpan(t)
        sb.setSpan(TypefaceSpan("sans-serif"), from, to, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(RelativeSizeSpan(1.2f), from, to, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun logColor(m: String): Int {
        val l = m.lowercase(Locale.US)
        return when {
            m.startsWith("ERROR") || l.contains("failed") || l.contains("rejected") ||
                l.contains("lost") || l.contains("unexpectedly") || l.contains("denied") ||
                l.contains("[error]") -> R.color.red
            m.startsWith("Disconnect") || l.contains("not supported") || l.contains("no sni") ||
                l.contains("[warning]") -> R.color.amber
            m == "Connected" || l.contains("authenticated") || l.contains("connected successfully") ||
                l.contains("handshake ok") || l.contains("started") || l.startsWith("public ip") ||
                l.startsWith("http/") -> R.color.green
            else -> R.color.text
        }
    }
}
