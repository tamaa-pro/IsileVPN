package com.tamaa.isilevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.URL

class IsileVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.tamaa.isilevpn.START"
        const val ACTION_STOP = "com.tamaa.isilevpn.STOP"
        const val ACTION_RECONNECT = "com.tamaa.isilevpn.RECONNECT"
        private const val CH = "vpn"
        private val LOCK = Any()
        @Volatile private var current: Any? = null // محاولة الاتصال الحالية (على مستوى التطبيق كله)
    }

    /** كل محاولة اتصال لها رمز إلغاء خاص بها، حتى لا تتأثر محاولة جديدة بمحاولة قديمة. */
    private class Attempt {
        @Volatile var cancelled = false
    }

    private var tun: ParcelFileDescriptor? = null
    private var xray: Process? = null
    private var dnsProc: Process? = null
    private var vay: VayDnsRunner? = null
    private var ssh: SshTunnel? = null
    private var socks: SocksTunnel? = null
    private var sampler: Thread? = null
    @Volatile private var attempt: Attempt? = null
    @Volatile private var tproxyStarted = false
    @Volatile private var xrayFail: String? = null
    @Volatile private var connectedAt = 0L
    @Volatile private var profName = ""

    // ---- إعادة الاتصال التلقائية ----
    private val reconnectBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var reconnectGen = 0
    @Volatile private var netWake = false
    @Volatile private var netAtConnect: Network? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                if (Bus.state != State.IDLE) Bus.log("Disconnect requested")
                stopAsync()
                return START_NOT_STICKY
            }
            ACTION_RECONNECT -> {
                reconnectGen++
                watchNet()
                profName = Store.active(this)?.name.orEmpty()
                goForeground("Reconnecting...")
                Bus.log("Reconnect requested")
                Thread {
                    teardown(stopService = false)
                    beginConnect(clearLog = false)
                }.start()
                return START_NOT_STICKY
            }
        }
        // يجب استدعاء startForeground دائمًا بعد startForegroundService وإلا يُغلق التطبيق
        reconnectGen++
        watchNet()
        profName = Store.active(this)?.name.orEmpty()
        goForeground("Connecting...")
        if (Bus.state != State.IDLE) return START_NOT_STICKY
        beginConnect(clearLog = true)
        return START_NOT_STICKY
    }

    private fun beginConnect(clearLog: Boolean) {
        val a = Attempt()
        attempt = a
        current = a
        if (clearLog) Bus.clear(false)
        Bus.set(State.CONNECTING)
        val p = Store.active(this)
        Thread {
            try {
                if (p == null) throw IOException("No config selected")
                connect(p, a)
            } catch (_: CancelledException) {
                // أُلغي الاتصال بطلب المستخدم
            } catch (e: Throwable) {
                // محاولة ملغاة (فصل أو إعادة اتصال) لا تُسقط المحاولة الجديدة
                if (!a.cancelled) {
                    Bus.log("ERROR: ${e.message ?: e.javaClass.simpleName}")
                    Bus.app("Connect failed: ${e.javaClass.name}: ${e.message}")
                    e.stackTrace.take(8).forEach { Bus.app("    at $it") }
                    teardown()
                }
            }
        }.start()
    }

    private fun check(a: Attempt) {
        if (a.cancelled) throw CancelledException()
    }

    private fun logHeader() {
        val v = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }
        Bus.log("Isile VPN v$v")
        Bus.log("Running on ${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} (${Build.DEVICE})")
        Bus.log("Android ${Build.VERSION.RELEASE} API-${Build.VERSION.SDK_INT} (${Build.SUPPORTED_ABIS.firstOrNull() ?: "?"})")
    }

    /**
     * تطبيقات الاتصال والمكالمات (الهاتف، Telecom، الاتصال عبر Wi-Fi/VoLTE) تخرج مباشرة خارج النفق.
     * تمرير حركتها عبر النفق يقطع المكالمات العادية لأن خادم SSH/V2Ray لا يمرّر بروتوكولات IMS.
     */
    private fun excludeTelephony(b: Builder) {
        val pkgs = linkedSetOf(
            "com.android.phone", "com.android.server.telecom", "com.android.incallui",
            "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
            "com.samsung.android.incallui", "com.android.providers.telephony", "com.android.stk",
            "com.android.ims", "com.qualcomm.qti.ims", "com.qualcomm.qtil.ims", "com.mediatek.ims",
            "org.codeaurora.ims", "com.miui.voip", "com.android.mms", "com.android.cellbroadcastreceiver"
        )
        try {
            getSystemService(android.telecom.TelecomManager::class.java)?.defaultDialerPackage?.let { pkgs += it }
        } catch (_: Throwable) {}
        try {
            val i = Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:123"))
            packageManager.queryIntentActivities(i, 0).forEach { pkgs += it.activityInfo.packageName }
        } catch (_: Throwable) {}
        val done = mutableListOf<String>()
        for (n in pkgs) {
            if (n == packageName) continue
            try { b.addDisallowedApplication(n); done += n } catch (_: Exception) { /* غير مثبّت */ }
        }
        Bus.app("Calls excluded from VPN: ${done.joinToString()}")
    }

    private fun connect(p: Profile, a: Attempt, header: Boolean = true) {
        netAtConnect = realNetwork()
        Bus.mask = if (p.locked)
            listOf(p.host, p.proxyHost, p.user, p.pass, p.secret, p.sni, p.wsHost, p.dnsResolver, p.dnsPubkey).filter { it.length >= 3 }.distinct()
                .sortedByDescending { it.length }
        else emptyList()
        if (header) logHeader()
        Bus.log("Starting ${if (p.isDns) p.typeLine() else p.kind.label}: ${p.name}")
        try {
            Class.forName("hev.htproxy.TProxyService")
        } catch (t: Throwable) {
            Bus.app("tun2socks load error: ${t.javaClass.name}: ${t.cause?.message ?: t.message}")
            throw IOException("tun2socks library failed to load (see App log)")
        }
        check(a)
        if (p.kind.isSsh) startSsh(p, a) else if (p.kind.isSocks) startSocks(p, a) else startXray(p, a)
        check(a)

        Bus.log("Creating VPN interface...")
        val b = Builder()
            .setSession("Isile VPN")
            .setMtu(1500)
            .addAddress("10.10.14.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")
        // عنوان ثابت لمشاركة الشبكة: يُضاف لواجهة النفق فيصبح عنوانًا محليًا على الهاتف
        Bus.fixedApplied = ""
        if (ShareCfg.enabled(this) && ShareCfg.fixedOn(this)) {
            val fip = ShareCfg.fixedIp(this)
            if (ShareCfg.validIp(fip) && fip != ShareCfg.DEF_FIXED) {
                try { b.addAddress(fip, 32); Bus.fixedApplied = fip } catch (e: Exception) {
                    Bus.log("Fixed IP not applied: ${e.message}")
                }
            }
        }
        // نستثني تطبيقنا من النفق: اتصالات SSH/Xray تخرج مباشرة وبذلك لا توجد حلقة
        b.addDisallowedApplication(packageName)
        excludeTelephony(b)
        val fd = b.establish() ?: throw IOException("VPN permission not granted")
        synchronized(LOCK) {
            if (a.cancelled) {
                try { fd.close() } catch (_: Exception) {}
                throw CancelledException()
            }
            tun = fd
        }
        Bus.app("VPN interface ready")

        val cfg = File(filesDir, "hev.yml")
        cfg.writeText(
            """
            tunnel:
              mtu: 1500
              ipv4: 10.10.14.1
            socks5:
              port: ${XrayConfig.SOCKS_PORT}
              address: 127.0.0.1
              udp: 'udp'
            misc:
              log-level: warn
            """.trimIndent() + "\n"
        )
        check(a)
        tproxyStarted = true
        val ok = try {
            TProxyService.TProxyStartService(cfg.absolutePath, fd.fd)
        } catch (t: Throwable) {
            Bus.app("tun2socks error: ${t.javaClass.name}: ${t.message}")
            false
        }
        if (!ok) throw IOException("tun2socks failed to start (see App log)")
        Thread.sleep(500)
        check(a)
        Bus.set(State.CONNECTED)
        Bus.log("SOCKS engine: hev-socks5-tunnel")
        Bus.log("Connected")
        connectedAt = System.currentTimeMillis()
        profName = p.name
        getSystemService(NotificationManager::class.java)
            .notify(1, notif("Connected", "↓ ${fmtSpeed(0)}   ↑ ${fmtSpeed(0)}", true))
        startSampler()
        fetchIp(a)
    }

    private fun alive(p: Process): Boolean = try { p.exitValue(); false } catch (_: IllegalThreadStateException) { true }

    private fun startXray(p: Profile, a: Attempt) {
        Bus.log("Starting Xray core...")
        xrayFail = null
        val cfg = File(filesDir, "xray.json")
        cfg.writeText(XrayConfig.build(p))
        val bin = Native.lib(this, "xray")
        if (!bin.exists()) throw IOException("libxray.so is not bundled in the APK")
        val pb = ProcessBuilder(bin.absolutePath, "run", "-c", cfg.absolutePath)
            .directory(filesDir).redirectErrorStream(true)
        pb.environment()["XRAY_LOCATION_ASSET"] = filesDir.absolutePath
        val pr = pb.start()
        synchronized(LOCK) {
            if (a.cancelled) {
                pr.destroy()
                throw CancelledException()
            }
            xray = pr
        }
        pipeLog(pr)
        for (i in 0 until 15) {
            Thread.sleep(100)
            check(a)
            if (!alive(pr)) break
        }
        if (!alive(pr)) {
            Thread.sleep(200) // نترك قارئ المخرجات يلتقط سبب الفشل
            throw IOException(xrayFail ?: "Xray exited (code ${pr.exitValue()}), see App log")
        }
        watch(pr)
        Bus.log("Xray started")
    }

    private fun startSsh(p: Profile, a: Attempt) {
        // SlowDNS / VayDNS: نشغّل عميل نفق DNS أولًا ثم نتصل بـ SSH عبر منفذه المحلي
        var host = p.host
        var port = p.port
        var timeout = 25000
        if (p.isDns) {
            port = startDnsTunnel(p, a)
            host = "127.0.0.1"
            timeout = 60000 // نفق DNS أبطأ في التهيئة
        }
        lateinit var t: SshTunnel
        t = SshTunnel(p) { if (ssh === t) onLinkLost("SSH connection lost") }
        synchronized(LOCK) {
            if (a.cancelled) throw CancelledException()
            ssh = t
        }
        t.start(host, port, timeout)
    }

    /** VayDNS: عميل VayDNS ثم وكيل SOCKS5 محلي يمرّر إلى الخادم عبره (باسم المستخدم وكلمة المرور). */
    private fun startSocks(p: Profile, a: Attempt) {
        val port = startDnsTunnel(p, a)
        lateinit var t: SocksTunnel
        t = SocksTunnel(p) { if (socks === t) onLinkLost("SOCKS5 connection lost") }
        synchronized(LOCK) {
            if (a.cancelled) throw CancelledException()
            socks = t
        }
        t.start("127.0.0.1", port, 60000)
    }

    /**
     * VayDNS: تحقق من الإعدادات -> تشغيل المحرك -> انتظار المنفذ المحلي -> فحص النفق فعليًا.
     * لا نعلن الجاهزية إلا بعد أن يردّ الخادم عبر النفق (ترحيب SOCKS5 أو لافتة SSH).
     */
    private fun startVay(p: Profile, a: Attempt): Int {
        Bus.log("VayDNS: validating configuration")
        val spec = try { VayDnsSpec.fromProfile(p) } catch (e: IOException) {
            throw IOException("VayDNS config: ${e.message}")
        }
        val r = VayDnsRunner(this, spec)
        r.onExit = { code ->
            if (vay === r && Bus.state == State.CONNECTED) onLinkLost("VayDNS client stopped unexpectedly (exit code $code)")
        }
        synchronized(LOCK) {
            if (a.cancelled) throw CancelledException()
            vay?.stop()
            vay = r
        }
        val port = r.start { a.cancelled }
        check(a)
        r.probe(if (p.kind.isSsh) "ssh" else "socks5", 45000) { a.cancelled }
        check(a)
        return port
    }

    private fun freeLocalPort(): Int =
        java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1")).use { it.localPort }

    /** يشغّل dnstt-client (SlowDNS) أو vaydns-client ويعيد المنفذ المحلي الذي يمرّر إلى خادم SSH. */
    private fun startDnsTunnel(p: Profile, a: Attempt): Int {
        val slow = p.dns == Dns.SLOW
        if (!slow) return startVay(p, a)
        val libName = if (slow) "dnstt" else "vaydns"
        val tag = if (slow) "SlowDNS" else "VayDNS"
        val bin = Native.lib(this, libName)
        if (!bin.exists()) throw IOException("lib$libName.so is not bundled in the APK")
        val resolver = Dns.resolver(p.dnsResolver) ?: throw IOException("Invalid DNS resolver: ${p.dnsResolver}")
        val fixed = Dns.listen(p.dnsListen).orEmpty()
        val listen = fixed.ifEmpty { "127.0.0.1:${freeLocalPort()}" }
        val port = listen.substringAfterLast(':').toInt()
        val cmd = ArrayList<String>()
        cmd += bin.absolutePath
        cmd += listOf("-udp", resolver, "-pubkey", p.dnsPubkey.trim())
        if (slow) {
            cmd += listOf(p.host.trim(), listen)
        } else {
            cmd += listOf("-domain", p.host.trim(), "-listen", listen)
            if (p.dnsRecord.isNotBlank()) cmd += listOf("-record-type", p.dnsRecord.trim())
            if (p.dnsCompat) cmd += "-dnstt-compat"
        }
        Bus.log("$tag: resolver $resolver, domain ${p.host.trim()}, listen $listen" + if (p.tls) ", SNI ${p.sni.ifBlank { p.host.trim() }}" else "")
        val pr = ProcessBuilder(cmd).directory(filesDir).redirectErrorStream(true).start()
        synchronized(LOCK) {
            if (a.cancelled) {
                pr.destroy()
                throw CancelledException()
            }
            dnsProc = pr
        }
        val last = java.util.concurrent.atomic.AtomicReference<String?>(null)
        Thread {
            try {
                pr.inputStream.bufferedReader().forEachLine { line ->
                    Bus.app("[$tag] $line")
                    last.set(line.trim().take(160))
                }
            } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()
        for (i in 0 until 10) {
            Thread.sleep(100)
            check(a)
            if (!alive(pr)) break
        }
        if (!alive(pr)) {
            Thread.sleep(200)
            throw IOException("$tag client exited (code ${pr.exitValue()})" + (last.get()?.let { ": $it" } ?: ""))
        }
        Thread {
            try { pr.waitFor() } catch (_: Exception) {}
            if (dnsProc === pr && Bus.state == State.CONNECTED) onLinkLost("$tag client stopped unexpectedly")
        }.apply { isDaemon = true }.start()
        Bus.log("$tag tunnel client started")
        return port
    }

    /** يقيس السرعة كل ثانية من إحصائيات النفق (tx = رفع، rx = تنزيل). */
    private fun startSampler() {
        val th = Thread {
            var lastTx = -1L
            var lastRx = -1L
            while (!Thread.currentThread().isInterrupted && tproxyStarted) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
                val s: LongArray? = try { TProxyService.TProxyGetStats() } catch (_: Throwable) { null }
                if (s == null || s.size < 4) continue
                val tx = s[1]
                val rx = s[3]
                if (lastTx >= 0) {
                    val down = maxOf(0L, rx - lastRx)
                    val up = maxOf(0L, tx - lastTx)
                    Bus.pushSpeed(down, up)
                    if (tproxyStarted && Bus.state == State.CONNECTED && !Thread.currentThread().isInterrupted) {
                        getSystemService(NotificationManager::class.java)
                            .notify(1, notif("Connected", "↓ ${fmtSpeed(down)}   ↑ ${fmtSpeed(up)}", true))
                    }
                }
                lastTx = tx
                lastRx = rx
            }
        }
        th.isDaemon = true
        sampler = th
        th.start()
    }

    /** يجلب عنوان IP العام عبر منفذ SOCKS المحلي (أي من خلال النفق فعلاً). */
    private fun fetchIp(a: Attempt) {
        Thread {
            for (i in 0 until 4) {
                if (a.cancelled || Bus.state != State.CONNECTED) return@Thread
                val ip = try { httpGet("https://api.ipify.org") } catch (_: Exception) { null }
                if (ip != null) {
                    Bus.ip = ip
                    Bus.log("Public IP: $ip")
                    Bus.notifyChanged()
                    return@Thread
                }
                try { Thread.sleep(2000) } catch (_: InterruptedException) { return@Thread }
            }
            if (!a.cancelled && Bus.state == State.CONNECTED) {
                Bus.ip = "Unknown"
                Bus.notifyChanged()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun httpGet(url: String): String? {
        val px = java.net.Proxy(java.net.Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT))
        val c = URL(url).openConnection(px) as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            if (c.responseCode != 200) return null
            val t = c.inputStream.bufferedReader().readText().trim()
            return if (t.length in 7..45 && !t.contains('<')) t else null
        } finally {
            c.disconnect()
        }
    }

    /** مخرجات xray كلها تذهب إلى سجل التطبيق؛ فقط سبب فشل التشغيل يظهر في سجل الاتصال. */
    private fun pipeLog(pr: Process) {
        Thread {
            try {
                pr.inputStream.bufferedReader().forEachLine { line ->
                    Bus.app("[xray] $line")
                    if (line.contains("Failed to start") || line.contains("failed to listen")) {
                        xrayFail = "Xray: " + line.substringAfterLast("> ").trim().take(160)
                    }
                }
            } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()
    }

    private fun watch(pr: Process) {
        Thread {
            try { pr.waitFor() } catch (_: Exception) {}
            if (xray === pr && Bus.state == State.CONNECTED) {
                onLinkLost("Xray stopped unexpectedly")
            }
        }.apply { isDaemon = true }.start()
    }

    private fun stopAsync() {
        reconnectGen++
        Thread { teardown() }.start()
    }

    /** إيقاف كل شيء بالترتيب، وانتظار موت xray قبل إعلان الحالة IDLE حتى لا يبقى المنفذ محجوزًا. */
    private fun teardown(stopService: Boolean = true, keepState: Boolean = false) {
        synchronized(LOCK) {
            val mine = attempt
            mine?.cancelled = true
            sampler?.interrupt(); sampler = null
            if (tproxyStarted) {
                tproxyStarted = false
                try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
            }
            try { tun?.close() } catch (_: Exception) {}
            tun = null
            ssh?.stop(); ssh = null
            socks?.stop(); socks = null
            dnsProc?.let { d -> dnsProc = null; try { d.destroy() } catch (_: Exception) {} }
            vay?.let { r -> vay = null; Bus.log("VayDNS: stopping engine"); try { r.stop() } catch (_: Exception) {} }
            val x = xray
            xray = null
            if (x != null) {
                x.destroy()
                var i = 0
                while (alive(x) && i < 30) {
                    try { Thread.sleep(100) } catch (_: InterruptedException) { break }
                    i++
                }
            }
            // نغيّر الحالة فقط إن كانت المحاولة الحالية تخصنا (لا نؤثر على اتصال جديد)
            if (!keepState && mine === current && Bus.state != State.IDLE) {
                Bus.set(State.IDLE)
                Bus.log("Disconnected")
            }
        }
        if (stopService) {
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
            try { getSystemService(NotificationManager::class.java).cancel(1) } catch (_: Exception) {}
            stopSelf()
        }
    }

    // ---------- إعادة الاتصال التلقائية عند انقطاع الشبكة/الخادم ----------
    @Suppress("DEPRECATION")
    private fun realNetwork(): Network? {
        return try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val act = cm.activeNetwork
            var best: Network? = null
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (best == null || n == act) best = n
            }
            best
        } catch (_: Exception) { null }
    }

    private fun watchNet() {
        if (netCb != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { netWake = true }
            override fun onLost(network: Network) {
                if (Bus.state == State.CONNECTED && network == netAtConnect) onLinkLost("Network lost")
            }
        }
        try {
            getSystemService(ConnectivityManager::class.java).registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(), cb
            )
            netCb = cb
        } catch (_: Exception) {}
    }

    private fun unwatchNet() {
        val cb = netCb ?: return
        netCb = null
        try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb) } catch (_: Exception) {}
    }

    /** انقطع الاتصال بعد أن كان ناجحًا: نبقى في الخدمة والإشعار ونحاول من جديد حتى ينجح أو يفصل المستخدم. */
    private fun onLinkLost(reason: String) {
        if (Bus.state != State.CONNECTED) return
        if (!reconnectBusy.compareAndSet(false, true)) return
        val gen = reconnectGen
        Bus.reconnecting = true
        Bus.set(State.CONNECTING)
        Thread {
            try { reconnectLoop(gen, reason) } finally { reconnectBusy.set(false) }
        }.start()
    }

    private fun showReconnect(n: Int, waitingNet: Boolean) {
        Bus.reconnectTry = n
        val text = when {
            waitingNet -> if (n > 0) "Waiting for network · attempt $n" else "Waiting for network"
            n > 0 -> "Attempt $n"
            else -> "Connection lost"
        }
        try {
            getSystemService(NotificationManager::class.java).notify(1, notif("Reconnecting...", text, false))
        } catch (_: Exception) {}
        Bus.notifyChanged()
    }

    /** ينام بخطوات قصيرة ويستيقظ فورًا عند الإلغاء أو عودة الشبكة. */
    private fun waitStep(ms: Long, gen: Int) {
        var left = ms
        while (left > 0 && gen == reconnectGen && !netWake) {
            try { Thread.sleep(250) } catch (_: InterruptedException) { return }
            left -= 250
        }
        netWake = false
    }

    private fun reconnectLoop(gen: Int, reason: String) {
        val p = Store.active(this)
        if (p == null) {
            Bus.log("ERROR: No config selected")
            teardown()
            return
        }
        Bus.log("Connection lost ($reason). Reconnecting...")
        showReconnect(0, realNetwork() == null)
        teardown(stopService = false, keepState = true)
        var n = 0
        var loggedWait = false
        while (gen == reconnectGen) {
            if (realNetwork() == null) {
                if (!loggedWait) { Bus.log("Waiting for network..."); loggedWait = true }
                showReconnect(n, true)
                waitStep(3000, gen)
                continue
            }
            loggedWait = false
            n++
            showReconnect(n, false)
            Bus.log("Reconnect attempt $n...")
            val a = Attempt()
            synchronized(LOCK) {
                if (gen != reconnectGen) return
                attempt = a
                current = a
            }
            try {
                connect(p, a, header = false)
                return
            } catch (_: CancelledException) {
                if (gen != reconnectGen) return
            } catch (e: Throwable) {
                if (gen != reconnectGen) return
                Bus.log("Reconnect failed: ${e.message ?: e.javaClass.simpleName}")
                Bus.app("Reconnect failed: ${e.javaClass.name}: ${e.message}")
                teardown(stopService = false, keepState = true)
            }
            waitStep(minOf(3000L + n * 2000L, 20000L), gen)
        }
    }

    override fun onRevoke() {
        stopAsync()
    }

    override fun onDestroy() {
        reconnectGen++
        unwatchNet()
        attempt?.cancelled = true
        stopAsync()
        super.onDestroy()
    }

    private fun goForeground(title: String) {
        val n = notif(title, "", false)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun fmtSpeed(b: Long): String = Prefs.fmtSpeed(b)

    /** connected=true: يعرض عدّادًا حيًّا لمدة الاتصال (يديره النظام) ويستعمل وقت الاتصال كمرجع. */
    private fun notif(title: String, text: String, connected: Boolean): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, IsileVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val reconnect = PendingIntent.getService(
            this, 2, Intent(this, IsileVpnService::class.java).setAction(ACTION_RECONNECT), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(Tr.t(title))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, Tr.t("Disconnect"), stop)
            .addAction(0, Tr.t("Reconnect"), reconnect)
        if (text.isNotEmpty()) b.setContentText(text)
        if (profName.isNotEmpty()) b.setSubText(profName)
        if (connected && connectedAt > 0) b.setWhen(connectedAt).setUsesChronometer(true).setShowWhen(true)
        else b.setShowWhen(false)
        return b.build()
    }
}
