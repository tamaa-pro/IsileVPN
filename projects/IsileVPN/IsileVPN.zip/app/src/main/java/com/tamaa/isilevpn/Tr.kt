package com.tamaa.isilevpn

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.TextView
import com.google.android.material.textfield.TextInputLayout

/**
 * ترجمة واجهة التطبيق (الأسماء والخيارات والعناوين والملاحظات) إلى العربية.
 * النصوص الإنجليزية هي المفاتيح، وأي نص غير موجود يبقى كما هو (مثل السجلات وأسماء البروتوكولات).
 * لا يُعكس اتجاه الواجهة.
 */
object Tr {
    @Volatile var ar = false

    private val map: Map<String, String> = mapOf(
        "Menu" to "القائمة",
        "Configs" to "الكونفيجات",
        "Create" to "إنشاء",
        "Home" to "الرئيسية",
        "Create config" to "إنشاء كونفيج",
        "Saved configs" to "الكونفيجات المحفوظة",
        "Show logs" to "عرض السجلات",
        "Share net" to "مشاركة الشبكة",
        "What's my IP" to "ما هو IP الخاص بي",
        "Settings" to "الإعدادات",
        "Disconnected" to "غير متصل",
        "Connecting..." to "جارٍ الاتصال...",
        "Reconnecting..." to "جارٍ إعادة الاتصال...",
        "Connected" to "متصل",
        "Connect" to "اتصال",
        "Disconnect" to "قطع الاتصال",
        "Reconnect" to "إعادة الاتصال",
        "Download" to "التنزيل",
        "Upload" to "الرفع",
        "Share" to "مشاركة",
        "Edit" to "تعديل",
        "Delete" to "حذف",
        "Refresh" to "تحديث",
        "Map" to "الخريطة",
        "Flag" to "العلم",
        "Share this connection over your hotspot as an HTTP proxy" to "شارك هذا الاتصال عبر نقطة الاتصال كوكيل HTTP",
        "Note: turn on your phone's hotspot so other devices can connect to this proxy." to "ملاحظة: شغّل نقطة اتصال هاتفك ليتمكن باقي الأجهزة من الاتصال بهذا الوكيل.",
        "Enable sharing" to "تفعيل المشاركة",
        "Port" to "المنفذ",
        "Fixed IP address" to "عنوان IP ثابت",
        "Fixed IP" to "IP الثابت",
        "Logs" to "السجلات",
        "Copy logs" to "نسخ السجلات",
        "Clear logs" to "مسح السجلات",
        "Connection" to "الاتصال",
        "App" to "التطبيق",
        "Version" to "الإصدار",
        "No config selected" to "لم يتم اختيار كونفيج",
        "Tap + to create one" to "اضغط + لإنشاء واحد",
        "Locked config" to "كونفيج مقفل",
        "Locked" to "مقفل",
        "Import" to "استيراد",
        "No saved configs yet. Tap + to create one, or Import." to "لا توجد كونفيجات محفوظة بعد. اضغط + للإنشاء أو استخدم الاستيراد.",
        "Share as file (.isl)" to "مشاركة كملف (.isl)",
        "Save file to Downloads" to "حفظ الملف في التنزيلات",
        "Share as link" to "مشاركة كرابط",
        "Copy link" to "نسخ الرابط",
        "Lock config" to "قفل الكونفيج",
        "The link shows all details and can be opened by any compatible app." to "الرابط يعرض كل التفاصيل ويمكن فتحه من أي تطبيق متوافق.",
        "Locked: the receiver can connect but cannot view, edit or share it." to "مقفل: يستطيع المستلم الاتصال فقط دون عرضه أو تعديله أو مشاركته.",
        "Open: the receiver can view, edit and share it." to "مفتوح: يستطيع المستلم عرضه وتعديله ومشاركته.",
        "Continue" to "متابعة",
        "Cancel" to "إلغاء",
        "Share link" to "مشاركة الرابط",
        "Share config" to "مشاركة الكونفيج",
        "Link copied" to "تم نسخ الرابط",
        "Share failed" to "فشلت المشاركة",
        "Save failed" to "فشل الحفظ",
        "Saved to" to "تم الحفظ في",
        "Imported" to "تم الاستيراد",
        "Import link" to "استيراد رابط",
        "Import config" to "استيراد كونفيج",
        "From file (.isl)" to "من ملف (.isl)",
        "Config link" to "رابط الكونفيج",
        "Paste a config link first" to "الصق رابط كونفيج أولاً",
        "Invalid config" to "كونفيج غير صالح",
        "Clipboard is empty" to "الحافظة فارغة",
        "Cannot read file" to "تعذّرت قراءة الملف",
        "File too large" to "الملف كبير جداً",
        "Import failed" to "فشل الاستيراد",
        "Disconnect first to switch config" to "اقطع الاتصال أولاً لتبديل الكونفيج",
        "Disconnect first" to "اقطع الاتصال أولاً",
        "This config is locked" to "هذا الكونفيج مقفل",
        "Saved. Disconnect to switch to it." to "تم الحفظ. اقطع الاتصال للتبديل إليه.",
        "Create a config first" to "أنشئ كونفيجاً أولاً",
        "Logs copied" to "تم نسخ السجلات",
        "Storage permission denied" to "تم رفض إذن التخزين",
        "Delete config" to "حذف الكونفيج",
        "Delete this config?" to "حذف هذا الكونفيج؟",
        "Paste from clipboard" to "لصق من الحافظة",
        "Config name" to "اسم الكونفيج",
        "Server address" to "عنوان الخادم",
        "Username" to "اسم المستخدم",
        "Password" to "كلمة المرور",
        "Transport" to "النقل",
        "DNS resolver (IP:port)" to "خادم DNS (IP:المنفذ)",
        "e.g. 8.8.8.8:53" to "مثال: 8.8.8.8:53",
        "Tunnel domain (NS)" to "نطاق النفق (NS)",
        "Server public key (hex)" to "المفتاح العام للخادم (hex)",
        "Record type (optional)" to "نوع السجل (اختياري)",
        "e.g. txt or null. Leave empty for the default" to "مثال: txt أو null. اتركه فارغاً للافتراضي",
        "dnstt compatibility mode" to "وضع توافق dnstt",
        "Local listener (optional)" to "المستمع المحلي Local Listener (اختياري)",
        "e.g. 127.0.0.1:7000. Leave empty for an automatic port" to "مثال: 127.0.0.1:7000. اتركه فارغاً لمنفذ تلقائي",
        "Use a port or 127.0.0.1:port" to "اكتب منفذاً أو 127.0.0.1:المنفذ",
        "Invalid local listener" to "المستمع المحلي غير صالح",
        "Invalid tunnel domain" to "نطاق النفق غير صالح",
        "Invalid DNS resolver (use -udp IPv4:port)" to "خادم DNS غير صالح (استخدم -udp IPv4:المنفذ)",
        "DoH/DoT is not supported, use -udp" to "DoH/DoT غير مدعوم، استخدم -udp",
        "VayDNS: a direct connection through the VayDNS tunnel (no SSH or V2Ray)." to "VayDNS: اتصال مباشر عبر نفق VayDNS (بدون SSH أو V2Ray).",
        "DNS transport" to "نقل DNS",
        "DoT resolver" to "خادم DoT (Resolver)",
        "DoH URL" to "رابط DoH",
        "Show advanced settings" to "إظهار الإعدادات المتقدمة",
        "Hide advanced settings" to "إخفاء الإعدادات المتقدمة",
        "Idle timeout (s)" to "مهلة الخمول (ث)",
        "Keepalive (s)" to "الإبقاء حيًّا (ث)",
        "Max QNAME length" to "أقصى طول QNAME",
        "Max labels (0 = any)" to "أقصى عدد تسميات (0 = أي عدد)",
        "Queries per second (0 = unlimited)" to "استعلامات في الثانية (0 = بلا حد)",
        "UDP workers" to "عمال UDP",
        "UDP timeout (ms)" to "مهلة UDP (م.ث)",
        "Client ID size" to "حجم معرّف العميل",
        "Open stream timeout (s)" to "مهلة فتح الـ stream (ث)",
        "TLS fingerprint (uTLS, optional)" to "بصمة TLS (uTLS، اختياري)",
        "Engine log level" to "مستوى سجل المحرك",
        "Extra client flags (optional)" to "خيارات إضافية للعميل (اختياري)",
        "UDP resolver" to "خادم UDP (Resolver)",
        "Tunnel domain" to "نطاق النفق",
        "Server public key" to "المفتاح العام للخادم",
        "What the server forwards to" to "ما يمرّره الخادم إليه",
        "SOCKS5 proxy" to "وكيل SOCKS5",
        "Only the UDP DNS transport is supported" to "يدعم التطبيق نقل UDP فقط",
        "Only SOCKS5 proxy forwarding is supported" to "يدعم التطبيق تمرير SOCKS5 فقط",
        "Authentication (username & password)" to "المصادقة (اسم المستخدم وكلمة المرور)",
        "Enable payload" to "تفعيل Payload",
        "Tags: [crlf] [host] [port] [host_port]" to "الوسوم: [crlf] [host] [port] [host_port]",
        "Remote proxy" to "الوكيل البعيد",
        "Path" to "المسار",
        "Host header" to "ترويسة Host",
        "[host] = server address" to "[host] = عنوان الخادم",
        "SNI version" to "إصدار SNI",
        "Fingerprint" to "البصمة",
        "ALPN (e.g. h2,http/1.1)" to "ALPN (مثال: h2,http/1.1)",
        "Allow insecure" to "السماح بغير الآمن",
        "Apply" to "تطبيق",
        "Edit config" to "تعديل الكونفيج",
        "New config" to "كونفيج جديد",
        "Config imported" to "تم استيراد الكونفيج",
        "Enter an IPv4 address, e.g. 8.8.8.8:53" to "أدخل عنوان IPv4، مثال: 8.8.8.8:53",
        "Enter a valid domain" to "أدخل نطاقاً صالحاً",
        "64 hex characters" to "64 خانة hex",
        "Required" to "مطلوب",
        "IP address" to "عنوان IP",
        "Connections" to "الاتصالات",
        "On the other device, set the Wi‑Fi proxy to Manual (HTTP) using the IP address and port shown above." to "على الجهاز الآخر، اجعل وكيل Wi‑Fi يدوياً (HTTP) باستخدام عنوان IP والمنفذ الظاهرين أعلاه.",
        "Use a port between 1024 and 65535" to "استخدم منفذاً بين 1024 و65535",
        "Enter a valid IPv4 address" to "أدخل عنوان IPv4 صالحاً",
        "Reconnecting VPN to apply the fixed IP" to "إعادة اتصال VPN لتطبيق IP الثابت",
        "Could not start the proxy" to "تعذّر تشغيل الوكيل",
        "Fixed IP needs an active VPN. Showing the hotspot address for now." to "IP الثابت يحتاج VPN نشطاً. يُعرض عنوان نقطة الاتصال حالياً.",
        "Applying the fixed IP… the VPN will reconnect." to "جارٍ تطبيق IP الثابت… سيُعاد اتصال VPN.",
        "Traffic goes through the VPN tunnel." to "حركة المرور تمر عبر نفق VPN.",
        "VPN is reconnecting; sharing is paused to avoid leaks." to "VPN يعيد الاتصال؛ المشاركة متوقفة لتجنب التسريب.",
        "VPN is off: sharing your direct connection." to "VPN متوقف: تتم مشاركة اتصالك المباشر.",
        "Checked through the VPN tunnel" to "تم الفحص عبر نفق VPN",
        "Checked on your direct connection (VPN off)" to "تم الفحص على اتصالك المباشر (VPN متوقف)",
        "Loading..." to "جارٍ التحميل...",
        "Unavailable" to "غير متاح",
        "Could not get IP info" to "تعذّر جلب معلومات IP",
        "network error" to "خطأ في الشبكة",
        "Map unavailable" to "الخريطة غير متاحة",
        "Unknown" to "غير معروف",
        "Country" to "الدولة",
        "Continent" to "القارة",
        "Region" to "المنطقة",
        "City" to "المدينة",
        "Postal code" to "الرمز البريدي",
        "Organization" to "المؤسسة",
        "ISP" to "مزوّد الخدمة",
        "Domain" to "النطاق",
        "Coordinates" to "الإحداثيات",
        "Timezone" to "المنطقة الزمنية",
        "Currency" to "العملة",
        "Calling code" to "رمز الاتصال",
        "Share net is on" to "مشاركة الشبكة قيد التشغيل",
        "HTTP proxy" to "وكيل HTTP",
        "Stop sharing" to "إيقاف المشاركة",
        "General" to "عام",
        "Language" to "اللغة",
        "Theme" to "المظهر",
        "Dark" to "مظلم",
        "Light" to "مشرق",
        "Speed unit" to "وحدة السرعة",
        "Byte (MB/s)" to "بايت (MB/s)",
        "Speed test" to "اختبار السرعة",
        "Start" to "ابدأ",
        "Stop" to "إيقاف",
        "Test again" to "أعد الاختبار",
        "Results" to "النتائج",
        "Ping" to "الاستجابة (Ping)",
        "Jitter" to "التذبذب (Jitter)",
        "Mbps" to "Mbps",
        "Your connection is good for" to "اتصالك مناسب لـ",
        "Browsing" to "التصفح",
        "Video streaming" to "تشغيل الفيديوهات",
        "Live streams" to "البثوث المباشرة",
        "Gaming" to "الألعاب",
        "Excellent" to "ممتاز",
        "Good" to "جيد",
        "Fair" to "متوسط",
        "Poor" to "ضعيف",
        "Up to" to "حتى",
        "Going live:" to "بث من هاتفك:",
        "Testing upload..." to "جارٍ اختبار الرفع...",
        "Testing download..." to "جارٍ اختبار التحميل...",
        "Testing ping..." to "جارٍ اختبار الاستجابة...",
        "Test complete" to "اكتمل الاختبار",
        "Speed test failed" to "فشل اختبار السرعة",
        "Tested through the VPN tunnel" to "تم الاختبار عبر نفق VPN",
        "Tested on your direct connection (VPN off)" to "تم الاختبار على اتصالك المباشر (VPN متوقف)",
        "Long-press a config and drag to reorder" to "اضغط مطولًا على كونفيج ثم حركه لتغيير الترتيب",
        "Bit (Mb/s)" to "بت (Mb/s)"
    )
    private val ci: Map<String, String> by lazy { map.mapKeys { it.key.lowercase() } }

    fun t(s: String): String = if (!ar) s else (map[s] ?: ci[s.lowercase()] ?: s)

    /**
     * في العربية: النص اللاتيني يلتصق بجهة البداية (اليمين) كالعربي بدل أن يبقى على اليسار.
     * لا يلمس الأزرار والمفاتيح وحقول الإدخال ولا النصوص المتمركزة ولا نص السجل.
     */
    fun align(v: View) {
        if (!ar) return
        if (v is TextView && v !is EditText && v !is Button && v !is CompoundButton && v.id != R.id.tvLogs) {
            val h = v.gravity and (Gravity.START or Gravity.END)
            if (h == Gravity.START || h == 0) v.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) align(v.getChildAt(i))
    }

    /** مفتاح تبديل يبقى بلا عكس: الاسم على اليسار والمفتاح على اليمين في اللغتين. */
    fun keepLtr(v: TextView) {
        v.layoutDirection = View.LAYOUT_DIRECTION_LTR
        v.textDirection = View.TEXT_DIRECTION_LTR
        v.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    /** عمود القيم (أرقام وعناوين): اتجاه لاتيني، ويُلصق بطرف النهاية (أقصى اليسار في العربية). */
    fun value(v: TextView) {
        v.textDirection = View.TEXT_DIRECTION_LTR
        v.textAlignment = if (ar) View.TEXT_ALIGNMENT_VIEW_END else View.TEXT_ALIGNMENT_VIEW_START
    }

    /** يترجم النصوص الثابتة لشجرة عناصر (بعد تضخيم ملف تخطيط أو بناء صفحة). لا يلمس حقول الإدخال. */
    fun view(v: View) {
        if (!ar) return
        if (v is TextInputLayout) {
            v.hint?.toString()?.let { v.hint = t(it) }
            v.helperText?.toString()?.let { v.helperText = t(it) }
        } else if (v is TextView && v !is EditText) {
            val s = v.text?.toString().orEmpty()
            if (s.isNotEmpty()) v.text = t(s)
        }
        v.contentDescription?.toString()?.let { v.contentDescription = t(it) }
        if (v is ViewGroup) for (i in 0 until v.childCount) view(v.getChildAt(i))
    }
}
