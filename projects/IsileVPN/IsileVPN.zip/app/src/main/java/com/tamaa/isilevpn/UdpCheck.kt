package com.tamaa.isilevpn

import java.io.DataInputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom

/**
 * فحص دعم UDP بعد الاتصال: عبر منفذ SOCKS المحلي (UDP ASSOCIATE) نرسل طلب STUN (منفذ غير 53)،
 * فإن لم يصل رد نجرّب استعلام DNS. النتيجة: SUPPORTED أو DNS_ONLY أو NONE.
 */
object UdpCheck {
    enum class Result { SUPPORTED, DNS_ONLY, NONE }

    private val stunServers = listOf("stun.l.google.com" to 19302, "stun.cloudflare.com" to 3478)

    fun run(): Result {
        for ((h, p) in stunServers) if (exchange(h, p, stunRequest()) { r -> r.size >= 20 && r[4] == 0x21.toByte() && r[5] == 0x12.toByte() }) return Result.SUPPORTED
        val dns = byteArrayOf(0x12, 0x34, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 7, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(), 'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(), 3, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0, 0, 1, 0, 1)
        if (exchange("8.8.8.8", 53, dns) { r -> r.size >= 12 && r[0] == 0x12.toByte() && r[1] == 0x34.toByte() }) return Result.DNS_ONLY
        return Result.NONE
    }

    private fun stunRequest(): ByteArray {
        val b = ByteArray(20)
        b[1] = 1 // Binding Request
        b[4] = 0x21; b[5] = 0x12; b[6] = 0xA4.toByte(); b[7] = 0x42 // magic cookie
        val t = ByteArray(12); SecureRandom().nextBytes(t)
        System.arraycopy(t, 0, b, 8, 12)
        return b
    }

    private fun exchange(host: String, port: Int, payload: ByteArray, ok: (ByteArray) -> Boolean): Boolean {
        try {
            Socket().use { ctl ->
                ctl.connect(InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT), 4000)
                ctl.soTimeout = 4000
                val o = ctl.getOutputStream()
                val i = DataInputStream(ctl.getInputStream())
                o.write(byteArrayOf(5, 1, 0)); o.flush()
                i.readUnsignedByte(); i.readUnsignedByte()
                o.write(byteArrayOf(5, 3, 0, 1, 0, 0, 0, 0, 0, 0)); o.flush()
                i.readUnsignedByte()
                if (i.readUnsignedByte() != 0) return false
                i.readUnsignedByte()
                val bndPort: Int
                when (i.readUnsignedByte()) {
                    1 -> { i.readFully(ByteArray(4)) }
                    4 -> { i.readFully(ByteArray(16)) }
                    3 -> { i.readFully(ByteArray(i.readUnsignedByte())) }
                    else -> return false
                }
                bndPort = i.readUnsignedShort()
                val hb = host.toByteArray(Charsets.ISO_8859_1)
                val pkt = byteArrayOf(0, 0, 0, 3, hb.size.toByte()) + hb + byteArrayOf((port shr 8).toByte(), (port and 0xff).toByte()) + payload
                DatagramSocket().use { ds ->
                    ds.soTimeout = 4000
                    val to = InetAddress.getByName("127.0.0.1")
                    ds.send(DatagramPacket(pkt, pkt.size, to, bndPort))
                    val buf = ByteArray(2048)
                    val rp = DatagramPacket(buf, buf.size)
                    ds.receive(rp)
                    val d = buf.copyOfRange(0, rp.length)
                    if (d.size < 10) return false
                    val hl = when (d[3].toInt()) { 1 -> 10; 4 -> 22; 3 -> 7 + (d[4].toInt() and 0xff); else -> return false }
                    if (d.size <= hl) return false
                    return ok(d.copyOfRange(hl, d.size))
                }
            }
        } catch (_: Exception) {
            return false
        }
    }
}
