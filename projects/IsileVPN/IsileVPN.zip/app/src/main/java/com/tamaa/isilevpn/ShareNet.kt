package com.tamaa.isilevpn

import android.content.Context
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Proxy
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** إعدادات مشاركة الشبكة. */
object ShareCfg {
    const val DEF_PORT = 8080
    /** هو نفسه عنوان واجهة النفق، لذلك يعمل دون إعادة اتصال. */
    const val DEF_FIXED = "10.10.14.1"

    private fun sp(c: Context) = c.getSharedPreferences("isile_share", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
    fun port(c: Context) = sp(c).getInt("port", DEF_PORT)
    fun setPort(c: Context, v: Int) = sp(c).edit().putInt("port", v).apply()
    fun fixedOn(c: Context) = sp(c).getBoolean("fixed_on", false)
    fun setFixedOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("fixed_on", v).apply()
    fun fixedIp(c: Context) = sp(c).getString("fixed_ip", DEF_FIXED) ?: DEF_FIXED
    fun setFixedIp(c: Context, v: String) = sp(c).edit().putString("fixed_ip", v).apply()

    fun validIp(s: String): Boolean {
        val p = s.trim().split(".")
        if (p.size != 4) return false
        val n = p.map { it.toIntOrNull() ?: return false }
        if (n.any { it !in 0..255 }) return false
        return n[0] in 1..223 && n[0] != 127 && n[3] != 0 && n[3] != 255
    }
}

/** العنوان الذي تستعمله الأجهزة الأخرى للوصول إلى الخادم (دون الاعتماد على نوع الهاتف). */
object ShareNet {
    private val skip = Regex("^(lo|tun\\d*|dummy.*|rmnet.*|ccmni.*|v4-.*|clat.*|ifb.*|sit.*|ip6.*|gre.*|wg.*)$")

    /**
     * أول عنوان IPv4 خاص (192.168/10/172.16) على واجهة شغّالة غير النفق وغير بيانات الجوال.
     * الواجهات التي يكون الهاتف فيها هو البوابة (آخر خانة 1) تُفضَّل لأنها نقطة الاتصال عادةً.
     */
    fun shareIp(): String? {
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return null
            val found = ArrayList<String>()
            for (ni in Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback || skip.matches(ni.name.lowercase())) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) {
                        val ip = a.hostAddress ?: continue
                        if (ip == ShareCfg.DEF_FIXED) continue // عنوان واجهة النفق
                        found.add(ip)
                    }
                }
            }
            return found.firstOrNull { it.endsWith(".1") } ?: found.firstOrNull()
        } catch (_: Exception) {
        }
        return null
    }
}

/**
 * خادم HTTP proxy بسيط (HTTP + CONNECT). أثناء اتصال الـ VPN يمرّر الطلبات عبر منفذ SOCKS المحلي
 * (أي عبر النفق)، وعند عدم الاتصال يخرج مباشرة. يقبل الاتصالات من الشبكات الخاصة فقط.
 */
object ShareProxy {
    @Volatile var running = false
    @Volatile var error = ""
    val up = AtomicLong()
    val down = AtomicLong()
    val active = AtomicInteger()

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool { r -> Thread(r).apply { isDaemon = true } }
    private val open = Collections.synchronizedSet(HashSet<Socket>())

    @Synchronized
    fun start(port: Int): Boolean {
        stop()
        error = ""
        up.set(0); down.set(0); active.set(0)
        return try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(port))
            server = ss
            running = true
            Thread { acceptLoop(ss) }.apply { isDaemon = true }.start()
            true
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
            running = false
            false
        }
    }

    @Synchronized
    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        server = null
        synchronized(open) { open.toList() }.forEach { try { it.close() } catch (_: Exception) {} }
        open.clear()
    }

    private fun allowed(a: InetAddress) = a.isLoopbackAddress || a.isSiteLocalAddress || a.isLinkLocalAddress

    private fun acceptLoop(ss: ServerSocket) {
        while (running && !ss.isClosed) {
            val s = try { ss.accept() } catch (_: Exception) { break }
            if (!allowed(s.inetAddress)) { try { s.close() } catch (_: Exception) {}; continue }
            pool.execute { handle(s) }
        }
    }

    private fun track(s: Socket) { open.add(s) }
    private fun untrack(s: Socket) { open.remove(s); try { s.close() } catch (_: Exception) {} }

    private fun connectUpstream(host: String, port: Int): Socket {
        val st = Bus.state
        if (st == State.CONNECTING) throw IOException("VPN is reconnecting") // لا تسرّب خارج النفق
        val s: Socket
        if (st == State.CONNECTED) {
            s = Socket(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT)))
            track(s)
            s.connect(InetSocketAddress.createUnresolved(host, port), 15000)
        } else {
            s = Socket()
            track(s)
            s.connect(InetSocketAddress(host, port), 15000)
        }
        s.tcpNoDelay = true
        return s
    }

    private fun fail(out: OutputStream, code: String) {
        try {
            out.write("HTTP/1.1 $code\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
            out.flush()
        } catch (_: Exception) {}
    }

    /** يقرأ الترويسة حتى \r\n\r\n ويعيدها مع أي بيانات زائدة قُرئت بعدها. */
    private fun readHead(inp: InputStream): Pair<String, ByteArray>? {
        val buf = ByteArrayOutputStream()
        val chunk = ByteArray(4096)
        while (buf.size() < 32768) {
            val n = inp.read(chunk)
            if (n < 0) return null
            buf.write(chunk, 0, n)
            val b = buf.toByteArray()
            val i = indexOf(b, "\r\n\r\n".toByteArray())
            if (i >= 0) {
                val head = String(b, 0, i, Charsets.ISO_8859_1)
                return head to b.copyOfRange(i + 4, b.size)
            }
        }
        return null
    }

    private fun indexOf(a: ByteArray, p: ByteArray): Int {
        outer@ for (i in 0..a.size - p.size) {
            for (j in p.indices) if (a[i + j] != p[j]) continue@outer
            return i
        }
        return -1
    }

    private fun handle(client: Socket) {
        track(client)
        active.incrementAndGet()
        var upstream: Socket? = null
        try {
            client.soTimeout = 30000
            val cin = BufferedInputStream(client.getInputStream())
            val cout = client.getOutputStream()
            val (head, extra) = readHead(cin) ?: return
            client.soTimeout = 0
            val lines = head.split("\r\n")
            val first = lines[0].split(" ")
            if (first.size < 3) { fail(cout, "400 Bad Request"); return }
            val method = first[0]
            val target = first[1]
            val ver = first[2]

            if (method.equals("CONNECT", true)) {
                val (h, p) = splitHostPort(target, 443)
                upstream = try { connectUpstream(h, p) } catch (e: Exception) { fail(cout, "502 Bad Gateway"); return }
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                cout.flush()
                if (extra.isNotEmpty()) { upstream.getOutputStream().write(extra); up.addAndGet(extra.size.toLong()) }
            } else {
                var host: String
                var port = 80
                var path: String
                if (target.startsWith("http://", true)) {
                    val rest = target.substring(7)
                    val slash = rest.indexOf('/')
                    val hp = if (slash >= 0) rest.substring(0, slash) else rest
                    path = if (slash >= 0) rest.substring(slash) else "/"
                    val r = splitHostPort(hp, 80); host = r.first; port = r.second
                } else if (target.startsWith("/")) {
                    val hostHdr = lines.drop(1).firstOrNull { it.startsWith("Host:", true) }?.substring(5)?.trim()
                    if (hostHdr.isNullOrEmpty()) { fail(cout, "400 Bad Request"); return }
                    val r = splitHostPort(hostHdr, 80); host = r.first; port = r.second
                    path = target
                } else { fail(cout, "400 Bad Request"); return }
                upstream = try { connectUpstream(host, port) } catch (e: Exception) { fail(cout, "502 Bad Gateway"); return }
                val sb = StringBuilder("$method $path $ver\r\n")
                for (l in lines.drop(1)) {
                    val name = l.substringBefore(':').trim().lowercase()
                    if (name in setOf("proxy-connection", "connection", "keep-alive", "proxy-authorization", "")) continue
                    sb.append(l).append("\r\n")
                }
                sb.append("Connection: close\r\n\r\n")
                val hb = sb.toString().toByteArray(Charsets.ISO_8859_1)
                val uo = upstream.getOutputStream()
                uo.write(hb); uo.write(extra); uo.flush()
                up.addAndGet((hb.size + extra.size).toLong())
            }
            pipe(client, cin, cout, upstream)
        } catch (_: Exception) {
        } finally {
            active.decrementAndGet()
            untrack(client)
            upstream?.let { untrack(it) }
        }
    }

    private fun splitHostPort(s: String, def: Int): Pair<String, Int> {
        if (s.startsWith("[")) {
            val e = s.indexOf(']')
            val h = s.substring(1, e)
            val p = s.substring(e + 1).removePrefix(":").toIntOrNull() ?: def
            return h to p
        }
        val i = s.lastIndexOf(':')
        return if (i > 0 && s.indexOf(':') == i) s.substring(0, i) to (s.substring(i + 1).toIntOrNull() ?: def) else s to def
    }

    private fun pipe(client: Socket, cin: InputStream, cout: OutputStream, upstream: Socket) {
        val uin = upstream.getInputStream()
        val uout = upstream.getOutputStream()
        val t = Thread {
            copy(uin, cout, down)
            try { client.shutdownOutput() } catch (_: Exception) {}
        }.apply { isDaemon = true; start() }
        copy(cin, uout, up)
        try { upstream.shutdownOutput() } catch (_: Exception) {}
        try { t.join(20000) } catch (_: InterruptedException) {}
    }

    private fun copy(i: InputStream, o: OutputStream, counter: AtomicLong) {
        val buf = ByteArray(16384)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
                counter.addAndGet(n.toLong())
            }
        } catch (_: Exception) {
        }
    }
}
