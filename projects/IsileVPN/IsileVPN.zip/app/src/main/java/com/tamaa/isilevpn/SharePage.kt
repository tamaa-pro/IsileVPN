package com.tamaa.isilevpn

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/** صفحة Share net: مشاركة الاتصال عبر نقطة الاتصال كـ HTTP proxy. */
class SharePage(private val act: Activity, private val root: View) {
    private val msg: TextView = root.findViewById(R.id.shMsg)
    private val rows: LinearLayout = root.findViewById(R.id.shRows)
    private val sw: MaterialSwitch = root.findViewById(R.id.shSwitch)
    private val port: TextInputEditText = root.findViewById(R.id.shPort)
    private val fixedSw: MaterialSwitch = root.findViewById(R.id.shFixedSwitch)
    private val fixedLayout: TextInputLayout = root.findViewById(R.id.shFixedLayout)
    private val fixedIp: TextInputEditText = root.findViewById(R.id.shFixedIp)
    private val hint: TextView = root.findViewById(R.id.shHint)

    private val h = Handler(Looper.getMainLooper())
    private var shown = false
    private var building = false

    private val vAddr = valueView()
    private val vPort = valueView()
    private val vUp = valueView()
    private val vDown = valueView()
    private val vConn = valueView()
    private val vNote = TextView(act).apply {
        textSize = 12f
        setTextColor(col(R.color.amber))
        setPadding(dp(4), dp(8), dp(4), 0)
    }

    private var lastUp = 0L
    private var lastDown = 0L

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density + 0.5f).toInt()
    private fun col(id: Int) = ContextCompat.getColor(act, id)

    private fun valueView() = TextView(act).apply {
        Tr.value(this)
        textSize = 14f
        gravity = Gravity.START
        setTextColor(col(R.color.text))
        setTextIsSelectable(true)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!shown) return
            render()
            h.postDelayed(this, 1000)
        }
    }

    init {
        // الصفوف تُبنى مرة واحدة وتُحدَّث قيمها فقط
        fun add(label: String, v: TextView, first: Boolean = false) {
            if (!first) rows.addView(View(act).apply { setBackgroundColor(col(R.color.outline)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), dp(11), dp(4), dp(11))
            }
            row.addView(TextView(act).apply {
                text = Tr.t(label)
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                textSize = 14f
                setTextColor(col(R.color.text_dim))
            }, LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            rows.addView(row)
        }
        add("IP address", vAddr, true)
        add("Port", vPort)
        add("Upload", vUp)
        add("Download", vDown)
        add("Connections", vConn)
        rows.addView(vNote)

        hint.text = Tr.t("On the other device, set the Wi‑Fi proxy to Manual (HTTP) using the IP address and port shown above.")

        sw.setOnCheckedChangeListener { _, on ->
            if (building) return@setOnCheckedChangeListener
            if (on) {
                if (!applyPort()) { building = true; sw.isChecked = false; building = false; return@setOnCheckedChangeListener }
                ShareCfg.setEnabled(act, true)
                ShareService.start(act)
                ensureFixedApplied()
            } else {
                ShareCfg.setEnabled(act, false)
                ShareService.stop(act)
            }
            render()
        }

        port.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { applyPort(); hideKb(v); true } else false
        }
        port.setOnFocusChangeListener { _, f -> if (!f) applyPort() }

        fixedSw.setOnCheckedChangeListener { _, on ->
            if (building) return@setOnCheckedChangeListener
            ShareCfg.setFixedOn(act, on)
            fixedLayout.visibility = if (on) View.VISIBLE else View.GONE
            if (on) applyFixed()
            render()
        }
        fixedIp.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { applyFixed(); hideKb(v); true } else false
        }
        fixedIp.setOnFocusChangeListener { _, f -> if (!f) applyFixed() }

        building = true
        port.setText(ShareCfg.port(act).toString())
        fixedIp.setText(ShareCfg.fixedIp(act))
        building = false
    }

    private fun hideKb(v: View) {
        v.clearFocus()
        (act.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    /** يتحقق من المنفذ ويحفظه، ويعيد تشغيل الخادم إن كان يعمل. */
    private fun applyPort(): Boolean {
        val p = port.text?.toString()?.trim()?.toIntOrNull()
        val til = port.parent.parent as? TextInputLayout
        if (p == null || p !in 1024..65535) {
            til?.error = Tr.t("Use a port between 1024 and 65535")
            return false
        }
        til?.error = null
        if (p != ShareCfg.port(act)) {
            ShareCfg.setPort(act, p)
            if (ShareCfg.enabled(act)) ShareService.start(act)
        }
        return true
    }

    private fun applyFixed(): Boolean {
        val v = fixedIp.text?.toString()?.trim().orEmpty()
        if (!ShareCfg.validIp(v)) {
            fixedLayout.error = Tr.t("Enter a valid IPv4 address")
            return false
        }
        fixedLayout.error = null
        ShareCfg.setFixedIp(act, v)
        ensureFixedApplied()
        return true
    }

    /** العنوان الثابت يُضاف لواجهة النفق عند الاتصال، فإن لم يكن مطبّقًا نعيد اتصال الـ VPN مرة واحدة. */
    private fun fixedEffective(): Boolean {
        val f = ShareCfg.fixedIp(act)
        return f == ShareCfg.DEF_FIXED || f == Bus.fixedApplied
    }

    private fun ensureFixedApplied() {
        if (!ShareCfg.enabled(act) || !ShareCfg.fixedOn(act)) return
        if (!ShareCfg.validIp(ShareCfg.fixedIp(act))) return
        if (Bus.state != State.CONNECTED || fixedEffective()) return
        Toast.makeText(act, Tr.t("Reconnecting VPN to apply the fixed IP"), Toast.LENGTH_SHORT).show()
        ContextCompat.startForegroundService(
            act, Intent(act, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_RECONNECT)
        )
    }

    fun show() {
        shown = true
        // إن كان التفعيل محفوظًا لكن الخادم متوقف (قتلت العملية مثلًا) نعيد تشغيله
        if (ShareCfg.enabled(act) && !ShareProxy.running) ShareService.start(act)
        building = true
        fixedSw.isChecked = ShareCfg.fixedOn(act)
        fixedLayout.visibility = if (fixedSw.isChecked) View.VISIBLE else View.GONE
        building = false
        lastUp = ShareProxy.up.get(); lastDown = ShareProxy.down.get()
        h.removeCallbacks(tick)
        tick.run()
    }

    fun hide() {
        shown = false
        h.removeCallbacks(tick)
    }

    private fun fmtBytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.2f MB", b / 1048576.0)
        else -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
    }

    private fun render() {
        val enabled = ShareCfg.enabled(act)
        building = true
        if (sw.isChecked != enabled) sw.isChecked = enabled
        building = false

        // المستطيل فارغ عند الإطفاء
        if (!enabled) {
            msg.visibility = View.GONE; rows.visibility = View.GONE
            return
        }
        if (ShareProxy.error.isNotEmpty()) {
            msg.visibility = View.VISIBLE
            msg.text = "${Tr.t("Could not start the proxy")}: ${ShareProxy.error}"
            rows.visibility = View.GONE
            return
        }
        val hs = ShareNet.shareIp() ?: "—"
        msg.visibility = View.GONE
        rows.visibility = View.VISIBLE

        val fixedWanted = ShareCfg.fixedOn(act) && ShareCfg.validIp(ShareCfg.fixedIp(act))
        val useFixed = fixedWanted && Bus.state == State.CONNECTED && fixedEffective()
        vAddr.text = if (useFixed) ShareCfg.fixedIp(act) else hs
        vPort.text = ShareCfg.port(act).toString()

        val u = ShareProxy.up.get()
        val d = ShareProxy.down.get()
        vUp.text = "↑ ${fmtBytes(u)}  (${Prefs.fmtSpeed(maxOf(0, u - lastUp))})"
        vDown.text = "↓ ${fmtBytes(d)}  (${Prefs.fmtSpeed(maxOf(0, d - lastDown))})"
        lastUp = u; lastDown = d
        vConn.text = ShareProxy.active.get().toString()

        vNote.text = when {
            fixedWanted && Bus.state != State.CONNECTED -> Tr.t("Fixed IP needs an active VPN. Showing the hotspot address for now.")
            fixedWanted && !useFixed -> Tr.t("Applying the fixed IP… the VPN will reconnect.")
            Bus.state == State.CONNECTED -> Tr.t("Traffic goes through the VPN tunnel.")
            Bus.state == State.CONNECTING -> Tr.t("VPN is reconnecting; sharing is paused to avoid leaks.")
            else -> Tr.t("VPN is off: sharing your direct connection.")
        }
    }
}
