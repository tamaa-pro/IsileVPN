package com.tamaa.isilevpn

import android.util.Base64
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Proxy
import com.jcraft.jsch.Session
import com.jcraft.jsch.UserInfo
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PushbackInputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * طبقة النقل لـ SSH. الترتيب: اتصال TCP (بالخادم أو بالريموت بروكسي) -> TLS (اختياري)
 * -> Payload / WebSocket / CONNECT (اختياري) -> تمرير خام لـ SSH.
 */
class TransportProxy(private val p: Profile) : Proxy {
    private var sock: Socket? = null
    private var ins: InputStream? = null
    private var outs: OutputStream? = null
    private val iso = Charsets.ISO_8859_1

    override fun connect(socketFactory: com.jcraft.jsch.SocketFactory?, host: String, port: Int, timeout: Int) {
        val dnsMode = p.isDns // نفق DNS: اتصال بالمنفذ المحلي (TLS/SNI اختياري) دون payload/ws/proxy
        val viaProxy = !dnsMode && p.proxyHost.isNotBlank()
        val connHost = if (viaProxy) p.proxyHost.trim() else host
        val connPort = if (viaProxy) p.proxyPort else port
        val raw = Socket()
        sock = raw // يُغلق من stop() حتى لو كان الاتصال ما زال جاريًا
        raw.tcpNoDelay = true
        if (viaProxy) Bus.log("Remote proxy: $connHost:$connPort")
        raw.connect(InetSocketAddress(connHost, connPort), timeout)
        raw.soTimeout = if (timeout > 0) timeout else 30000
        var s: Socket = raw
        if (p.tls) {
            val sni = Tags.field(p.sni, host, port).ifBlank { if (dnsMode) p.host.trim() else connHost }
            val ipLike = sni.all { it.isDigit() || it == '.' || it == ':' }
            Bus.log("TLS: $connHost:$connPort, SNI=$sni, version=${p.tlsVersion}" +
                if (ipLike) " (SNI is an IP address, so NO SNI will be sent - set a domain in SNI)" else "")
            val ssl = wrapTls(raw, sni, connPort)
            Bus.log("TLS handshake OK (SNI: $sni, ${ssl.session.protocol})")
            s = ssl
        }
        sock = s
        var input: InputStream = s.getInputStream()
        val output = s.getOutputStream()
        val pre: String? = when {
            dnsMode -> null
            p.payloadOn -> expand(p.payload, host, port)
            p.ws -> wsRequest(host)
            viaProxy -> "CONNECT $host:$port HTTP/1.1\r\nHost: $host:$port\r\n\r\n"
            else -> null
        }
        if (pre != null) {
            Bus.log(when {
                p.payloadOn -> "Sending custom payload..."
                p.ws -> "Sending WebSocket upgrade..."
                else -> "Sending proxy CONNECT..."
            })
            output.write(pre.toByteArray(iso))
            output.flush()
            input = skipHttp(input)
        }
        ins = input
        outs = output
    }

    private fun expand(t: String, host: String, port: Int): String =
        t.replace("\\r\\n", "\r\n").replace("[crlf]", "\r\n").replace("[lf]", "\n").replace("[cr]", "\r")
            .let { Tags.resolve(it, host, port) }

    private fun wsRequest(host: String): String {
        val key = Base64.encodeToString(ByteArray(16).also { SecureRandom().nextBytes(it) }, Base64.NO_WRAP)
        val h = Tags.field(p.wsHost, host, p.port).ifBlank { Tags.field(p.sni, host, p.port).ifBlank { host } }
        val path = p.wsPath.ifBlank { "/" }
        return "GET $path HTTP/1.1\r\nHost: $h\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
            "Sec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\nUser-Agent: Mozilla/5.0\r\n\r\n"
    }

    private fun wrapTls(raw: Socket, sni: String, port: Int): SSLSocket {
        val ctx = SSLContext.getInstance("TLS")
        if (p.insecure) {
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            ctx.init(null, arrayOf<TrustManager>(tm), SecureRandom())
        } else {
            ctx.init(null, null, null)
        }
        val ssl = ctx.socketFactory.createSocket(raw, sni, port, true) as SSLSocket
        runCatching {
            val prm = ssl.sslParameters
            prm.serverNames = listOf(SNIHostName(sni))
            ssl.sslParameters = prm
        }
        val v = when (p.tlsVersion) {
            "TLSv1.0" -> "TLSv1"
            "TLSv1.1", "TLSv1.2", "TLSv1.3" -> p.tlsVersion
            else -> null
        }
        if (v != null) {
            if (ssl.supportedProtocols.contains(v)) ssl.enabledProtocols = arrayOf(v)
            else Bus.log("TLS version ${p.tlsVersion} is not supported on this device, using default")
        }
        try {
            ssl.startHandshake()
        } catch (e: javax.net.ssl.SSLException) {
            try { ssl.close() } catch (_: Exception) {}
            val m = e.message.orEmpty()
            val why = if (m.contains("HANDSHAKE_FAILURE"))
                "server rejected the TLS handshake (usually wrong/missing SNI, or unsupported TLS version)"
            else m.lineSequence().firstOrNull().orEmpty()
            throw IOException("TLS failed (SNI: $sni, version: ${p.tlsVersion}): $why")
        }
        if (!p.insecure && !HttpsURLConnection.getDefaultHostnameVerifier().verify(sni, ssl.session)) {
            try { ssl.close() } catch (_: Exception) {}
            throw SSLPeerUnverifiedException("Certificate does not match SNI '$sni' (enable Allow insecure to skip)")
        }
        return ssl
    }

    /** يقرأ رد HTTP الأول (ويكرر إن جاء ردّ ثانٍ كـ "200 Connection established") ثم يعيد باقي البيانات. */
    private fun skipHttp(src: InputStream): InputStream {
        val pb = PushbackInputStream(src, 16384)
        var first = true
        var rounds = 0
        while (rounds < 4) {
            rounds++
            val buf = ByteArray(16384)
            var n = try {
                pb.read(buf, 0, buf.size)
            } catch (e: java.net.SocketTimeoutException) {
                if (first) throw e else return pb
            }
            if (n <= 0) {
                if (first) throw IOException("Server closed connection after payload") else return pb
            }
            if (!String(buf, 0, minOf(n, 5), iso).startsWith("HTTP/")) {
                pb.unread(buf, 0, n)
                if (first) Bus.app("Server did not answer with an HTTP response; continuing")
                return pb
            }
            var end = headerEnd(buf, n)
            while (end < 0) {
                if (n >= buf.size) throw IOException("HTTP response too large")
                val r = pb.read(buf, n, buf.size - n)
                if (r <= 0) throw IOException("Incomplete HTTP response")
                n += r
                end = headerEnd(buf, n)
            }
            val status = String(buf, 0, end, iso).lineSequence().first().trim()
            Bus.log(status)
            val code = status.split(" ").getOrNull(1)?.toIntOrNull() ?: 0
            if (code != 101 && code !in 200..299) throw IOException("Proxy rejected: $status")
            if (end < n) pb.unread(buf, end, n - end)
            first = false
        }
        return pb
    }

    private fun headerEnd(b: ByteArray, n: Int): Int {
        for (i in 0..n - 4) {
            if (b[i] == 13.toByte() && b[i + 1] == 10.toByte() && b[i + 2] == 13.toByte() && b[i + 3] == 10.toByte())
                return i + 4
        }
        return -1
    }

    override fun getInputStream(): InputStream? = ins
    override fun getOutputStream(): OutputStream? = outs
    override fun getSocket(): Socket? = sock
    override fun close() {
        try { sock?.close() } catch (_: Exception) {}
    }
}

/** جلسة SSH + خادم SOCKS5 محلي (CONNECT عبر direct-tcpip، وUDP للـ DNS فقط عبر TCP). */
class SshTunnel(private val p: Profile, private val onLost: () -> Unit) {
    private var session: Session? = null
    private var server: ServerSocket? = null
    private val proxy = TransportProxy(p)
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var stopped = false
    @Volatile private var running = false

    private class Chan(val ch: ChannelDirectTCPIP, val ins: InputStream, val outs: OutputStream)

    fun start(targetHost: String, targetPort: Int, timeoutMs: Int) {
        Bus.log("SSH: Initializing...")
        val s = JSch().getSession(p.user, targetHost, targetPort)
        s.setPassword(p.pass)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setConfig("PreferredAuthentications", "password,keyboard-interactive")
        s.setProxy(proxy)
        s.setServerAliveInterval(25000)
        s.setServerAliveCountMax(3)
        s.setDaemonThread(true)
        // مهم للسرعة: JSch يقرأ كل قنوات الجلسة بخيط واحد ويمرّر بيانات كل قناة عبر أنبوب حجمه 32KB افتراضيًا
        // غير قابل للتمدد. عند امتلاء الأنبوب (القارئ أبطأ لحظيًا) يتوقف الخيط الوحيد فتتوقف كل الاتصالات الأخرى
        // وتتأخر إشعارات نافذة الاستقبال فيتباطأ التنزيل. رفع الحد يجعل الأنبوب يتمدد (النافذة 1MB تحدّ الذاكرة).
        s.setConfig("max_input_buffer_size", (1024 * 1024).toString())
        // رسالة الخادم (Banner) تظهر في السجل
        s.setUserInfo(object : UserInfo {
            override fun getPassphrase(): String? = null
            override fun getPassword(): String? = p.pass
            override fun promptPassword(message: String?) = true
            override fun promptPassphrase(message: String?) = false
            override fun promptYesNo(message: String?) = true
            override fun showMessage(message: String?) {
                // رسالة واحدة (قد تمتد على أسطر وتتشارك وسم لون واحد) فلا نقسمها
                val lines = message?.lineSequence()?.map { it.trimEnd() }?.filter { it.isNotBlank() }?.toList()
                if (!lines.isNullOrEmpty()) Bus.log("Server: " + lines.joinToString(Bus.NL.toString()))
            }
        })
        session = s
        Bus.log("SSH: Connecting to $targetHost:$targetPort, timeout ${timeoutMs / 1000} seconds")
        try {
            s.connect(timeoutMs)
        } catch (e: Exception) {
            if (stopped) throw CancelledException()
            throw e
        }
        if (stopped) {
            try { s.disconnect() } catch (_: Exception) {}
            throw CancelledException()
        }
        Bus.log("SSH: Authenticated as ${p.user}")

        // منفذ SOCKS المحلي: نعيد المحاولة قليلًا إن كان المنفذ ما زال محجوزًا من محاولة سابقة
        var ss: ServerSocket? = null
        var err: Exception? = null
        for (i in 0 until 10) {
            if (stopped) break
            try {
                val c = ServerSocket()
                c.reuseAddress = true
                c.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), XrayConfig.SOCKS_PORT), 128)
                ss = c
                break
            } catch (e: IOException) {
                err = e
                try { Thread.sleep(300) } catch (_: InterruptedException) { break }
            }
        }
        if (ss == null) {
            try { s.disconnect() } catch (_: Exception) {}
            if (stopped) throw CancelledException()
            throw IOException("Local SOCKS port ${XrayConfig.SOCKS_PORT} is busy: ${err?.message}")
        }
        synchronized(this) {
            if (stopped) {
                try { ss.close() } catch (_: Exception) {}
                try { s.disconnect() } catch (_: Exception) {}
                throw CancelledException()
            }
            server = ss
            running = true
        }
        Bus.log("SSH: Connected successfully")
        val srv = ss
        try {
            pool.execute {
                while (running) {
                    val c = try { srv.accept() } catch (_: Exception) { break }
                    try {
                        pool.execute { handle(c) }
                    } catch (_: java.util.concurrent.RejectedExecutionException) {
                        try { c.close() } catch (_: Exception) {}
                        break
                    }
                }
            }
            pool.execute {
                while (running) {
                    try { Thread.sleep(5000) } catch (_: InterruptedException) { break }
                    if (running && session?.isConnected != true) {
                        Bus.log("SSH: Connection lost")
                        onLost()
                        break
                    }
                }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            throw CancelledException()
        }
    }

    @Synchronized
    fun stop() {
        stopped = true
        running = false
        try { proxy.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        server = null
        try { session?.disconnect() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun openDirect(host: String, port: Int): Chan {
        val s = session ?: throw IOException("No SSH session")
        val ch = s.openChannel("direct-tcpip") as ChannelDirectTCPIP
        ch.setHost(host)
        ch.setPort(port)
        val i = ch.inputStream
        val o = ch.outputStream
        ch.connect(15000)
        return Chan(ch, i, o)
    }

    private fun readAddr(i: DataInputStream, atyp: Int): String = when (atyp) {
        1 -> { val b = ByteArray(4); i.readFully(b); InetAddress.getByAddress(b).hostAddress ?: "" }
        4 -> { val b = ByteArray(16); i.readFully(b); InetAddress.getByAddress(b).hostAddress ?: "" }
        3 -> { val l = i.readUnsignedByte(); val b = ByteArray(l); i.readFully(b); String(b, Charsets.ISO_8859_1) }
        else -> throw IOException("Bad address type")
    }

    private fun handle(c: Socket) {
        try {
            c.tcpNoDelay = true
            val inp = DataInputStream(BufferedInputStream(c.getInputStream()))
            val out = c.getOutputStream()
            if (inp.readUnsignedByte() != 5) return
            val n = inp.readUnsignedByte()
            inp.readFully(ByteArray(n))
            out.write(byteArrayOf(5, 0)); out.flush()
            inp.readUnsignedByte()
            val cmd = inp.readUnsignedByte()
            inp.readUnsignedByte()
            val host = readAddr(inp, inp.readUnsignedByte())
            val port = inp.readUnsignedShort()
            when (cmd) {
                1 -> connectCmd(c, inp, out, host, port)
                3 -> udpCmd(inp, out)
                else -> { out.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); out.flush() }
            }
        } catch (_: Exception) {
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
    }

    private fun connectCmd(c: Socket, inp: InputStream, out: OutputStream, host: String, port: Int) {
        val ch = try {
            openDirect(host, port)
        } catch (e: Exception) {
            out.write(byteArrayOf(5, 5, 0, 1, 0, 0, 0, 0, 0, 0)); out.flush()
            return
        }
        out.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); out.flush()
        val t = Thread {
            try { copy(ch.ins, out) } catch (_: Exception) {}
            try { ch.ch.disconnect() } catch (_: Exception) {}
            try { c.close() } catch (_: Exception) {}
        }
        t.isDaemon = true
        t.start()
        try { copy(inp, ch.outs) } catch (_: Exception) {
        } finally {
            try { ch.ch.disconnect() } catch (_: Exception) {}
        }
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val b = ByteArray(32768)
        while (true) {
            val n = i.read(b)
            if (n < 0) break
            o.write(b, 0, n)
            o.flush()
        }
    }

    // ---- UDP ASSOCIATE: نمرّر استعلامات DNS (المنفذ 53) فقط، عبر DNS-over-TCP داخل نفق SSH ----
    private fun udpCmd(inp: InputStream, out: OutputStream) {
        val ds = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        val prt = ds.localPort
        out.write(byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, (prt shr 8).toByte(), (prt and 0xff).toByte()))
        out.flush()
        pool.execute {
            val buf = ByteArray(65535)
            while (!ds.isClosed) {
                val pkt = DatagramPacket(buf, buf.size)
                try { ds.receive(pkt) } catch (_: Exception) { break }
                val data = pkt.data.copyOfRange(0, pkt.length)
                val client = pkt.socketAddress
                pool.execute { udpHandle(ds, data, client) }
            }
        }
        try { while (inp.read() >= 0) { /* keep control connection open */ } } catch (_: Exception) {}
        ds.close()
    }

    private fun udpHandle(ds: DatagramSocket, d: ByteArray, client: java.net.SocketAddress) {
        try {
            if (d.size < 10 || d[2].toInt() != 0) return
            var o = 4
            val host: String
            when (d[3].toInt()) {
                1 -> { host = InetAddress.getByAddress(d.copyOfRange(4, 8)).hostAddress ?: return; o = 8 }
                4 -> { host = InetAddress.getByAddress(d.copyOfRange(4, 20)).hostAddress ?: return; o = 20 }
                3 -> { val l = d[4].toInt() and 0xff; host = String(d, 5, l, Charsets.ISO_8859_1); o = 5 + l }
                else -> return
            }
            val port = ((d[o].toInt() and 0xff) shl 8) or (d[o + 1].toInt() and 0xff)
            o += 2
            if (port != 53) return
            val resp = dnsOverSsh(host, d.copyOfRange(o, d.size)) ?: return
            val r = d.copyOfRange(0, o) + resp
            ds.send(DatagramPacket(r, r.size, client))
        } catch (_: Exception) {}
    }

    private fun dnsOverSsh(host: String, q: ByteArray): ByteArray? {
        val ch = try { openDirect(host, 53) } catch (_: Exception) { return null }
        val f = pool.submit(Callable<ByteArray> {
            ch.outs.write(byteArrayOf((q.size shr 8).toByte(), (q.size and 0xff).toByte()))
            ch.outs.write(q)
            ch.outs.flush()
            val di = DataInputStream(ch.ins)
            val len = di.readUnsignedShort()
            val r = ByteArray(len)
            di.readFully(r)
            r
        })
        return try { f.get(6, TimeUnit.SECONDS) } catch (_: Exception) { f.cancel(true); null } finally {
            try { ch.ch.disconnect() } catch (_: Exception) {}
        }
    }
}
