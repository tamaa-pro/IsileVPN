package com.tamaa.isilevpn

import android.graphics.Color
import android.text.Html
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan

/** يحوّل أكواد ألوان ANSI (ESC[...m) التي يرسلها الخادم في رسالته إلى ألوان حقيقية في السجل. */
object Ansi {
    private val csi = Regex("\u001B\\[([0-9;?]*)([A-Za-z])")

    /** true في الوضع المشرق: تُستعمل ألوان أغمق كي تبقى مقروءة على الخلفية البيضاء. */
    @Volatile var light = false

    // ألوان مناسبة للخلفية الداكنة (الأسود الصرف يُستبدل برمادي كي يبقى مقروءًا)
    private val normalDark = intArrayOf(
        0xFF6B7280.toInt(), 0xFFF87171.toInt(), 0xFF34D399.toInt(), 0xFFFBBF24.toInt(),
        0xFF60A5FA.toInt(), 0xFFC084FC.toInt(), 0xFF22D3EE.toInt(), 0xFFE6EDF3.toInt()
    )
    private val brightDark = intArrayOf(
        0xFF9CA3AF.toInt(), 0xFFFCA5A5.toInt(), 0xFF6EE7B7.toInt(), 0xFFFDE68A.toInt(),
        0xFF93C5FD.toInt(), 0xFFD8B4FE.toInt(), 0xFF67E8F9.toInt(), 0xFFFFFFFF.toInt()
    )

    private val normalLight = intArrayOf(
        0xFF4B5563.toInt(), 0xFFDC2626.toInt(), 0xFF059669.toInt(), 0xFFB45309.toInt(),
        0xFF2563EB.toInt(), 0xFF7C3AED.toInt(), 0xFF0891B2.toInt(), 0xFF1F2937.toInt()
    )
    private val brightLight = intArrayOf(
        0xFF6B7280.toInt(), 0xFFEF4444.toInt(), 0xFF10B981.toInt(), 0xFFD97706.toInt(),
        0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFF06B6D4.toInt(), 0xFF111827.toInt()
    )
    private val normal: IntArray get() = if (light) normalLight else normalDark
    private val bright: IntArray get() = if (light) brightLight else brightDark

    private val htmlTag = Regex("<\\s*/?\\s*(font|b|i|u|br|span|strong|em|p|div)\\b[^>]*>", RegexOption.IGNORE_CASE)

    fun strip(s: String): String = csi.replace(s, "")

    /** هل النص يحتوي وسوم HTML (مثل <font color=...>) كما ترسلها بعض الخوادم؟ */
    fun hasHtml(s: String): Boolean = htmlTag.containsMatchIn(s)

    /** يعرض رسالة الخادم المكتوبة بـ HTML (متعددة الأسطر) كنص ملوّن واحد. */
    fun appendHtml(sb: SpannableStringBuilder, text: String) {
        val html = text.replace("\r", "").replace("\n", "<br>")
        @Suppress("DEPRECATION")
        val sp = if (android.os.Build.VERSION.SDK_INT >= 24)
            Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY) else Html.fromHtml(html)
        var end = sp.length
        while (end > 0 && sp[end - 1].isWhitespace()) end--
        sb.append(sp.subSequence(0, end))
    }

    private fun color256(n: Int): Int = when {
        n < 8 -> normal[n]
        n < 16 -> bright[n - 8]
        n < 232 -> {
            val i = n - 16
            fun lv(v: Int) = if (v == 0) 0 else 55 + 40 * v
            Color.rgb(lv(i / 36), lv(i / 6 % 6), lv(i % 6))
        }
        else -> {
            val g = 8 + 10 * (n - 232)
            Color.rgb(g, g, g)
        }
    }

    /** يضيف النص إلى sb مع تطبيق ألوانه؛ base هو اللون الافتراضي عند عدم وجود كود. */
    fun append(sb: SpannableStringBuilder, text: String, base: Int) {
        var fg = base
        var bg: Int? = null
        var pos = 0

        fun emit(t: String) {
            if (t.isEmpty()) return
            val a = sb.length
            sb.append(t)
            sb.setSpan(ForegroundColorSpan(fg), a, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            bg?.let { sb.setSpan(BackgroundColorSpan(it), a, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }

        for (m in csi.findAll(text)) {
            emit(text.substring(pos, m.range.first))
            pos = m.range.last + 1
            if (m.groupValues[2] != "m") continue // أوامر أخرى (مسح/تحريك المؤشر) نتجاهلها
            val codes = m.groupValues[1].split(';').map { it.toIntOrNull() ?: 0 }.ifEmpty { listOf(0) }
            var i = 0
            while (i < codes.size) {
                val c = codes[i]
                when {
                    c == 0 -> { fg = base; bg = null }
                    c == 39 -> fg = base
                    c == 49 -> bg = null
                    c in 30..37 -> fg = normal[c - 30]
                    c in 90..97 -> fg = bright[c - 90]
                    c in 40..47 -> bg = normal[c - 40]
                    c in 100..107 -> bg = bright[c - 100]
                    c == 38 || c == 48 -> {
                        val isFg = c == 38
                        val mode = codes.getOrNull(i + 1)
                        if (mode == 5) {
                            val v = color256((codes.getOrNull(i + 2) ?: 0).coerceIn(0, 255))
                            if (isFg) fg = v else bg = v
                            i += 2
                        } else if (mode == 2) {
                            val v = Color.rgb(
                                (codes.getOrNull(i + 2) ?: 0).coerceIn(0, 255),
                                (codes.getOrNull(i + 3) ?: 0).coerceIn(0, 255),
                                (codes.getOrNull(i + 4) ?: 0).coerceIn(0, 255)
                            )
                            if (isFg) fg = v else bg = v
                            i += 4
                        }
                    }
                }
                i++
            }
        }
        emit(text.substring(pos))
    }
}
