package com.tamaa.isilevpn

import android.net.Uri
import android.util.Base64
import org.json.JSONObject

/** يحوّل روابط vless:// vmess:// trojan:// إلى Profile جاهز لملء الخانات. */
object LinkParser {
    fun parse(raw: String): Profile {
        val l = raw.trim()
        return when {
            isDnsCommand(l) -> fromDnsCommand(l)
            l.startsWith("vless://", true) -> fromUri(l, Kind.VLESS)
            l.startsWith("trojan://", true) -> fromUri(l, Kind.TROJAN)
            l.startsWith("vmess://", true) -> fromVmess(l)
            l.startsWith("vaydns://", true) -> fromVaySocks(l)
            l.startsWith("ssh://", true) -> fromSsh(l)
            else -> fromPlainSsh(l)
        }
    }

    private fun net(t: String?): String = when (t) {
        "ws", "grpc", "httpupgrade", "xhttp" -> t
        "splithttp" -> "xhttp"
        else -> "tcp"
    }

    private fun truthy(v: String?) = v == "1" || v.equals("true", true)

    private fun fromUri(l: String, kind: Kind): Profile {
        val u = Uri.parse(l)
        val q = HashMap<String, String>()
        for (k in u.queryParameterNames) u.getQueryParameter(k)?.let { q[k] = it }
        val p = Profile(kind = kind)
        p.host = u.host ?: throw IllegalArgumentException("Missing host")
        p.port = if (u.port > 0) u.port else 443
        p.secret = u.userInfo ?: throw IllegalArgumentException("Missing UUID / password")
        p.name = u.fragment.orEmpty()
        p.network = net(q["type"])
        p.ws = p.network == "ws"
        p.wsPath = q["path"]?.ifEmpty { null } ?: "/"
        p.wsHost = q["host"].orEmpty()
        p.serviceName = q["serviceName"].orEmpty()
        val sec = q["security"]?.ifEmpty { null } ?: if (kind == Kind.TROJAN) "tls" else "none"
        p.security = sec
        p.tls = sec == "tls" || sec == "reality"
        p.sni = (q["sni"] ?: q["peer"]).orEmpty()
        p.fingerprint = q["fp"] ?: "chrome"
        p.alpn = q["alpn"].orEmpty()
        p.insecure = truthy(q["allowInsecure"]) || truthy(q["insecure"])
        p.flow = q["flow"].orEmpty()
        p.encryption = q["encryption"]?.ifEmpty { null } ?: "none"
        p.pbk = q["pbk"].orEmpty()
        p.sid = q["sid"].orEmpty()
        p.spx = q["spx"].orEmpty()
        return p
    }

    private fun fromVmess(l: String): Profile {
        var b64 = l.substring(8).substringBefore('#').trim()
        b64 = b64.replace('-', '+').replace('_', '/')
        val j = try {
            JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid vmess link")
        }
        val p = Profile(kind = Kind.VMESS)
        p.name = j.optString("ps")
        p.host = j.optString("add").ifEmpty { throw IllegalArgumentException("Missing host") }
        p.port = j.optString("port", "443").toIntOrNull() ?: 443
        p.secret = j.optString("id").ifEmpty { throw IllegalArgumentException("Missing UUID") }
        p.alterId = j.optString("aid", "0").toIntOrNull() ?: 0
        p.vmessScy = j.optString("scy").ifEmpty { "auto" }
        p.network = net(j.optString("net", "tcp"))
        p.ws = p.network == "ws"
        p.wsPath = j.optString("path").ifEmpty { "/" }
        p.serviceName = j.optString("path")
        p.wsHost = j.optString("host")
        p.tls = j.optString("tls") == "tls"
        p.security = if (p.tls) "tls" else "none"
        p.sni = j.optString("sni")
        p.fingerprint = j.optString("fp").ifEmpty { "chrome" }
        p.alpn = j.optString("alpn")
        p.insecure = truthy(j.optString("allowInsecure"))
        return p
    }

    // ---------- أوامر عملاء نفق DNS ----------
    private val dnsCmd = Regex("""^\s*(\S*/)?(vaydns-client|dnstt-client)(\s|$)""", RegexOption.IGNORE_CASE)

    fun isDnsCommand(l: String) = dnsCmd.containsMatchIn(l.trim())

    /** تقسيم شبيه بالـ shell: يدعم علامات الاقتباس المفردة والمزدوجة، وإكمال السطر بـ \ . */
    private fun tokenize(s: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var q: Char? = null
        var has = false
        for (ch in s.replace("\\\n", " ").replace("\r", " ").replace("\n", " ")) {
            when {
                q != null -> if (ch == q) q = null else cur.append(ch)
                ch == '"' || ch == '\'' -> { q = ch; has = true }
                ch.isWhitespace() -> if (has || cur.isNotEmpty()) { out += cur.toString(); cur.clear(); has = false }
                else -> cur.append(ch)
            }
        }
        if (has || cur.isNotEmpty()) out += cur.toString()
        return out
    }

    /**
     * vaydns-client -udp IP:53 -pubkey HEX -domain D -listen 127.0.0.1:7000 [-record-type T] [-dnstt-compat]
     * dnstt-client  -udp IP:53 -pubkey HEX D 127.0.0.1:7001
     * يعيد Profile لنفق DNS؛ اسم المستخدم/كلمة المرور يبقيان فارغين ليملأهما المستخدم.
     */
    private fun fromDnsCommand(l: String): Profile {
        val t = tokenize(l)
        val vay = t.first().substringAfterLast('/').equals("vaydns-client", true)
        val p = Profile(kind = Kind.SSH)
        p.dns = if (vay) Dns.VAY else Dns.SLOW
        var resolver: String? = null
        var transport = "udp"
        var domain: String? = null
        var listen: String? = null
        val extra = ArrayList<String>()
        val pos = ArrayList<String>()
        var i = 1
        while (i < t.size) {
            val raw = t[i]
            if (!raw.startsWith("-") || raw == "-") { pos += raw; i++; continue }
            val name = raw.trimStart('-').substringBefore('=').lowercase()
            val inline = if (raw.contains('=')) raw.substringAfter('=') else null
            fun v(): String = inline ?: run {
                if (i + 1 >= t.size) throw IllegalArgumentException("Missing value for -$name")
                i++; t[i]
            }
            when (name) {
                "udp" -> { resolver = v(); transport = "udp" }
                "dot" -> { if (!vay) throw IllegalArgumentException("-dot is only supported by vaydns-client"); resolver = v(); transport = "dot" }
                "doh" -> { if (!vay) throw IllegalArgumentException("-doh is only supported by vaydns-client"); resolver = v(); transport = "doh" }
                "pubkey" -> p.dnsPubkey = v().trim()
                "domain" -> domain = v()
                "listen" -> listen = v()
                "record-type" -> p.dnsRecord = v()
                "dnstt-compat" -> p.dnsCompat = inline == null || truthy(inline)
                "pubkey-file" -> throw IllegalArgumentException("Use -pubkey with the key in hex")
                "idle-timeout" -> if (vay) p.dnsIdle = goDur(name, v(), 1000) else extra += raw
                "keepalive" -> if (vay) p.dnsKeepalive = goDur(name, v(), 1000) else extra += raw
                "udp-timeout" -> if (vay) p.dnsUdpTimeout = goDur(name, v(), 1) else extra += raw
                "open-stream-timeout" -> if (vay) p.dnsOpenStream = goDur(name, v(), 1000) else extra += raw
                "udp-workers" -> if (vay) p.dnsWorkers = v().trim() else extra += raw
                "rps" -> if (vay) p.dnsRps = v().trim() else extra += raw
                "max-qname-len" -> if (vay) p.dnsMaxQname = v().trim() else extra += raw
                "max-num-labels" -> if (vay) p.dnsMaxLabels = v().trim() else extra += raw
                "clientid-size" -> if (vay) p.dnsClientId = v().trim() else extra += raw
                "utls" -> if (vay) p.dnsUtls = v().trim() else extra += raw
                "log-level" -> if (vay) p.dnsLogLevel = v().trim().lowercase() else extra += raw
                else -> {
                    // خيار آخر يدعمه المحرك: يُحفظ في "Extra client flags" ولا يُتجاهل بصمت
                    extra += raw
                    if (inline == null && i + 1 < t.size && !t[i + 1].startsWith("-")) { i++; extra += t[i] }
                }
            }
            i++
        }
        if (!vay) {
            // dnstt-client [flags] DOMAIN LOCALADDR
            domain = domain ?: pos.getOrNull(0)
            listen = listen ?: pos.getOrNull(1)
        }
        p.dnsTransport = if (vay) transport else "udp"
        p.dnsResolver = (if (vay) VayDnsSpec.normalizeResolver(transport, resolver.orEmpty()) else Dns.resolver(resolver.orEmpty()))
            ?: throw IllegalArgumentException(if (vay) VayDnsSpec.resolverError(transport) else "Invalid DNS resolver (use -udp IPv4:port)")
        if (!Dns.validKey(p.dnsPubkey)) throw IllegalArgumentException("Invalid public key")
        p.host = domain?.trim().orEmpty()
        if (!Dns.validDomain(p.host)) throw IllegalArgumentException("Invalid tunnel domain")
        p.dnsListen = Dns.listen(listen.orEmpty()) ?: throw IllegalArgumentException("Invalid local listener")
        if (!vay) p.dnsRecord = ""
        p.dnsCompat = vay && p.dnsCompat
        p.dnsExtra = if (vay) extra.joinToString(" ") else ""
        p.port = 22
        return p
    }

    /** مدة بصيغة Go (10s, 500ms, 2m) أو رقم مجرد (بالثواني) -> عدد صحيح كنص بوحدة التطبيق (unitMs: 1000 = ثوانٍ، 1 = ميلي ثانية). */
    private fun goDur(name: String, v: String, unitMs: Int): String {
        val m = Regex("^(\\d+)(ms|s|m)?$").matchEntire(v.trim())
            ?: throw IllegalArgumentException("Unsupported duration for -$name: $v (use e.g. 10s)")
        val n = m.groupValues[1].toLong()
        val ms = when (m.groupValues[2]) {
            "ms" -> n
            "s" -> n * 1000
            "m" -> n * 60000
            else -> if (unitMs == 1) n else n * 1000 // رقم بلا وحدة: ميلي ثانية للـ UDP timeout وثوانٍ لغيره
        }
        return (ms / unitMs).toString()
    }

    // ---------- SSH ----------
    private fun queryMap(q: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (kv in q.split('&')) {
            if (kv.isEmpty()) continue
            val k = kv.substringBefore('=')
            m[Uri.decode(k)] = Uri.decode(kv.substringAfter('=', ""))
        }
        return m
    }

    private fun splitHostPort(hp: String, defPort: Int): Pair<String, Int> {
        val h = hp.trim()
        if (h.startsWith("[")) {
            val end = h.indexOf(']')
            if (end > 0) return h.substring(1, end) to (h.substring(end + 1).removePrefix(":").toIntOrNull() ?: defPort)
        }
        val i = h.lastIndexOf(':')
        if (i > 0 && h.count { it == ':' } == 1) {
            val port = h.substring(i + 1).toIntOrNull()
            if (port != null) return h.substring(0, i) to port
        }
        return h to defPort
    }

    /** ssh://user:pass@host:port?payload=..&proxy=host:port&ws=1&tls=1&sni=..&tlsv=..&insecure=1#name */
    private fun fromSsh(l: String): Profile {
        val body = l.substring(6)
        val name = Uri.decode(body.substringAfter('#', ""))
        val noFrag = body.substringBefore('#')
        val q = queryMap(noFrag.substringAfter('?', ""))
        val main = noFrag.substringBefore('?').trimEnd('/')
        val at = main.lastIndexOf('@')
        if (at < 0) throw IllegalArgumentException("Missing user / password")
        val info = main.substring(0, at)
        val (host, port) = splitHostPort(main.substring(at + 1), 22)
        if (host.isEmpty()) throw IllegalArgumentException("Missing host")
        val p = Profile(kind = Kind.SSH)
        p.name = name
        p.host = host; p.port = port
        p.user = Uri.decode(info.substringBefore(':'))
        p.pass = Uri.decode(info.substringAfter(':', ""))
        val dnsMode = q["dns"]?.lowercase()
        if (dnsMode == Dns.SLOW || dnsMode == Dns.VAY) {
            // نفق DNS: لا يجتمع مع payload/ws/tls/proxy
            p.dns = dnsMode
            if (dnsMode == Dns.VAY) {
                val tr = q["transport"]?.lowercase().orEmpty().ifEmpty { "udp" }
                if (tr !in VayDnsSpec.TRANSPORTS) throw IllegalArgumentException("DNS transport must be udp, dot or doh")
                p.dnsTransport = tr
                p.dnsResolver = VayDnsSpec.normalizeResolver(tr, q["resolver"].orEmpty()) ?: throw IllegalArgumentException(VayDnsSpec.resolverError(tr))
            } else {
                p.dnsResolver = Dns.resolver(q["resolver"].orEmpty()) ?: throw IllegalArgumentException("Invalid DNS resolver")
            }
            p.dnsPubkey = q["pubkey"].orEmpty().trim()
            if (!Dns.validKey(p.dnsPubkey)) throw IllegalArgumentException("Invalid public key")
            p.dnsRecord = if (dnsMode == Dns.VAY) q["rtype"].orEmpty().lowercase() else ""
            p.dnsCompat = dnsMode == Dns.VAY && truthy(q["compat"])
            if (dnsMode == Dns.VAY) {
                p.dnsIdle = q["idle"].orEmpty(); p.dnsKeepalive = q["keepalive"].orEmpty()
                p.dnsUdpTimeout = q["udptimeout"].orEmpty(); p.dnsOpenStream = q["openstream"].orEmpty()
                p.dnsWorkers = q["workers"].orEmpty(); p.dnsRps = q["rps"].orEmpty()
                p.dnsMaxQname = q["maxqname"].orEmpty(); p.dnsMaxLabels = q["maxlabels"].orEmpty()
                p.dnsClientId = q["clientid"].orEmpty(); p.dnsUtls = q["utls"].orEmpty()
                p.dnsLogLevel = q["loglevel"].orEmpty(); p.dnsExtra = q["extra"].orEmpty()
            }
            p.dnsListen = Dns.listen(q["listen"].orEmpty()) ?: throw IllegalArgumentException("Invalid local listener")
            p.tls = truthy(q["tls"])
            p.sni = q["sni"].orEmpty()
            p.tlsVersion = q["tlsv"]?.ifEmpty { null } ?: "Auto"
            p.insecure = truthy(q["insecure"])
            p.port = 22
            return p
        }
        q["payload"]?.let { p.payloadOn = true; p.payload = it }
        q["proxy"]?.let {
            val (ph, pp) = splitHostPort(it, 8080)
            p.proxyHost = ph; p.proxyPort = pp
        }
        p.ws = truthy(q["ws"])
        q["path"]?.let { p.wsPath = it.ifEmpty { "/" } }
        q["host"]?.let { p.wsHost = it }
        p.tls = truthy(q["tls"])
        p.sni = q["sni"].orEmpty()
        p.tlsVersion = q["tlsv"]?.ifEmpty { null } ?: "Auto"
        p.insecure = truthy(q["insecure"])
        return p
    }

    /** vaydns://[user:pass@]tunnel-domain?resolver=IP:53&pubkey=HEX[&rtype=..][&compat=1][&listen=..]#name */
    private fun fromVaySocks(l: String): Profile {
        val body = l.substring(9)
        val name = Uri.decode(body.substringAfter('#', ""))
        val noFrag = body.substringBefore('#')
        val q = queryMap(noFrag.substringAfter('?', ""))
        val main = noFrag.substringBefore('?').trimEnd('/')
        val at = main.lastIndexOf('@')
        val info = if (at < 0) "" else main.substring(0, at)
        val p = Profile(kind = Kind.SOCKS)
        p.name = name
        p.auth = at >= 0
        p.host = main.substring(at + 1).substringBefore(':').trim()
        if (!Dns.validDomain(p.host)) throw IllegalArgumentException("Invalid tunnel domain")
        p.port = 22
        p.user = Uri.decode(info.substringBefore(':'))
        p.pass = Uri.decode(info.substringAfter(':', ""))
        p.dns = Dns.VAY
        val tr = q["transport"]?.lowercase().orEmpty().ifEmpty { "udp" }
        if (tr !in VayDnsSpec.TRANSPORTS) throw IllegalArgumentException("DNS transport must be udp, dot or doh")
        val fw = q["forward"]?.lowercase().orEmpty().ifEmpty { "socks5" }
        if (fw != "socks5") throw IllegalArgumentException("Only SOCKS5 proxy forwarding is supported")
        p.dnsTransport = tr; p.forward = fw
        p.dnsResolver = VayDnsSpec.normalizeResolver(tr, q["resolver"].orEmpty()) ?: throw IllegalArgumentException(VayDnsSpec.resolverError(tr))
        p.dnsPubkey = q["pubkey"].orEmpty().trim()
        if (!Dns.validKey(p.dnsPubkey)) throw IllegalArgumentException("Invalid public key")
        p.dnsRecord = q["rtype"].orEmpty()
        p.dnsCompat = truthy(q["compat"])
        p.dnsIdle = q["idle"].orEmpty(); p.dnsKeepalive = q["keepalive"].orEmpty()
        p.dnsUdpTimeout = q["udptimeout"].orEmpty(); p.dnsOpenStream = q["openstream"].orEmpty()
        p.dnsWorkers = q["workers"].orEmpty(); p.dnsRps = q["rps"].orEmpty()
        p.dnsMaxQname = q["maxqname"].orEmpty(); p.dnsMaxLabels = q["maxlabels"].orEmpty()
        p.dnsClientId = q["clientid"].orEmpty(); p.dnsUtls = q["utls"].orEmpty()
        p.dnsLogLevel = q["loglevel"].orEmpty(); p.dnsExtra = q["extra"].orEmpty()
        p.dnsListen = Dns.listen(q["listen"].orEmpty()) ?: throw IllegalArgumentException("Invalid local listener")
        return p
    }

    /** صيغ بسيطة شائعة: host:port@user:pass  أو  host:port:user:pass */
    private fun fromPlainSsh(raw: String): Profile {
        val t = raw.trim().lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        val a = Regex("^([^\\s:@/]+):(\\d{1,5})@([^:\\s]+):(.+)$").find(t)
        val b = Regex("^([^\\s:@/]+):(\\d{1,5}):([^:\\s]+):(.+)$").find(t)
        val m = a ?: b ?: throw IllegalArgumentException("Unrecognized config. Use a link or host:port@user:pass")
        val p = Profile(kind = Kind.SSH)
        p.host = m.groupValues[1]
        p.port = m.groupValues[2].toInt().takeIf { it in 1..65535 } ?: 22
        p.user = m.groupValues[3]
        p.pass = m.groupValues[4]
        return p
    }
}
