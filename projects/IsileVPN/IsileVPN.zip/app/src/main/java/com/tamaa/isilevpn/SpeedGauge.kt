package com.tamaa.isilevpn

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** مقياس سرعة دائري (قوس 270°) بتدريج غير خطي: القيمة الحالية في الوسط ووحدتها تحتها. */
class SpeedGauge @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    companion object {
        val MBPS = doubleArrayOf(0.0, 1.0, 5.0, 10.0, 20.0, 50.0, 100.0, 250.0, 500.0, 1000.0)
        val MS = doubleArrayOf(0.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0)
    }

    private var marks = MBPS
    private var unit = "Mbps"
    private var value = 0.0
    private var shown = 0f
    private var anim: ValueAnimator? = null
    private var color = ContextCompat.getColor(c, R.color.accent)

    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        strokeWidth = 14 * d; this.color = ContextCompat.getColor(c, R.color.outline)
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 14 * d
    }
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = 11 * resources.displayMetrics.scaledDensity
        this.color = ContextCompat.getColor(c, R.color.text_dim)
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        this.color = ContextCompat.getColor(c, R.color.text)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = 15 * resources.displayMetrics.scaledDensity
        this.color = ContextCompat.getColor(c, R.color.text_dim)
    }

    fun setScale(m: DoubleArray, u: String, col: Int) {
        marks = m; unit = u; color = ContextCompat.getColor(context, col)
        anim?.cancel(); shown = 0f; value = 0.0
        invalidate()
    }

    fun setValue(v: Double, animate: Boolean = true) {
        value = v
        val to = frac(v)
        anim?.cancel()
        if (!animate) { shown = to; invalidate(); return }
        anim = ValueAnimator.ofFloat(shown, to).apply {
            duration = 250
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun frac(v: Double): Float {
        val n = marks.size - 1
        if (v <= marks[0]) return 0f
        if (v >= marks[n]) return 1f
        for (i in 0 until n) {
            if (v < marks[i + 1]) return ((i + (v - marks[i]) / (marks[i + 1] - marks[i])) / n).toFloat()
        }
        return 1f
    }

    private fun fmt(v: Double): String = when {
        unit == "ms" -> String.format(Locale.US, "%.0f", v)
        v >= 100 -> String.format(Locale.US, "%.0f", v)
        v >= 10 -> String.format(Locale.US, "%.1f", v)
        else -> String.format(Locale.US, "%.2f", v)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f + 6 * d
        val r = min(width, height) / 2f - 34 * d
        val oval = RectF(cx - r, cy - r, cx + r, cy + r)
        cv.drawArc(oval, 135f, 270f, false, track)
        prog.color = color
        if (shown > 0.002f) cv.drawArc(oval, 135f, 270f * shown, false, prog)
        // نقطة عند طرف القوس
        val ang = Math.toRadians(135.0 + 270.0 * shown)
        knob.color = color
        cv.drawCircle(cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat(), 11 * d, knob)
        knob.color = ContextCompat.getColor(context, R.color.card)
        cv.drawCircle(cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat(), 5 * d, knob)
        // أرقام التدريج
        val n = marks.size - 1
        val tr = r + 26 * d
        for (i in 0..n) {
            val a = Math.toRadians(135.0 + 270.0 * i / n)
            val label = marks[i].let { if (it >= 1000) "1K" else String.format(Locale.US, "%.0f", it) }
            cv.drawText(label, cx + (tr * cos(a)).toFloat(), cy + (tr * sin(a)).toFloat() + tick.textSize / 3f, tick)
        }
        big.textSize = r * 0.62f
        cv.drawText(fmt(value), cx, cy + big.textSize * 0.2f, big)
        cv.drawText(unit, cx, cy + big.textSize * 0.2f + small.textSize * 1.5f, small)
    }
}
