package com.tamaa.isilevpn

import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

class SpeedCancelled : IOException("cancelled")

/** القيمة NaN تعني أن هذه المرحلة فشلت على كل الخوادم. */
data class SpeedResult(val down: Double, val up: Double, val ping: Double, val jitter: Double)

/**
 * اختبار السرعة (رفع ثم تحميل ثم ping).
 * أثناء الاتصال تمر الطلبات عبر نفق SOCKS لأن التطبيق مستثنى من الـ VPN، فتُقاس سرعة النفق نفسه.
 * إن فشل خادم تُجرَّب الخوادم التالية تلقائيًا.
 */
object SpeedTest {
    private const val UA = "Mozilla/5.0 (Linux; Android 13) IsileVPN"
    private const val THREADS = 4
    private const val SECS = 8
    private const val WARMUP_MS = 1000L

    class Server(
        val name: String,
        val down: (Long) -> String,
        val up: String?,
        val pingUrl: String,
        val pingMethod: String
    )

    val SERVERS = listOf(
        Server(
            "Cloudflare", { b -> "https://speed.cloudflare.com/__down?bytes=$b" },
            "https://speed.cloudflare.com/__up",
            "https://speed.cloudflare.com/__down?bytes=0", "GET"
        ),
        Server(
            "Tele2", { _ -> "https://speedtest.tele2.net/100MB.zip" },
            "https://speedtest.tele2.net/upload.php",
            "https://speedtest.tele2.net/1MB.zip", "HEAD"
        ),
        Server(
            "OVH", { _ -> "https://proof.ovh.net/files/1Gb.dat" }, null,
            "https://proof.ovh.net/files/1Gb.dat", "HEAD"
        )
    )

    class Token { @Volatile var cancelled = false }

    private fun open(url: String, via: Boolean): HttpURLConnection {
        val px = if (via) Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT)) else Proxy.NO_PROXY
        val c = URL(url).openConnection(px) as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.useCaches = false
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "*/*")
        c.setRequestProperty("Cache-Control", "no-cache")
        return c
    }

    private fun err(e: Throwable): String = (e.message ?: e.javaClass.simpleName).take(80)

    /** يشغّل عدة خيوط تنقل بيانات لمدة محددة ويقيس السرعة (Mbps) بعد فترة إحماء قصيرة. */
    private fun measure(
        tk: Token, onSpeed: (Double) -> Unit,
        worker: (conn: (HttpURLConnection) -> Unit, total: AtomicLong, stop: () -> Boolean) -> Unit
    ): Double {
        val total = AtomicLong()
        val done = AtomicBoolean(false)
        val conns = ArrayList<HttpURLConnection>()
        val firstErr = AtomicReference<String?>(null)
        val workers = List(THREADS) {
            Thread {
                try {
                    worker({ c -> synchronized(conns) { conns.add(c) } }, total) { done.get() || tk.cancelled }
                } catch (e: Throwable) {
                    if (!done.get() && !tk.cancelled) firstErr.compareAndSet(null, err(e))
                }
            }.apply { isDaemon = true; start() }
        }
        val t0 = System.nanoTime()
        val end = t0 + SECS * 1_000_000_000L
        var baseT = -1L
        var baseB = 0L
        val win = ArrayDeque<Pair<Long, Long>>()
        while (System.nanoTime() < end && !tk.cancelled && workers.any { it.isAlive }) {
            try { Thread.sleep(150) } catch (_: InterruptedException) { break }
            val now = System.nanoTime()
            val b = total.get()
            win.addLast(now to b)
            while (win.size > 2 && now - win.first().first > 1_500_000_000L) win.removeFirst()
            val f = win.first()
            val dt = (now - f.first) / 1e9
            if (dt > 0.3 && (now - t0) / 1_000_000 >= 400) onSpeed((b - f.second) * 8 / dt / 1e6)
            if (baseT < 0 && (now - t0) / 1_000_000 >= WARMUP_MS) { baseT = now; baseB = b }
        }
        val tEnd = System.nanoTime()
        val bytesEnd = total.get()
        done.set(true)
        synchronized(conns) { conns.forEach { try { it.disconnect() } catch (_: Throwable) {} } }
        workers.forEach { try { it.join(1500) } catch (_: InterruptedException) {} }
        if (tk.cancelled) throw SpeedCancelled()
        if (bytesEnd == 0L) throw IOException(firstErr.get() ?: "no data received")
        val secs = if (baseT > 0) (tEnd - baseT) / 1e9 else (tEnd - t0) / 1e9
        val bytes = if (baseT > 0) bytesEnd - baseB else bytesEnd
        return if (secs > 0) bytes * 8 / secs / 1e6 else 0.0
    }

    fun download(s: Server, via: Boolean, tk: Token, onSpeed: (Double) -> Unit): Double =
        measure(tk, onSpeed) { reg, total, stop ->
            val buf = ByteArray(65536)
            while (!stop()) {
                val c = open(s.down(100_000_000), via)
                reg(c)
                try {
                    val code = c.responseCode
                    if (code !in 200..299) throw IOException("HTTP $code")
                    c.inputStream.use { st ->
                        while (!stop()) {
                            val n = st.read(buf)
                            if (n < 0) break
                            total.addAndGet(n.toLong())
                        }
                    }
                } finally { try { c.disconnect() } catch (_: Throwable) {} }
            }
        }

    /**
     * الرفع: لا يُحسب أي بايت إلا بعد أن يرد الخادم بنجاح على الطلب، لأن الكتابة في المقبس تظهر
     * بسرعة وهمية عالية (تذهب لذاكرة النظام والنفق المحلي) قبل أن يستلمها الخادم فعلًا.
     * تبدأ الطلبات صغيرة وتكبر تدريجيًا كلما كان الاتصال سريعًا.
     */
    fun upload(s: Server, via: Boolean, tk: Token, onSpeed: (Double) -> Unit): Double {
        val url = s.up ?: throw IOException("no upload endpoint")
        val data = ByteArray(4 * 1024 * 1024).also { java.util.Random().nextBytes(it) }
        return measure(tk, onSpeed) { reg, total, stop ->
            var size = 64 * 1024
            while (!stop()) {
                val c = open(url, via)
                reg(c)
                val t = System.nanoTime()
                try {
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.setFixedLengthStreamingMode(size)
                    c.setRequestProperty("Content-Type", "application/octet-stream")
                    c.outputStream.use { it.write(data, 0, size) }
                    val code = c.responseCode
                    if (code !in 200..299) throw IOException("HTTP $code")
                    c.inputStream.use { it.readBytes() }
                    if (!stop()) total.addAndGet(size.toLong())
                } catch (e: Throwable) {
                    try { c.disconnect() } catch (_: Throwable) {}
                    throw e
                }
                val ms = (System.nanoTime() - t) / 1e6
                if (ms < 300 && size < data.size) size *= 2
            }
        }
    }

    /** يرجع (ping الوسيط, jitter) بالميلي ثانية. أول طلب للإحماء (اتصال + TLS) ولا يُحسب. */
    fun ping(s: Server, via: Boolean, tk: Token, onSample: (Double) -> Unit): Pair<Double, Double> {
        fun one(): Double {
            val c = open(s.pingUrl, via)
            c.requestMethod = s.pingMethod
            val t = System.nanoTime()
            try {
                val code = c.responseCode
                if (code !in 200..299) throw IOException("HTTP $code")
                if (s.pingMethod != "HEAD") c.inputStream.use { it.readBytes() }
            } catch (e: IOException) {
                try { c.disconnect() } catch (_: Throwable) {}
                throw e
            }
            return (System.nanoTime() - t) / 1e6
        }
        one()
        val list = ArrayList<Double>()
        var fails = 0
        while (list.size < 12) {
            if (tk.cancelled) throw SpeedCancelled()
            try {
                list.add(one()); onSample(list.last())
            } catch (e: IOException) {
                if (++fails > 4) throw e
            }
        }
        val sorted = list.sorted()
        val median = (sorted[list.size / 2 - 1] + sorted[list.size / 2]) / 2
        var j = 0.0
        for (i in 1 until list.size) j += abs(list[i] - list[i - 1])
        return median to j / (list.size - 1)
    }

    // ---------- التقييم ----------
    enum class Grade(val label: String) { EXCELLENT("Excellent"), GOOD("Good"), FAIR("Fair"), POOR("Poor") }
    data class Rating(val title: String, val grade: Grade, val detail: String)

    private fun grade(score: Double): Grade = when {
        score >= 3 -> Grade.EXCELLENT
        score >= 2 -> Grade.GOOD
        score >= 1 -> Grade.FAIR
        else -> Grade.POOR
    }

    fun rate(r: SpeedResult): List<Rating> {
        val out = ArrayList<Rating>()
        // التصفح: يحتاج استجابة سريعة أكثر من سرعة عالية
        val bs = when {
            r.down >= 10 && r.ping < 100 -> 3.0
            r.down >= 3 && r.ping < 200 -> 2.0
            r.down >= 1 && r.ping < 400 -> 1.0
            else -> 0.0
        }
        out.add(Rating("Browsing", grade(bs), ""))
        // الفيديو: أعلى جودة تكفيها سرعة التحميل
        val (q, vs) = when {
            r.down >= 25 -> "4K" to 3.0
            r.down >= 8 -> "1080p" to 3.0
            r.down >= 5 -> "720p" to 2.0
            r.down >= 2.5 -> "480p" to 1.0
            r.down >= 1 -> "360p" to 1.0
            else -> "" to 0.0
        }
        out.add(Rating("Video streaming", grade(vs), if (q.isEmpty()) "" else "Up to $q"))
        // البثوث المباشرة: تحتاج ثباتًا (jitter منخفض) إضافة للسرعة. الرفع يحدد جودة البث من هاتفك
        val ls = when {
            r.down >= 8 && r.jitter < 30 && r.ping < 150 -> 3.0
            r.down >= 4 && r.jitter < 60 -> 2.0
            r.down >= 2 && r.jitter < 120 -> 1.0
            else -> 0.0
        }
        val go = when {
            r.up >= 6 -> "1080p"
            r.up >= 3 -> "720p"
            r.up >= 1.5 -> "480p"
            r.up >= 0.7 -> "360p"
            else -> ""
        }
        out.add(Rating("Live streams", grade(ls), if (go.isEmpty()) "" else "Going live: $go"))
        // الألعاب: الاستجابة والثبات أهم من السرعة
        val gs = when {
            r.ping <= 40 && r.jitter <= 10 && r.down >= 3 -> 3.0
            r.ping <= 80 && r.jitter <= 25 && r.down >= 3 -> 2.0
            r.ping <= 130 && r.jitter <= 50 && r.down >= 1 -> 1.0
            else -> 0.0
        }
        out.add(Rating("Gaming", grade(gs), ""))
        return out
    }
}
