#!/usr/bin/env bash
# يجلب/يبني المكونات الأصلية ويضعها في jniLibs (arm64-v8a)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/app/src/main/jniLibs/arm64-v8a"
TMP="$(mktemp -d)"
mkdir -p "$OUT"

echo "==> [1/4] Xray-core (VLESS / VMess / Trojan)"
# لتثبيت إصدار محدد: XRAY_VERSION=v25.x.x ./scripts/fetch-natives.sh
if [ -n "${XRAY_VERSION:-}" ]; then
  XRAY_URL="https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/Xray-android-arm64-v8a.zip"
else
  XRAY_URL="https://github.com/XTLS/Xray-core/releases/latest/download/Xray-android-arm64-v8a.zip"
fi
curl -fL "$XRAY_URL" -o "$TMP/xray.zip"
mkdir -p "$TMP/xray" && unzip -o "$TMP/xray.zip" xray -d "$TMP/xray"
cp "$TMP/xray/xray" "$OUT/libxray.so"
chmod +x "$OUT/libxray.so"

echo "==> [2/4] hev-socks5-tunnel (TUN -> SOCKS5)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [ -z "$NDK" ] || [ ! -x "$NDK/ndk-build" ]; then
  NDK="$(ls -d "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"/ndk/* 2>/dev/null | sort -V | tail -n1)"
fi
echo "NDK: $NDK"
T="$TMP/tproxy"
mkdir -p "$T/jni"
echo 'include $(call all-subdir-makefiles)' > "$T/jni/Android.mk"
# مثبّت على إصدار يطابق واجهة JNI في TProxyService.java (الإصدارات >= 2.17.0).
# لتغييره: HEV_VERSION=2.x.y ./scripts/fetch-natives.sh
HEV_VERSION="${HEV_VERSION:-2.18.0}"
git clone --recursive --depth 1 --branch "$HEV_VERSION" https://github.com/heiher/hev-socks5-tunnel "$T/jni/hev-socks5-tunnel"
"$NDK/ndk-build" NDK_PROJECT_PATH="$T" APP_BUILD_SCRIPT="$T/jni/Android.mk" \
  APP_ABI=arm64-v8a APP_PLATFORM=android-24 NDK_LIBS_OUT="$T/libs" NDK_OUT="$T/obj"
cp "$T/libs/arm64-v8a/libhev-socks5-tunnel.so" "$OUT/"

# ---- عملاء نفق DNS (Go خالص، دون cgo): تُبنى لـ linux/arm64 وتُشغَّل كعمليات من nativeLibraryDir ----
export GOOS=linux GOARCH=arm64 CGO_ENABLED=0

echo "==> [3/4] dnstt-client (SlowDNS)"
# المستودع على HTTP "غبي" (dumb) فلا يدعم --depth؛ نستنسخه كاملًا (صغير الحجم)
if git clone https://www.bamsoftware.com/git/dnstt.git "$TMP/dnstt"; then
  (cd "$TMP/dnstt/dnstt-client" && go build -trimpath -ldflags "-s -w" -o "$OUT/libdnstt.so" .)
else
  echo "git clone failed, trying go install"
  # مع التحويل لمعمارية أخرى يضع go install الملف في $GOPATH/bin/linux_arm64 (ولا يقبل GOBIN)
  go install -trimpath -ldflags "-s -w" www.bamsoftware.com/git/dnstt.git/dnstt-client@latest
  BIN="$(find "$(go env GOPATH)/bin" -type f -name dnstt-client | head -n1)"
  [ -n "$BIN" ] || { echo "dnstt-client binary not found"; exit 1; }
  cp "$BIN" "$OUT/libdnstt.so"
fi
chmod +x "$OUT/libdnstt.so"

echo "==> [4/4] vaydns-client (VayDNS)"
# لم تعد libvaydns.so مضمَّنة في المستودع: تُبنى هنا من المصدر الرسمي، مثبّتة على نفس الإصدار (v0.2.8)
# الذي كان مضمَّنًا سابقًا، وبنفس خيارات البناء (Go خالص، -trimpath، -s -w)، فلا يتغير أي سلوك.
# لتغيير الإصدار: VAYDNS_REF=<commit أو tag> ./scripts/fetch-natives.sh
# (الترخيص: licenses/VAYDNS-LICENSE-CC0.txt)
VAYDNS_REF="${VAYDNS_REF:-a0ff70110d5e96686ab8f4c8e1c44cd09be07a75}"
VAYDNS_VERSION="${VAYDNS_VERSION:-0.2.8}"
V="$TMP/vaydns"
git clone --quiet https://github.com/net2share/vaydns "$V"
git -C "$V" checkout --quiet "$VAYDNS_REF"
(cd "$V" && go build -trimpath -ldflags "-s -w -X main.version=$VAYDNS_VERSION" -o "$OUT/libvaydns.so" ./vaydns-client)
[ -s "$OUT/libvaydns.so" ] || { echo "::error::failed to build libvaydns.so"; exit 1; }
chmod +x "$OUT/libvaydns.so"

ls -lh "$OUT"
