#!/usr/bin/env bash
# يجلب/يبني المكونات الأصلية ويضعها في jniLibs (arm64-v8a و armeabi-v7a)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"

# ABIs المدعومة: arm64-v8a (أغلب الهواتف) + armeabi-v7a (هواتف 32-bit مثل Redmi 10A التي تعمل بنظام 32-bit فقط)
ABIS="${ABIS:-arm64-v8a armeabi-v7a}"
for ABI in $ABIS; do mkdir -p "$ROOT/app/src/main/jniLibs/$ABI"; done

echo "==> [1/4] Xray-core (VLESS / VMess / Trojan)"
# لتثبيت إصدار محدد: XRAY_VERSION=v25.x.x ./scripts/fetch-natives.sh
xray_url() {  # $1 = اسم الملف
  if [ -n "${XRAY_VERSION:-}" ]; then echo "https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/$1"
  else echo "https://github.com/XTLS/Xray-core/releases/latest/download/$1"; fi
}
for ABI in $ABIS; do
  case "$ABI" in
    arm64-v8a)   XZIP="Xray-android-arm64-v8a.zip" ;;
    armeabi-v7a) XZIP="Xray-linux-arm32-v7a.zip" ;;   # Go ثابت (static) يعمل على أندرويد 32-bit
  esac
  curl -fL "$(xray_url "$XZIP")" -o "$TMP/xray-$ABI.zip"
  mkdir -p "$TMP/xray-$ABI" && unzip -o "$TMP/xray-$ABI.zip" xray -d "$TMP/xray-$ABI"
  cp "$TMP/xray-$ABI/xray" "$ROOT/app/src/main/jniLibs/$ABI/libxray.so"
  chmod +x "$ROOT/app/src/main/jniLibs/$ABI/libxray.so"
done

echo "==> [2/4] hev-socks5-tunnel (TUN -> SOCKS5)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [ -z "$NDK" ] || [ ! -x "$NDK/ndk-build" ]; then
  NDK="$(ls -d "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"/ndk/* 2>/dev/null | sort -V | tail -n1)"
fi
echo "NDK: $NDK"
T="$TMP/tproxy"
mkdir -p "$T/jni"
echo 'include $(call all-subdir-makefiles)' > "$T/jni/Android.mk"
# مثبّت على إصدار يطابق واجهة JNI في TProxyService.java (الإصدارات >= 2.17.0).
# لتغييره: HEV_VERSION=2.x.y ./scripts/fetch-natives.sh
HEV_VERSION="${HEV_VERSION:-2.18.0}"
git clone --recursive --depth 1 --branch "$HEV_VERSION" https://github.com/heiher/hev-socks5-tunnel "$T/jni/hev-socks5-tunnel"
"$NDK/ndk-build" NDK_PROJECT_PATH="$T" APP_BUILD_SCRIPT="$T/jni/Android.mk" \
  APP_ABI="$ABIS" APP_PLATFORM=android-24 NDK_LIBS_OUT="$T/libs" NDK_OUT="$T/obj"
for ABI in $ABIS; do cp "$T/libs/$ABI/libhev-socks5-tunnel.so" "$ROOT/app/src/main/jniLibs/$ABI/"; done

# ---- عملاء نفق DNS (Go خالص، دون cgo): تُبنى لكل ABI وتُشغَّل كعمليات من nativeLibraryDir ----
export GOOS=linux CGO_ENABLED=0
go_env() {  # $1 = ABI
  case "$1" in
    arm64-v8a)   export GOARCH=arm64; unset GOARM ;;
    armeabi-v7a) export GOARCH=arm GOARM=7 ;;
  esac
}

echo "==> [3/4] dnstt-client (SlowDNS)"
# المستودع على HTTP "غبي" (dumb) فلا يدعم --depth؛ نستنسخه كاملًا (صغير الحجم)
if git clone https://www.bamsoftware.com/git/dnstt.git "$TMP/dnstt"; then
  for ABI in $ABIS; do
    go_env "$ABI"
    (cd "$TMP/dnstt/dnstt-client" && go build -trimpath -ldflags "-s -w" -o "$ROOT/app/src/main/jniLibs/$ABI/libdnstt.so" .)
  done
else
  echo "git clone failed, trying go install"
  for ABI in $ABIS; do
    go_env "$ABI"
    rm -rf "$(go env GOPATH)/bin"
    go install -trimpath -ldflags "-s -w" www.bamsoftware.com/git/dnstt.git/dnstt-client@latest
    BIN="$(find "$(go env GOPATH)/bin" -type f -name dnstt-client | head -n1)"
    [ -n "$BIN" ] || { echo "dnstt-client binary not found"; exit 1; }
    cp "$BIN" "$ROOT/app/src/main/jniLibs/$ABI/libdnstt.so"
  done
fi

echo "==> [4/4] vaydns-client (VayDNS)"
# تُبنى من المصدر الرسمي مثبّتة على الإصدار v0.2.8 (نفس ما كان مضمَّنًا سابقًا وبنفس خيارات البناء).
# لتغيير الإصدار: VAYDNS_REF=<commit أو tag> ./scripts/fetch-natives.sh
# (الترخيص: licenses/VAYDNS-LICENSE-CC0.txt)
VAYDNS_REF="${VAYDNS_REF:-a0ff70110d5e96686ab8f4c8e1c44cd09be07a75}"
VAYDNS_VERSION="${VAYDNS_VERSION:-0.2.8}"
V="$TMP/vaydns"
git clone --quiet https://github.com/net2share/vaydns "$V"
git -C "$V" checkout --quiet "$VAYDNS_REF"
for ABI in $ABIS; do
  go_env "$ABI"
  (cd "$V" && go build -trimpath -ldflags "-s -w -X main.version=$VAYDNS_VERSION" -o "$ROOT/app/src/main/jniLibs/$ABI/libvaydns.so" ./vaydns-client)
done

for ABI in $ABIS; do
  D="$ROOT/app/src/main/jniLibs/$ABI"
  for L in libxray libhev-socks5-tunnel libdnstt libvaydns; do
    [ -s "$D/$L.so" ] || { echo "::error::$L.so missing for $ABI"; exit 1; }
  done
  chmod +x "$D"/*.so
  echo "-- $ABI"; ls -lh "$D"
done
